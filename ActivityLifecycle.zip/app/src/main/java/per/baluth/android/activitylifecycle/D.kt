package per.baluth.android.activitylifecycle

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.Window
import android.widget.Button

private const val EXTRA_IS_BUTTON_CLEAR_PRESSED =
    "per.baluth.android.activitylifecycle.is_button_clear_pressed"

class D : Activity() {
    private lateinit var clearButton: Button
    private lateinit var closeButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        this.requestWindowFeature(Window.FEATURE_NO_TITLE)
        setContentView(R.layout.d)
        this.setFinishOnTouchOutside(false)
    }

    override fun onResume() {
        super.onResume()

        closeButton = findViewById(R.id.close_button)
        closeButton.setOnClickListener {
            val data = Intent().apply {
                putExtra(EXTRA_IS_BUTTON_CLEAR_PRESSED, false)
            }
            setResult(RESULT_OK, data)
            finish()
        }

        clearButton = findViewById(R.id.clear_button)
        clearButton.setOnClickListener {
            val data = Intent().apply {
                putExtra(EXTRA_IS_BUTTON_CLEAR_PRESSED, true)
            }
            setResult(RESULT_OK, data)
            finish()
        }
    }
}