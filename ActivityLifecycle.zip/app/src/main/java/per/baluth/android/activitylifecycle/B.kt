package per.baluth.android.activitylifecycle

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

private const val TAG = "ActivityB"

class B : AppCompatActivity() {
    private lateinit var startAButton: Button
    private lateinit var startCButton: Button
    private lateinit var finishBButton: Button
    private lateinit var dialogButton: Button
    private lateinit var lifecycleMethodListContentTextView: TextView
    private lateinit var activityStatusContentTextView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportActionBar?.hide()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            window.statusBarColor = getColor(R.color.b_bg)
        }
        setContentView(R.layout.b)

        Log.d(TAG, getString(R.string.task_id) + taskId.toString())

        val info = getString(R.string.activity_b) + getString(R.string.on_create)
        Log.d(TAG, info)
        addTextToList(info)

        val status = getString(R.string.activity_b) + getString(R.string.created)
        updateStatus(status)
    }

    override fun onStart() {
        super.onStart()

        val info = getString(R.string.activity_b) + getString(R.string.on_start)
        Log.d(TAG, info)
        addTextToList(info)

        val status = getString(R.string.activity_b) + getString(R.string.started)
        updateStatus(status)
    }

    override fun onResume() {
        super.onResume()

        val info = getString(R.string.activity_b) + getString(R.string.on_resume)
        Log.d(TAG, info)
        addTextToList(info)

        val status = getString(R.string.activity_b) + getString(R.string.resumed)
        updateStatus(status)

        startAButton = findViewById(R.id.start_a_button)
        startAButton.setOnClickListener {
            val intent = Intent(this, A::class.java)
            startActivity(intent)
        }

        startCButton = findViewById(R.id.start_c_button)
        startCButton.setOnClickListener {
            val intent = Intent(this, C::class.java)
            startActivity(intent)
        }

        finishBButton = findViewById(R.id.finish_b_button)
        finishBButton.setOnClickListener {
            finish()
        }

        dialogButton = findViewById(R.id.dialog_button)
        dialogButton.setOnClickListener {
            AlertDialog.Builder(this).apply {
                setMessage(getString(R.string.simple_dialog))
                setCancelable(true)
                setNegativeButton(getString(R.string.close)) { _, _ -> }
                setPositiveButton(R.string.clear) { _, _ ->
                    LogViewModel.lifecycleMethodListContent = ""
                    lifecycleMethodListContentTextView.text = ""
                }
                show()
            }
        }
    }

    override fun onPostResume() {
        super.onPostResume()
        Handler().postDelayed({
            lifecycleMethodListContentTextView.text = LogViewModel.lifecycleMethodListContent
            activityStatusContentTextView.text = LogViewModel.activityStatusContent
        }, 1000)
    }

    override fun onPause() {
        super.onPause()

        val info = getString(R.string.activity_b) + getString(R.string.on_pause)
        Log.d(TAG, info)
        addTextToList(info)

        val status = getString(R.string.activity_b) + getString(R.string.paused)
        updateStatus(status)
    }

    override fun onStop() {
        super.onStop()

        val info = getString(R.string.activity_b) + getString(R.string.on_stop)
        Log.d(TAG, info)
        addTextToList(info)

        val status = getString(R.string.activity_b) + getString(R.string.stopped)
        updateStatus(status)
    }

    override fun onDestroy() {
        super.onDestroy()

        val info = getString(R.string.activity_b) + getString(R.string.on_destroy)
        Log.d(TAG, info)
        addTextToList(info)

        val status = getString(R.string.activity_b) + getString(R.string.destroyed)
        updateStatus(status)
    }

    override fun onRestart() {
        super.onRestart()

        val info = getString(R.string.activity_b) + getString(R.string.on_restart)
        Log.d(TAG, info)
        addTextToList(info)

        val status = getString(R.string.activity_b) + getString(R.string.restarted)
        updateStatus(status)
    }

    private fun addTextToList(nextLine: String) {
        lifecycleMethodListContentTextView = findViewById(R.id.lifecycle_method_list_content)
        var origin = LogViewModel.lifecycleMethodListContent
        if (origin != "") {
            origin = "\n" + origin
        }
        val current = nextLine + origin
        lifecycleMethodListContentTextView.text = current
        LogViewModel.lifecycleMethodListContent = current
    }

    private fun updateStatus(status: String) {
        activityStatusContentTextView = findViewById(R.id.activity_status_content)
        LogViewModel.activityStatus[1] = status
        val array = LogViewModel.activityStatus
        var concat = status
        if (array[0] != "") {
            concat = array[0] + "\n" + concat
        }
        if (array[2] != "") {
            concat = concat + "\n" + array[2]
        }
        activityStatusContentTextView.text = concat
        LogViewModel.activityStatusContent = concat
    }
}