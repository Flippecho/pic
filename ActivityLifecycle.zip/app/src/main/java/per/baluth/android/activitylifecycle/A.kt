package per.baluth.android.activitylifecycle

import android.app.ActivityManager
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.DialogFragment

private const val TAG = "ActivityA"

class A : AppCompatActivity(), SimpleDialogFragment.SimpleDialogListener {
    private lateinit var startBButton: Button
    private lateinit var startCButton: Button
    private lateinit var finishAButton: Button
    private lateinit var dialogButton: Button
    private lateinit var lifecycleMethodListContentTextView: TextView
    private lateinit var activityStatusContentTextView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportActionBar?.hide()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            window.statusBarColor = getColor(R.color.a_bg)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            setTaskDescription(
                ActivityManager.TaskDescription(
                    "Activity Lifecycle",
                    R.drawable.ic_launcher_foreground
                )
            )
        }
        setContentView(R.layout.a)

        Log.d(TAG, getString(R.string.task_id) + taskId.toString())

        val info = getString(R.string.activity_a) + getString(R.string.on_create)
        Log.d(TAG, info)
        addTextToList(info)

        val status = getString(R.string.activity_a) + getString(R.string.created)
        updateStatus(status)
    }

    override fun onStart() {
        super.onStart()

        val info = getString(R.string.activity_a) + getString(R.string.on_start)
        Log.d(TAG, info)
        addTextToList(info)

        val status = getString(R.string.activity_a) + getString(R.string.started)
        updateStatus(status)
    }

    override fun onResume() {
        super.onResume()

        val info = getString(R.string.activity_a) + getString(R.string.on_resume)
        Log.d(TAG, info)
        addTextToList(info)

        val status = getString(R.string.activity_a) + getString(R.string.resumed)
        updateStatus(status)

        startBButton = findViewById(R.id.start_b_button)
        startBButton.setOnClickListener {
            val intent = Intent(this, B::class.java)
            startActivity(intent)
        }

        startCButton = findViewById(R.id.start_c_button)
        startCButton.setOnClickListener {
            val intent = Intent(this, C::class.java)
            startActivity(intent)
        }

        finishAButton = findViewById(R.id.finish_a_button)
        finishAButton.setOnClickListener {
            finish()
        }

        dialogButton = findViewById(R.id.dialog_button)
        dialogButton.setOnClickListener {
            val simpleDialogFragment = SimpleDialogFragment()
            simpleDialogFragment.show(supportFragmentManager, getString(R.string.simple_dialog))
        }
    }

    override fun onPostResume() {
        super.onPostResume()
        Handler().postDelayed({
            lifecycleMethodListContentTextView.text = LogViewModel.lifecycleMethodListContent
            activityStatusContentTextView.text = LogViewModel.activityStatusContent
        }, 1000)
    }

    override fun onPause() {
        super.onPause()

        val info = getString(R.string.activity_a) + getString(R.string.on_pause)
        Log.d(TAG, info)
        addTextToList(info)

        val status = getString(R.string.activity_a) + getString(R.string.paused)
        updateStatus(status)
    }

    override fun onStop() {
        super.onStop()

        val info = getString(R.string.activity_a) + getString(R.string.on_stop)
        Log.d(TAG, info)
        addTextToList(info)

        val status = getString(R.string.activity_a) + getString(R.string.stopped)
        updateStatus(status)
    }

    override fun onDestroy() {
        super.onDestroy()

        val info = getString(R.string.activity_a) + getString(R.string.on_destroy)
        Log.d(TAG, info)
        addTextToList(info)

        val status = getString(R.string.activity_a) + getString(R.string.destroyed)
        updateStatus(status)
    }

    override fun onRestart() {
        super.onRestart()

        val info = getString(R.string.activity_a) + getString(R.string.on_restart)
        Log.d(TAG, info)
        addTextToList(info)

        val status = getString(R.string.activity_a) + getString(R.string.restarted)
        updateStatus(status)
    }

    private fun addTextToList(nextLine: String) {
        lifecycleMethodListContentTextView = findViewById(R.id.lifecycle_method_list_content)
        var origin = LogViewModel.lifecycleMethodListContent
        if (origin != "") {
            origin = "\n" + origin
        }
        val current = nextLine + origin
        lifecycleMethodListContentTextView.text = current
        LogViewModel.lifecycleMethodListContent = current
    }

    private fun updateStatus(status: String) {
        activityStatusContentTextView = findViewById(R.id.activity_status_content)
        LogViewModel.activityStatus[0] = status
        val array = LogViewModel.activityStatus
        var concat = status
        if (array[1] != "") {
            concat = concat + "\n" + array[1]
        }
        if (array[2] != "") {
            concat = concat + "\n" + array[2]
        }
        activityStatusContentTextView.text = concat
        LogViewModel.activityStatusContent = concat
    }

    override fun onDialogPositiveClick(dialog: DialogFragment) {
        LogViewModel.lifecycleMethodListContent = ""
        lifecycleMethodListContentTextView.text = ""
    }

    override fun onDialogNeutralClick(dialog: DialogFragment) {
        val intent = Intent(this, A::class.java)
        startActivity(intent)
    }
}