package per.baluth.android.activitylifecycle

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

private const val TAG = "ActivityC"
private const val REQUEST_CODE_DIALOG = 0
private const val EXTRA_IS_BUTTON_CLEAR_PRESSED =
    "per.baluth.android.activitylifecycle.is_button_clear_pressed"

class C : AppCompatActivity() {
    private lateinit var startAButton: Button
    private lateinit var startBButton: Button
    private lateinit var finishCButton: Button
    private lateinit var dialogButton: Button
    private lateinit var lifecycleMethodListContentTextView: TextView
    private lateinit var activityStatusContentTextView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportActionBar?.hide()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            window.statusBarColor = getColor(R.color.c_bg)
        }
        setContentView(R.layout.c)

        Log.d(TAG, getString(R.string.task_id) + taskId.toString())

        val info = getString(R.string.activity_c) + getString(R.string.on_create)
        Log.d(TAG, info)
        addTextToList(info)

        val status = getString(R.string.activity_c) + getString(R.string.created)
        updateStatus(status)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) {
            return
        }

        if (requestCode == REQUEST_CODE_DIALOG) {
            val isButtonClearPressed =
                data?.getBooleanExtra(EXTRA_IS_BUTTON_CLEAR_PRESSED, false) ?: false
            if (isButtonClearPressed) {
                LogViewModel.lifecycleMethodListContent = ""
                lifecycleMethodListContentTextView.text = ""
            }
        }
    }

    override fun onStart() {
        super.onStart()

        val info = getString(R.string.activity_c) + getString(R.string.on_start)
        Log.d(TAG, info)
        addTextToList(info)

        val status = getString(R.string.activity_c) + getString(R.string.started)
        updateStatus(status)
    }

    override fun onResume() {
        super.onResume()

        val info = getString(R.string.activity_c) + getString(R.string.on_resume)
        Log.d(TAG, info)
        addTextToList(info)

        val status = getString(R.string.activity_c) + getString(R.string.resumed)
        updateStatus(status)

        startAButton = findViewById(R.id.start_a_button)
        startAButton.setOnClickListener {
            val intent = Intent(this, A::class.java)
            startActivity(intent)
        }

        startBButton = findViewById(R.id.start_b_button)
        startBButton.setOnClickListener {
            val intent = Intent(this, B::class.java)
            startActivity(intent)
        }

        finishCButton = findViewById(R.id.finish_c_button)
        finishCButton.setOnClickListener {
            finish()
        }

        dialogButton = findViewById(R.id.dialog_button)
        dialogButton.setOnClickListener {
            val intent = Intent(this, D::class.java)
            startActivityForResult(intent, 0)
        }
    }

    override fun onPostResume() {
        super.onPostResume()
        Handler().postDelayed({
            lifecycleMethodListContentTextView.text = LogViewModel.lifecycleMethodListContent
            activityStatusContentTextView.text = LogViewModel.activityStatusContent
        }, 1000)
    }

    override fun onPause() {
        super.onPause()

        val info = getString(R.string.activity_c) + getString(R.string.on_pause)
        Log.d(TAG, info)
        addTextToList(info)

        val status = getString(R.string.activity_c) + getString(R.string.paused)
        updateStatus(status)
    }

    override fun onStop() {
        super.onStop()

        val info = getString(R.string.activity_c) + getString(R.string.on_stop)
        Log.d(TAG, info)
        addTextToList(info)

        val status = getString(R.string.activity_c) + getString(R.string.stopped)
        updateStatus(status)
    }

    override fun onDestroy() {
        super.onDestroy()

        val info = getString(R.string.activity_c) + getString(R.string.on_destroy)
        Log.d(TAG, info)
        addTextToList(info)

        val status = getString(R.string.activity_c) + getString(R.string.destroyed)
        updateStatus(status)
    }

    override fun onRestart() {
        super.onRestart()

        val info = getString(R.string.activity_c) + getString(R.string.on_restart)
        Log.d(TAG, info)
        addTextToList(info)

        val status = getString(R.string.activity_c) + getString(R.string.restarted)
        updateStatus(status)
    }

    private fun addTextToList(nextLine: String) {
        lifecycleMethodListContentTextView = findViewById(R.id.lifecycle_method_list_content)
        var origin = LogViewModel.lifecycleMethodListContent
        if (origin != "") {
            origin = "\n" + origin
        }
        val current = nextLine + origin
        lifecycleMethodListContentTextView.text = current
        LogViewModel.lifecycleMethodListContent = current
    }

    private fun updateStatus(status: String) {
        activityStatusContentTextView = findViewById(R.id.activity_status_content)
        LogViewModel.activityStatus[2] = status
        val array = LogViewModel.activityStatus
        var concat = status
        if (array[1] != "") {
            concat = array[1] + "\n" + concat
        }

        if (array[0] != "") {
            concat = array[0] + "\n" + concat
        }
        activityStatusContentTextView.text = concat
        LogViewModel.activityStatusContent = concat
    }
}