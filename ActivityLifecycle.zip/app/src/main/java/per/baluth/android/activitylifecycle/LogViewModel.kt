package per.baluth.android.activitylifecycle

import androidx.lifecycle.ViewModel
import android.util.Log

private const val TAG = "LogViewModel"

class LogViewModel : ViewModel() {

    init {
        Log.d(TAG, "LogViewModel instance created.")
    }

    companion object {
        var lifecycleMethodListContent: String = ""

        var activityStatus: Array<String> = Array(3) { "" }

        var activityStatusContent: String = ""
    }

    override fun onCleared() {
        super.onCleared()
        Log.d(TAG, "LogViewModel instance about to be destroyed.")
    }
}