package per.baluth.android.activitylifecycle

import android.app.AlertDialog
import android.app.Dialog
import android.content.Context
import android.content.DialogInterface
import android.os.Bundle
import androidx.fragment.app.DialogFragment

class SimpleDialogFragment : DialogFragment() {
    private lateinit var listener: SimpleDialogListener

    interface SimpleDialogListener {
        fun onDialogPositiveClick(dialog: DialogFragment)
        fun onDialogNeutralClick(dialog: DialogFragment)
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)

        try {
            listener = context as SimpleDialogListener
        } catch (e: ClassCastException) {
            throw ClassCastException(("$context must implement SimpleDialogListener"))
        }
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        return activity?.let {
            val builder = AlertDialog.Builder(it)

            builder.setMessage(R.string.simple_dialog)
                .setNeutralButton(R.string.new_activity,
                    DialogInterface.OnClickListener { _, _ ->
                        listener.onDialogNeutralClick(this)
                    })
                .setPositiveButton(
                    R.string.clear,
                    DialogInterface.OnClickListener { _, _ ->
                        listener.onDialogPositiveClick(this)
                    })
                .setNegativeButton(
                    R.string.close
                ) { _, _ -> }
            builder.create()
        } ?: throw IllegalStateException("Activity cannot be null")
    }
}