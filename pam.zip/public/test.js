a = [1, 2, 3]
console.log(typeof a)