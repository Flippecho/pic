const PCBState = {CREATE: 0, ACTIVE_READY: 1, STATIC_READY: 2, RUNNING: 3, SUSPENDING: 4, EXIT: 5}
const Property = {INDEPENDENT: 0, SYNCHRONIZED: 1}
const MemoryBlockState = {UNASSIGNED: 0, ASSIGNED: 1, OS_ASSIGNED: 2}

// insert function implement
Array.prototype.insert = function (index, item) {
    this.splice(index, 0, item);
};

// removeItem function implement
Array.prototype.removeItem = function (item) {
    this.splice(this.indexOf(item), 1)
}

// sum function implement
Array.prototype.sum = function () {
    return this.reduce(function (acr, cur) {
        return acr + cur;
    });
}

// count function implement
Array.prototype.count = function () {
    let countNum = 0
    for (let item of this) {
        countNum += item.length
    }
    return countNum
}

function sortPriorityArray(array) {
    array.sort(function (first, second) {
        return second[1] - first[1];
    });

    let sortedList = []

    for (let item of array) {
        sortedList.push(item[0])
    }
    return sortedList
}

class PCB {
    constructor(pid, time, memory, priority, property, precursorList, state = PCBState.CREATE) {
        this.pid = pid
        this.time = time
        this.memory = memory
        this.priority = priority
        this.property = property
        this.precursorList = precursorList
        this.state = state
        this.precursorListCopy = [].concat(precursorList)
        this.successorList = []
        this.successorListCopy = []
    }

    getPID() {
        return this.pid
    }

    getTime() {
        return this.time
    }

    getMemory() {
        return this.memory
    }

    getPriority() {
        return this.priority
    }

    getProperty() {
        return this.property
    }

    getPrecursorList() {
        return this.precursorList
    }

    getPrecursorListCopy() {
        return this.precursorListCopy
    }

    removeFromPrecursorList(pid_to_remove) {
        this.precursorList.removeItem(pid_to_remove)
        // those who have neither precursor nor successor are independent
        if (this.precursorList.length === 0 && this.successorList.length === 0) {
            this.property = Property.INDEPENDENT
        }
    }

    getState() {
        return this.state
    }

    setState(state) {
        this.state = state
    }

    getSuccessorList() {
        return this.successorList
    }

    getSuccessorListCopy() {
        return this.successorListCopy
    }

    addToSuccessorList(pid_to_add) {
        this.successorList.push(pid_to_add)
        this.successorListCopy.push(pid_to_add)
        // those who have successors are synchronized
        this.property = Property.SYNCHRONIZED
    }

    removeFromSuccessorList(pid_to_remove) {
        this.successorList.removeItem(pid_to_remove)
        // those who have neither precursor nor successor are independent
        if (this.precursorList.length === 0 && this.successorList.length === 0) {
            this.property = Property.INDEPENDENT
        }
    }

    process() {
        this.time--
        this.priority--
        if (this.time === 0) {
            this.setState(PCBState.EXIT)
        } else {
            this.setState(PCBState.RUNNING)
        }
    }
}

class PCBQueue {
    constructor() {
        this.pidList = []
        this.pcbList = []
        this.nextPID = 0
    }

    getPIDList() {
        return this.pidList
    }

    getPCBList() {
        return this.pcbList
    }

    getNextPid() {
        return this.nextPID
    }

    getPCBByPID(pid) {
        return this.pcbList[pid]
    }

    appendPCB(pcb) {
        this.pidList.push(pcb.getPID())
        this.pcbList.push(pcb)
        this.nextPID++
        for (let pid of pcb.getPrecursorList()) {
            // add pid of successor to precursor found by pid
            this.getPCBByPID(pid).addToSuccessorList(pcb.getPID())
        }
    }
}

class BackupQueue {
    constructor() {
        this.backupList = []
    }

    getBackupList() {
        return this.backupList
    }

    appendPCB(pcb_queue, pcb) {
        this.backupList.push(pcb.getPID())
        pcb.setState(PCBState.STATIC_READY)
    }

    removePCB(pcb) {
        this.backupList.removeItem(pcb.getPID())
    }

    autoMoveToProcessor(pcb_queue, main_memory, processor) {
        let backupListCopy = [].concat(this.backupList)
        for (let pid of backupListCopy) {
            let pcb = pcb_queue.getPCBByPID(pid)
            let [isAssignable, partitionNum] = main_memory.checkAssignable(pcb, processor)
            if (isAssignable) {
                main_memory.insertPCB(pcb_queue, pcb, partitionNum)
                processor.dispatchPCB(main_memory.sortedList)
                this.removePCB(pcb)
            } else {
                return false
            }
        }
        return true
    }
}

class HangingQueue {
    constructor() {
        this.hangingList = []
    }

    getHangingList() {
        return this.hangingList
    }

    appendPCB(pcb) {
        this.hangingList.push(pcb.getPID())
        pcb.setState(PCBState.SUSPENDING)
    }

    removePCB(pcb) {
        this.hangingList.removeItem(pcb.getPID())
    }
}

class MainMemory {
    constructor(Config) {
        this.sortedList = []
        // memory blocks are represented by an array like [pid, start, length, state]
        // -1 stands for memory reserved by OS, -2 stands for memory unassigned
        this.memoryList = [
            [-1, 0, Config.OSMemory, MemoryBlockState.OS_ASSIGNED],
            [-2, Config.OSMemory, Config.Memory - Config.OSMemory, MemoryBlockState.UNASSIGNED]
        ]
        this.Config = Config
    }

    getMemory() {
        return this.memoryList
    }

    checkAssignable(pcb, processor) {
        // processor seats not enough
        if (this.Config.ProcessorSeatNum * this.Config.ProcessorNum <= processor.processorPCBList.count()) {
            return [false, -2]
        }
        for (let i = 1; i < this.memoryList.length; i++) {
            let memoryBlock = this.memoryList[i]
            if (memoryBlock[3] === MemoryBlockState.UNASSIGNED && memoryBlock[2] >= pcb.getMemory()) {
                // free memory block found
                return [true, i]
            }
        }
        // mainMemory space not enough
        return [false, -1]
    }

    insertPCB(pcb_queue, pcb, memoryBlockNum) {
        let partition = this.memoryList[memoryBlockNum]
        let pcb_memory = pcb.getMemory()
        let pid = pcb.getPID()
        this.sortedList.push(pid)
        pcb.setState(PCBState.ACTIVE_READY)
        if (partition[2] === pcb_memory) {
            partition[0] = pid
            partition[3] = MemoryBlockState.ASSIGNED
        } else {
            this.memoryList.insert(memoryBlockNum + 1,
                [-2, partition[1] + pcb_memory, partition[2] - pcb_memory, MemoryBlockState.UNASSIGNED])
            partition[0] = pid
            partition[2] = pcb_memory
            partition[3] = MemoryBlockState.ASSIGNED
        }
        this.autoSortByPriority(pcb_queue)
    }

    removePCB(pcb) {
        let memoryBlockNum = 0
        let pid = pcb.getPID()
        for (let i = 1; i < this.memoryList.length; i++) {
            if (this.memoryList[i][0] === pid) {
                memoryBlockNum = i
            }
        }
        this.sortedList.removeItem(pid)
        this.memoryList[memoryBlockNum][0] = -2
        this.memoryList[memoryBlockNum][3] = MemoryBlockState.UNASSIGNED
        this.mergeMemory()
    }

    mergeMemory() {
        let flag = false
        let memoryBlockToMergeList = []
        for (let i = 1; i < this.memoryList.length; i++) {
            let memoryBlock = this.memoryList[i]
            let pid = memoryBlock[0]
            if (pid === -2) {
                if (!flag) {
                    flag = true
                } else {
                    memoryBlockToMergeList.push(i)
                }
            } else {
                flag = false
            }
        }
        if (memoryBlockToMergeList.length > 0) {
            let beginMemoryBlockNum = memoryBlockToMergeList[0] - 1
            for (let partition of memoryBlockToMergeList.reverse()) {
                let memoryBlockToMerge = this.memoryList[partition]
                this.memoryList.splice(partition, 1);
                this.memoryList[beginMemoryBlockNum][2] += memoryBlockToMerge[2]
            }
        }
    }

    autoSortByPriority(pcb_queue) {
        let freePIDArray = [], syncPIDArray = []
        for (let pid of this.sortedList) {
            let pcb = pcb_queue.getPCBByPID(pid)
            if (pcb.getPrecursorList().length === 0) {
                freePIDArray.push([pid, pcb.getPriority()])
            } else {
                syncPIDArray.push([pid, pcb.getPriority()])
            }
        }

        let sortedFreeList = sortPriorityArray(freePIDArray)
        let sortedSyncList = sortPriorityArray(syncPIDArray)
        this.sortedList = sortedFreeList.concat(sortedSyncList)
    }
}

class Processor {
    constructor(Config) {
        this.processorNum = Config.ProcessorNum
        this.processorPCBList = []
        for (let i = 0; i < this.processorNum; i++) {
            this.processorPCBList.push([])
        }
    }

    getProcessorPCBList() {
        return this.processorPCBList
    }

    removePCB(pcb) {
        let pid = pcb.getPID()
        for (let i = 0; i < this.processorNum; i++) {
            let index = this.processorPCBList[i].indexOf(pid)
            if (index !== -1) {
                this.processorPCBList[i].splice(index, 1)
                return true
            }
        }
        return false
    }

    checkProcessable(pcb_queue) {
        for (let processor of this.processorPCBList) {
            for (let pid of processor) {
                let pcb = pcb_queue.getPCBByPID(pid)
                if (pcb.getPrecursorList().length === 0) {
                    return true
                }
            }
        }
        return false
    }

    process(pcb_queue, main_memory, backup_queue) {
        for (let i = 0; i < this.processorNum; i++) {
            let processor = this.processorPCBList[i]
            if (processor.length > 0) {
                let pcb_to_process = pcb_queue.getPCBByPID(processor[0])
                if (pcb_to_process.getPrecursorList().length === 0) {
                    pcb_to_process.process();
                    if (pcb_to_process.getState() === PCBState.EXIT) {
                        for (let pid of pcb_to_process.getSuccessorList()) {
                            let pcb = pcb_queue.getPCBByPID(pid)
                            pcb.removeFromPrecursorList(pcb_to_process.getPID())
                        }
                        for (let pid of pcb_to_process.getPrecursorListCopy()) {
                            let pcb = pcb_queue.getPCBByPID(pid)
                            pcb.removeFromSuccessorList(pcb_to_process.getPID())
                        }
                        processor.splice(0, 1)
                        main_memory.removePCB(pcb_to_process)
                        backup_queue.autoMoveToProcessor(pcb_queue, main_memory, this)
                    }
                    this.autoSortByPriority(pcb_queue)
                }
            }
        }
    }

    autoSortByPriority(pcb_queue) {
        let freePIDArray = [], syncPIDArray = []
        for (let processor of this.processorPCBList) {
            for (let pid of processor) {
                let pcb = pcb_queue.getPCBByPID(pid)
                if (pcb.getPrecursorList().length === 0) {
                    freePIDArray.push([pid, pcb.getPriority()])
                } else {
                    syncPIDArray.push([pid, pcb.getPriority()])
                }
            }
        }

        let sortedFreeList = sortPriorityArray(freePIDArray)
        let sortedSyncList = sortPriorityArray(syncPIDArray)
        let sortedList = sortedFreeList.concat(sortedSyncList)
        this.dispatchPCB(sortedList)
    }

    dispatchPCB(sorted_list) {
        this.processorPCBList = []
        for (let i = 0; i < this.processorNum; i++) {
            this.processorPCBList.push([])
        }
        let processorID = 0
        for (let pid of sorted_list) {
            this.processorPCBList[processorID].push(pid)
            processorID = (processorID + 1) % this.processorNum
        }
    }
}