package per.baluth.web.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;
import per.baluth.web.utils.DBHelper;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Objects;

@WebServlet(urlPatterns = "/avatar")
@MultipartConfig
public class Avatar extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("image/*");
        String username = (String) request.getSession().getAttribute("username");
        String filepath = request.getServletContext().getRealPath("/WEB-INF/avatar/");
        String filename = "default.png";
        if (username != null) {
            String suffix = DBHelper.getSuffix(username);
            if (!Objects.equals(suffix, "null")) {
                filename = username + "." + suffix;
            }
        }
        Files.copy(Paths.get(filepath, filename), response.getOutputStream());
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        String username = (String) request.getSession().getAttribute("username");
        String filepath = request.getServletContext().getRealPath("/WEB-INF/avatar/");
        String suffix = request.getParameter("suffix");
        String filename = username + "." + suffix;

        DBHelper.setSuffix(username, suffix);

        Part part = request.getPart("avatar");
        part.write(filepath + filename);
    }
}
