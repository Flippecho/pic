package per.baluth.web.servlet;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import per.baluth.web.utils.DBHelper;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;

@WebServlet(urlPatterns = "/resume")
public class ResumeServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("application/json;charset=UTF-8");

        PrintWriter pw = response.getWriter();
        String username = (String) request.getSession().getAttribute("username");
        String content = username == null ? "PLEASE LOGIN FIRST" : DBHelper.getContent(username);

        pw.write(content);
        pw.flush();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("text/html;charset=utf-8");
        PrintWriter pw = response.getWriter();
        String username = (String) request.getSession().getAttribute("username");

        if (username == null) {
            pw.write("FAILED");
        } else {
            BufferedReader br = new BufferedReader(new InputStreamReader(request.getInputStream()));
            StringBuilder sb = new StringBuilder();
            String line;

            while ((line = br.readLine()) != null) {
                sb.append(line);
            }

            DBHelper.updateContent(username, sb.toString());
            pw.write("SUCCEED");
        }

        pw.flush();
    }
}
