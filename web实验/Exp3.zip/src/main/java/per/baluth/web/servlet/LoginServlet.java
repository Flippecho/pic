package per.baluth.web.servlet;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import per.baluth.web.utils.DBHelper;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Objects;

@WebServlet(urlPatterns = "/login")
public class LoginServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("text/html;charset=utf-8");
        PrintWriter pw = response.getWriter();

        String username = request.getParameter("username").toLowerCase();
        String password = request.getParameter("password");
        String psw = DBHelper.getPassword(username);

        if (Objects.equals(psw, "")) {
            DBHelper.addUser(username, password);
            request.getSession().setAttribute("username", username);
            pw.write("created");
        } else if (Objects.equals(psw, password)) {
            request.getSession().setAttribute("username", username);
            String content = DBHelper.getContent(username);
            if (Objects.equals(content, "")) {
                pw.write("succeed but data not found");
            } else {
                pw.write("succeed and data found");
            }
        } else {
            pw.write("failed");
        }

        pw.flush();
    }
}
