package per.baluth.web.servlet;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import per.baluth.web.utils.DBHelper;

import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(urlPatterns = "/page-view")
public class PageViewServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {

        response.setContentType("text/html;charset=utf-8");
        PrintWriter pw = response.getWriter();

        pw.write(String.valueOf(DBHelper.getPV()));
        pw.flush();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("text/html;charset=utf-8");
        PrintWriter pw = response.getWriter();

        DBHelper.increasePV();
        pw.write(String.valueOf(DBHelper.getPV()));
        pw.flush();
    }
}
