const avatar = document.querySelector(".basic-info .avatar")
const avatarInput = document.querySelector("#avatar-input")
let file

function makeAvatarMutable() {
    avatar.title = "单击或拖拽图片至此来修改头像"
    avatar.onclick = () => {
        avatarInput.click()
        avatarInput.onchange = () => {
            file = avatarInput.files[0]
            avatarInput.value = ""
            if (file.type.indexOf("image") === 0) {
                avatar.src = window.URL.createObjectURL(file)
                hasImageChanged = true
            } else {
                alert("不受支持的图片类型，请重新选择！")
            }
        }
    }
}

function makeAvatarImmutable() {
    avatar.title = ""
    avatar.onclick = EMPTY_FUNCTION
}

function cropImage(image) {
    // const avatarToolsContainer = document.querySelector("#avatar-tools-container")
    // avatarToolsContainer.style.display = "block";
    return image
}

function compressImage(image) {
    return image
}

function uploadImage() {
    const reader = new FileReader()

    reader.readAsArrayBuffer(file)

    reader.onload = (ev) => {
        const blob = typeof ev.target.result === "object" ? new Blob([ev.target.result]) : ev.target.result
        const suffix = file.name.substring(file.name.lastIndexOf('.') + 1)
        const formData = new FormData()
        formData.append("avatar", blob)

        const Http = new XMLHttpRequest()
        const url = "http://localhost:8080/avatar?suffix=" + suffix
        Http.open("POST", url, true)
        Http.send(formData)
    }
}