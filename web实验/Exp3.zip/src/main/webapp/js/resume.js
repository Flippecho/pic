function loadResume() {
    if (getObject(RESUME) != null) {
        applyResumeObj(getObject(RESUME))
    } else {
        putObject(RESUME, getResumeObj())
    }
}

function bindEditableCheck() {
    for (const element of document.querySelectorAll(".editable")) {
        element.addEventListener("blur", () => {
            if (element.innerText.trim().length === 0) {
                element.innerText = element.getAttribute("data-placeholder")
                if (!element.classList.contains("highlight")) {
                    element.style.color = "white"
                    element.style.background = "#3498db"
                }
            }
        })

        element.addEventListener("click", () => {
            if (!element.classList.contains("highlight")) {
                element.style.background = "none"
            }
            if (element.innerText === element.getAttribute("data-placeholder")) {
                element.innerText = ""
                element.style.color = "black"
            }
        })
    }
}

function fetchResume() {
    if (!getBoolean(hasRemoteResume)) return

    const Http = new XMLHttpRequest()

    Http.open("GET", "http://localhost:8080/resume", true)
    Http.setRequestHeader("content-type", "application/x-www-form-urlencoded")
    Http.send()

    Http.onreadystatechange = () => {
        if (Http.readyState === Http.DONE && Http.status === 200) {
            applyResumeObj(JSON.parse(Http.response))
            putObject(RESUME, JSON.parse(Http.response))
            hintInfo.innerText = "读档成功 : ）"
        }
    }
}

function uploadResume() {
    if (hasImageChanged) {
        hasImageChanged = false
        uploadImage()
    }

    const Http = new XMLHttpRequest()

    Http.open("POST", "http://localhost:8080/resume", true)
    Http.setRequestHeader("content-type", "application/x-www-form-urlencoded")
    Http.send(JSON.stringify(getResumeObj()))

    Http.onreadystatechange = () => {
        if (Http.readyState === Http.DONE && Http.status === 200) {
            hintInfo.innerText = "存档成功 : ）"
            uploadButton.style.cursor = "default"
            uploadButton.title = "从服务器下载"
        }
    }
}

function restoreResume() {
    applyResumeObj(getObject(TEMPLATE))
    hintInfo.innerText = "从头开始吧 : ）"
}

function applyResumeObj(resume) {
    setBasicInfo(resume.basicInfo)
    setEducation(resume.education)
    setWork(resume.work)
    setProject(resume.project)
    setAssessment(resume.assessment)

    const editableList = document.querySelectorAll(".editable")
    for (const item of editableList) {
        item.style.cssText += "user-modify: read-write-plaintext-only;"
        item.style.cssText += "-webkit-user-modify: read-write-plaintext-only;"
    }

    bindEditableCheck()
}

function getResumeObj() {
    const resumeObj = {}

    resumeObj.basicInfo = getBasicInfo()
    resumeObj.education = getEducation()
    resumeObj.work = getWork()
    resumeObj.project = getProject()
    resumeObj.assessment = getAssessment()

    return resumeObj
}

function getBasicInfo() {
    const basicInfoObj = {}

    basicInfoObj.name = document.querySelector(".name-and-position .name").innerText
    basicInfoObj.position = document.querySelector(".name-and-position .position .highlight").innerText
    basicInfoObj.contacts = getContacts()

    return basicInfoObj
}

function getContacts() {
    const contacts = document.querySelectorAll(".contact-me .editable")
    const contactObj = {}

    contactObj.telephone = contacts[0].innerText
    contactObj.email = contacts[1].innerText
    contactObj.github = contacts[2].innerText
    contactObj.wechat = contacts[3].innerText

    return contactObj
}

function getEducation() {
    const educationArray = []
    const experiences = document.querySelectorAll(".education-experience-item")

    for (const experience of experiences) {
        educationArray.push(getEducationExperience(experience))
    }

    return educationArray
}

function getEducationExperience(experience) {
    const experienceObj = {}
    const TPC = experience.querySelectorAll(".editable")

    experienceObj.start = TPC[0].innerText
    experienceObj.end = TPC[1].innerText
    experienceObj.school = TPC[2].innerText
    experienceObj.major = TPC[3].innerText
    experienceObj.courses = TPC[4].innerText

    return experienceObj
}

function getWork() {
    const workArray = []
    const experiences = document.querySelectorAll(".work-experience-item")

    for (const experience of experiences) {
        workArray.push(getWorkExperience(experience))
    }

    return workArray
}

function getWorkExperience(experience) {
    const experienceObj = {}
    const contentArray = []
    const TPC = experience.querySelectorAll(".three-part-container .editable")
    const content = experience.querySelectorAll("ul .editable")

    experienceObj.start = TPC[0].innerText
    experienceObj.end = TPC[1].innerText
    experienceObj.company = TPC[2].innerText
    experienceObj.position = TPC[3].innerText

    for (const item of content) {
        contentArray.push(item.innerText)
    }

    experienceObj.content = contentArray

    return experienceObj
}

function getProject() {
    const projectArray = []
    const experiences = document.querySelectorAll(".project-experience-item")

    for (const experience of experiences) {
        projectArray.push(getProjectExperience(experience))
    }

    return projectArray
}

function getProjectExperience(experience) {
    const experienceObj = {}
    const contentArray = []
    const TPC = experience.querySelectorAll(".three-part-container .editable")
    const PEC = experience.querySelectorAll(".project-experience-content .editable")

    experienceObj.start = TPC[0].innerText
    experienceObj.end = TPC[1].innerText
    experienceObj.project = TPC[2].innerText

    for (const item of PEC) {
        contentArray.push(item.innerText)
    }

    experienceObj.content = contentArray

    return experienceObj
}

function getAssessment() {
    const assessmentArray = []
    const content = document.querySelectorAll(".self-assessment-content .editable")

    for (const item of content) {
        assessmentArray.push(item.innerText)
    }

    return assessmentArray
}

function setBasicInfo(basicInfoObj) {
    document.querySelector(".avatar").src = "./avatar"
    document.querySelector(".name-and-position .name").innerText = basicInfoObj.name
    document.querySelector(".name-and-position .position .highlight").innerText = basicInfoObj.position
    setContacts(basicInfoObj.contacts)
}

function setContacts(contactObj) {
    const contactArray = document.querySelectorAll(".contact-me .editable")

    contactArray[0].innerText = contactObj.telephone
    contactArray[1].innerText = contactObj.email
    contactArray[2].innerText = contactObj.github
    contactArray[3].innerText = contactObj.wechat
}

function setEducation(educationArray) {
    const parent = document.querySelector(".education-experience-container .experience-items-container")
    const oldArray = parent.querySelectorAll(".education-experience-item")

    for (const item of oldArray) {
        parent.removeChild(item)
    }

    for (const item of educationArray) {
        parent.append(cloneEducationExperience(item))
    }
}

function cloneEducationExperience(educationExperienceObj) {
    const template = document.querySelector("#education-experience")
    const clone = document.importNode(template.content, true)
    const TPC = clone.querySelectorAll(".editable")

    TPC[0].innerText = educationExperienceObj.start
    TPC[1].innerText = educationExperienceObj.end
    TPC[2].innerText = educationExperienceObj.school
    TPC[3].innerText = educationExperienceObj.major
    TPC[4].innerText = educationExperienceObj.courses

    return clone
}

function setWork(workArray) {
    const parent = document.querySelector(".work-experience-container .experience-items-container")
    const oldArray = parent.querySelectorAll(".work-experience-item")

    for (const item of oldArray) {
        parent.removeChild(item)
    }

    for (const item of workArray) {
        parent.append(cloneWorkExperience(item))
    }
}

function cloneWorkExperience(workExperienceObj) {
    const template = document.querySelector("#work-experience")
    const clone = document.importNode(template.content, true)
    const TPC = clone.querySelectorAll(".three-part-container .editable")
    const parent = clone.querySelector("ul")

    TPC[0].innerText = workExperienceObj.start
    TPC[1].innerText = workExperienceObj.end
    TPC[2].innerText = workExperienceObj.company
    TPC[3].innerText = workExperienceObj.position

    for (const item of workExperienceObj.content) {
        parent.append(cloneWorkExperienceItem(item))
    }

    return clone
}

function cloneWorkExperienceItem(item) {
    const template = document.querySelector("#work-item")
    const clone = document.importNode(template.content, true)

    clone.querySelector("li").innerText = item

    return clone
}

function setProject(projectArray) {
    const parent = document.querySelector(".project-experience-container .experience-items-container")
    const oldArray = parent.querySelectorAll(".project-experience-item")

    for (const item of oldArray) {
        parent.removeChild(item)
    }

    for (const item of projectArray) {
        parent.append(cloneProjectExperience(item))
    }
}

function cloneProjectExperience(projectExperienceObj) {
    const template = document.querySelector("#project-experience")
    const clone = document.importNode(template.content, true)
    const TPC = clone.querySelectorAll(".three-part-container .editable")
    const parent = clone.querySelector(".project-experience-content")

    TPC[0].innerText = projectExperienceObj.start
    TPC[1].innerText = projectExperienceObj.end
    TPC[2].innerText = projectExperienceObj.project

    for (const item of projectExperienceObj.content) {
        parent.append(cloneProjectExperienceItem(item))
    }

    return clone
}

function cloneProjectExperienceItem(item) {
    const template = document.querySelector("#project-item")
    const clone = document.importNode(template.content, true)

    clone.querySelector("p").innerText = item

    return clone
}

function setAssessment(assessmentArray) {
    const parent = document.querySelector(".self-assessment-content")
    const oldArray = parent.querySelectorAll(".editable")

    for (const item of oldArray) {
        parent.removeChild(item)
    }

    for (const item of assessmentArray) {
        parent.append(cloneAssessmentItem(item))
    }
}

function cloneAssessmentItem(item) {
    const template = document.querySelector("#assessment-item")
    const clone = document.importNode(template.content, true)

    clone.querySelector("p").innerText = item

    return clone
}