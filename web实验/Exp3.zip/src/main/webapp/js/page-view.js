function startPageViewService() {
    updatePageView()
    setInterval(getPageView, 3000)
}

function getPageView() {
    const Http = new XMLHttpRequest()

    Http.open("GET", "http://localhost:8080/page-view")
    Http.send()

    Http.onreadystatechange = function () {
        if (Http.readyState === Http.DONE && Http.status === 200) {
            document.querySelector(".pv-text").innerText = Http.responseText
        }
    }
}

function updatePageView() {
    // if (getBoolean(pvIncreased)) {
    //     getPageView()
    //     return
    // }

    const Http = new XMLHttpRequest()

    Http.open("POST", "http://localhost:8080/page-view", true)
    Http.setRequestHeader("content-type", "application/x-www-form-urlencoded")
    Http.send()

    Http.onreadystatechange = function () {
        if (Http.readyState === Http.DONE && Http.status === 200) {
            // console.log(Http.responseText)
            document.querySelector(".pv-text").innerText = Http.responseText
            // putBoolean(pvIncreased, true)
        }
    }
}