// shared const variables
const isLoginPanelShown = "isLoginPanelShown"
const isEditorPanelShown = "isEditorPanelShown"
const isLoggedIn = "isLoggedIn"
const hasRemoteResume = "hasRemoteResume"
const USERNAME = "USERNAME"
const RESUME = "RESUME"
const TEMPLATE = "TEMPLATE"
const pvIncreased = "pvIncreased"

// shared flags
let hasImageChanged = false

// shared functions
function EMPTY_FUNCTION() {
}

function getString(key) {
    return sessionStorage.getItem(key)
}

function putString(key, value) {
    sessionStorage.setItem(key, value)
}

function getBoolean(key) {
    return sessionStorage.getItem(key) === "true"
}
function putBoolean(key, value) {
    sessionStorage.setItem(key, value.toString())
}
function flipBoolean(key) {
    putBoolean(key, !getBoolean(key))
}

function getObject(key) {
    return JSON.parse(sessionStorage.getItem(key))
}
function putObject(key, value) {
    sessionStorage.setItem(key, JSON.stringify(value))
}