const HALF_MARGIN_COLLAPSED = "calc((100vh - 14rem) / 2)"
const HALF_MARGIN_NOT_COLLAPSED = "calc((100vh - 22rem) / 2)"

const weatherContainer = document.querySelector("#weather-container")
const controlPanel = document.querySelector("#control-panel")
const modeDiv = controlPanel.querySelector(".pv-and-mode .mode")
const modeIcon = modeDiv.querySelector("img")
const accountDiv = controlPanel.querySelector(".pv-and-mode .account")
const loginPanel = controlPanel.querySelector(".login-panel")
const editorPanel = controlPanel.querySelector(".editor-panel")
const hintInfo = controlPanel.querySelector(".hint-info")
const fetchButton = editorPanel.querySelector(".fetch")
const uploadButton = editorPanel.querySelector(".upload")
const discardButton = editorPanel.querySelector(".discard")
const inputs = loginPanel.querySelectorAll(".login-panel .left input")
const loginButton = loginPanel.querySelector(".login-and-editor .login-panel .right button")

modeDiv.onclick = toggleEditorPanel
fetchButton.onclick = fetchResume
uploadButton.onclick = uploadResume
discardButton.onclick = restoreResume
accountDiv.onclick = toggleLoginPanel
loginButton.onclick = changeLoginStatus

function loadTogglePanel() {
    updatePanelLayout()

    fetchButton.style.cursor = getBoolean(hasRemoteResume) ? "default" : "not-allowed"
    fetchButton.title = getBoolean(hasRemoteResume) ? "从服务器下载" : "服务器无存档"

    if (getBoolean(isLoggedIn)) {
        loginButton.innerText = "登出"
        modeDiv.title = "单击进入编辑模式"
        modeDiv.style.cursor = "default"
        inputs[0].value = getString(USERNAME)
        inputs[1].value = "password"
        inputs[0].readOnly = true
        inputs[1].readOnly = true
    }

    if (getBoolean(isEditorPanelShown)) {
        const editableList = document.querySelectorAll(".editable")

        makeAvatarMutable()
        editorPanel.style.display = "flex"
        hintInfo.style.display = "block"
        modeIcon.src = "./icons/preview.svg"
        modeDiv.title = "单击进入只读模式"
        hintInfo.innerText = "右键进行增删移动"

        for (const item of editableList) {
            item.style.cssText += "user-modify: read-write-plaintext-only;"
            item.style.cssText += "-webkit-user-modify: read-write-plaintext-only;"
        }
    }

    if (getBoolean(isLoginPanelShown)) {
        loginPanel.style.display = "flex"
        hintInfo.style.display = "block"
        accountDiv.title = "收起面板"
        hintInfo.innerText = getBoolean(isLoggedIn) ? "登录成功" : "自动注册新账户"
    }
}

function toggleEditorPanel() {
    if (!getBoolean(isLoggedIn)) return

    const editableList = document.querySelectorAll(".editable")

    putBoolean(isLoginPanelShown, false)
    flipBoolean(isEditorPanelShown)
    updatePanelLayout()
    loginPanel.style.display = "none"
    hintInfo.innerText = "右键进行增删移动"

    if (getBoolean(isEditorPanelShown)) {
        makeAvatarMutable()
        editorPanel.style.display = "flex"
        hintInfo.style.display = "block"
        modeIcon.src = "./icons/preview.svg"
        modeDiv.title = "单击进入只读模式"

        for (const item of editableList) {
            item.style.cssText += "user-modify: read-write-plaintext-only;"
            item.style.cssText += "-webkit-user-modify: read-write-plaintext-only;"
        }
    } else {
        makeAvatarImmutable()
        editorPanel.style.display = "none"
        hintInfo.style.display = "none"
        modeIcon.src = "./icons/edit.svg"
        modeDiv.title = "单击进入编辑模式"

        for (const item of editableList) {
            item.style.cssText -= "-webkit-user-modify: read-write-plaintext-only;"
            item.style.cssText -= "user-modify: read-write-plaintext-only;"
        }
    }
}

function toggleLoginPanel() {
    const editableList = document.querySelectorAll(".editable")

    putBoolean(isEditorPanelShown, false)
    flipBoolean(isLoginPanelShown)
    updatePanelLayout()

    makeAvatarImmutable()
    editorPanel.style.display = "none"
    modeIcon.src = "./icons/edit.svg"
    modeDiv.title = getBoolean(isLoggedIn) ? "单击进入编辑模式" : "登录后方可编辑"
    hintInfo.innerText = getBoolean(isLoggedIn) ? "登录成功" : "自动注册新账户"

    for (const item of editableList) {
        item.style.cssText -= "-webkit-user-modify: read-write-plaintext-only;"
        item.style.cssText -= "user-modify: read-write-plaintext-only;"
    }

    if (getBoolean(isLoginPanelShown)) {
        loginPanel.style.display = "flex"
        hintInfo.style.display = "block"
        accountDiv.title = "收起面板"
    } else {
        loginPanel.style.display = "none"
        hintInfo.style.display = "none"
        accountDiv.title = getBoolean(isLoggedIn) ? "账号" : "登录"
    }
}

function updatePanelLayout() {
    const isCollapsed = !getBoolean(isEditorPanelShown) && !getBoolean(isLoginPanelShown)
    const halfMargin = isCollapsed ? HALF_MARGIN_COLLAPSED : HALF_MARGIN_NOT_COLLAPSED
    weatherContainer.style.top = halfMargin
    controlPanel.style.bottom = halfMargin
    controlPanel.style.height = isCollapsed ? "3rem" : "11rem"
}

function changeLoginStatus() {
    if (getBoolean(isLoggedIn)) {
        logout()
    } else {
        login()
    }
}

function login() {
    const username = inputs[0].value.replace(/\s*/g, "")
    const password = inputs[1].value.replace(/\s*/g, "")

    const Http = new XMLHttpRequest()

    if (username === "") {
        hintInfo.innerText = "账号不能为空！"
    } else if (password === "") {
        hintInfo.innerText = "密码不能为空！"
    } else {
        const url = "http://localhost:8080/login?username=" + username + "&password=" + password
        Http.open("GET", url)
        Http.send()
    }

    Http.onreadystatechange = () => {
        if (Http.readyState === Http.DONE && Http.status === 200) {
            if (getObject(TEMPLATE) == null) {
                putObject(TEMPLATE, getResumeObj())
            }

            putBoolean(isLoggedIn, Http.response !== "failed")
            putString(USERNAME, username)
            if (getBoolean(isLoggedIn)) {
                if (Http.response === "succeed and data found") {
                    putBoolean(hasRemoteResume, true)
                    fetchButton.style.cursor = "default"
                    fetchButton.title = "从服务器下载"
                }
                inputs[0].readOnly = true
                inputs[1].readOnly = true
                loginButton.innerText = "登出"
                hintInfo.innerText = Http.response.startsWith("succeed") ? "登录成功 : ）" : "创建成功 : ）"
                modeDiv.style.cursor = "default"
                modeDiv.title = "单击进入编辑模式"
                fetchResume()
            } else {
                hintInfo.innerText = "密码错误 : （"
                inputs[1].value = ""
            }
        }
    }
}

function logout() {
    const Http = new XMLHttpRequest()
    Http.open("GET", "http://localhost:8080/logout")
    Http.send()

    Http.onreadystatechange= () => {
        if (Http.readyState === Http.DONE && Http.status === 200) {
            inputs[0].value = ""
            inputs[1].value = ""
            inputs[0].readOnly = false
            inputs[1].readOnly = false
            loginButton.innerText = "登录"
            hintInfo.innerText = "再会 : )"
            modeDiv.style.cursor = "not-allowed"
            modeDiv.title = "登录后方可编辑"
            fetchButton.style.cursor = "not-allowed"
            fetchButton.title = "服务器无存档"
            restoreResume()
            sessionStorage.clear()
            document.querySelector(".avatar").src = "./avatar"
        }
    }
}