const contextMenu = document.querySelector("#context-menu")
const contextMenuItems = document.querySelectorAll("#context-menu .flex-container")
let targetElement, activeElement
let WCX, WCY

document.oncontextmenu = (e) => {
    contextMenu.style.display = "none"
    console.log(document.activeElement)

    activeElement = document.activeElement
    activeElement.blur()

    if (targetElement != null) {
        targetElement.style.outline = "none"
    }

    if (getBoolean(isEditorPanelShown) === false) {
        return
    }

    if (!activeElement.classList.contains("editable")) {
        return;
    }

    if (activeElement.classList.contains("removable")) {
        targetElement = activeElement
    } else if (activeElement.classList.contains("unmovable")) {
        targetElement = activeElement
    } else if (activeElement.nodeName === "P") {
        targetElement = activeElement.parentNode.parentNode
    } else {
        targetElement = activeElement.parentNode.parentNode.parentNode
    }

    updateContextMenuLayout(e)
}
document.onclick = () => {
    enableWindowScroll()
    contextMenu.style.display = "none"
    if (targetElement != null) {
        targetElement.style.outline = "none"
    }
}
window.addEventListener("scroll", () => {
    if (WCX != null && WCY != null) {
        window.scrollTo(WCX, WCY)
    }
})

function updateContextMenuLayout(e) {
    e.preventDefault()
    disableWindowScroll()

    const isFirstChild = targetElement.parentNode.firstElementChild === targetElement
    const isLastChild = targetElement.parentNode.lastElementChild === targetElement
    const isOnlyChild = isFirstChild && isLastChild
    const isUnmovable = targetElement.classList.contains("unmovable")

    contextMenuItems[0].style.display = isUnmovable || isOnlyChild ? "none" : "block"
    contextMenuItems[1].style.display = isUnmovable ? "none" : "block"
    contextMenuItems[2].style.display = isUnmovable || isFirstChild ? "none" : "block"
    contextMenuItems[3].style.display = isUnmovable || isLastChild ? "none" : "block"
    contextMenuItems[4].style.display = isUnmovable || isFirstChild ? "none" : "block"
    contextMenuItems[5].style.display = isUnmovable || isLastChild ? "none" : "block"
    contextMenuItems[6].style.display = isUnmovable ? "block" : "none"
    contextMenuItems[0].style.borderBottom = isFirstChild && isLastChild ? "#dadada 1px solid" : "none"
    contextMenuItems[2].style.borderTop = "#dadada 1px solid"
    contextMenuItems[3].style.borderTop = isFirstChild ? "#dadada 1px solid" : "none"
    contextMenuItems[3].style.borderBottom = isFirstChild ? "none" : "#dadada 1px solid"


    targetElement.style.outline = "thick double #1e2732"
    contextMenu.style.display = "block"

    const position = {}

    if (e.clientX + contextMenu.offsetWidth + 16 > window.innerWidth) {
        position.x = e.clientX - contextMenu.offsetWidth
    } else {
        position.x = e.clientX
    }

    position.top = e.clientY - contextMenu.offsetHeight / 2
    position.bottom = e.clientY + contextMenu.offsetHeight / 2

    if (position.bottom + 16 > window.innerHeight) {
        position.y = window.innerHeight - 16 - contextMenu.offsetHeight
    } else {
        position.y = Math.max(position.top, 16)
    }

    contextMenu.style.top = `${position.y}px`
    contextMenu.style.left = `${position.x}px`
}

function disableWindowScroll() {
    WCX = window.scrollX
    WCY = window.scrollY
}

function enableWindowScroll() {
    WCX = null
    WCY = null
}

// delete
contextMenuItems[0].onclick = () => {
    targetElement.remove()
}

// insert
contextMenuItems[1].onclick = () => {
    const clone = targetElement.cloneNode(true)
    clone.style.outline = "none"
    clone.addEventListener("blur", () => {
        if (clone.innerText.trim().length === 0) {
            clone.innerText = clone.getAttribute("data-placeholder")
            clone.style.color = "white"
            clone.style.background = "#3498db"
        }
    })
    clone.addEventListener("click", () => {
        if (!clone.classList.contains("highlight")) {
            clone.style.background = "none"
        }
        if (clone.innerText === clone.getAttribute("data-placeholder")) {
            clone.innerText = ""
            clone.style.color = "black"
        }
    })
    targetElement.parentNode.insertBefore(clone, targetElement)
}

// move up
contextMenuItems[2].onclick = () => {
    const previousElement = targetElement.previousElementSibling
    targetElement.parentNode.insertBefore(targetElement, previousElement)
}

// move down
contextMenuItems[3].onclick = () => {
    const nextElement = targetElement.nextElementSibling
    targetElement.parentNode.insertBefore(nextElement, targetElement)
}

// move to top
contextMenuItems[4].onclick = () => {
    const topElement = targetElement.parentNode.firstElementChild
    targetElement.parentNode.insertBefore(targetElement, topElement)
}

// move to bottom
contextMenuItems[5].onclick = () => {
    const topElement = targetElement.parentNode.firstElementChild
    targetElement.parentNode.insertBefore(targetElement, topElement.previousElementSibling)
}