const iconWeatherMap = {
    '风': ['有风', '平静', '微风', '和风', '清风', '强风/劲风', '疾风', '大风', '烈风', '风暴', '狂爆风', '飓风', '热带风暴', '龙卷风'],
    '多云': ['少云', '晴间多云', '多云'],
    '雪': ['雪', '阵雪', '小雪', '中雪', '大雪', '暴雪', '小雪-中雪', '中雪-大雪', '大雪-暴雪', '冷'],
    '雾': ['浮尘', '扬沙', '沙尘暴', '强沙尘暴', '雾', '浓雾', '强浓雾', '轻雾', '大雾', '特强浓雾'],
    '晴': ['晴', '热'],
    '雨夹雪': ['雨雪天气', '雨夹雪', '阵雨夹雪'],
    '雨': ['阵雨', '雷阵雨', '雷阵雨并伴有冰雹', '小雨', '中雨', '大雨', '暴雨', '大暴雨', '特大暴雨', '强阵雨', '强雷阵雨', '极端降雨', '毛毛雨/细雨', '雨', '小雨-中雨', '中雨-大雨', '大雨-暴雨', '暴雨-大暴雨', '大暴雨-特大暴雨', '冻雨'],
    '阴': ['阴', '霾', '中度霾', '重度霾', '严重霾', '未知']
}

const refreshButton = document.querySelector("#weather-container .bottom-right")

refreshButton.onclick = updateWeather

function startWeatherService() {
    updateWeather();
    setInterval(updateWeather, 15 * 60 * 1000);
}

function getIcon(weather) {
    for (const key in iconWeatherMap) {
        const weatherNames = iconWeatherMap[key]
        for (const index in weatherNames) {
            if (weatherNames[index] === weather) return "icons/" + key + ".svg"
        }
    }
}

function updateWeather() {
    document.getElementById("location").innerText = "地点";
    document.getElementById("temperature").innerText = "气温";
    document.getElementById("weather").innerText = "天气";

    const Http = new XMLHttpRequest();
    const url = 'https://restapi.amap.com/v3/weather/weatherInfo?city=330483&key=a4e3e20bd2c31afb56f90c848e1d70f5';
    Http.open("GET", url);
    Http.send();

    Http.onreadystatechange = () => {
        if (Http.readyState === Http.DONE && Http.status === 200) {
            let obj = JSON.parse(Http.response).lives[0];
            document.getElementById("location").innerText = obj.province + "省 " + obj.city
            document.getElementById("temperature").innerText = obj.temperature + " ℃"
            document.getElementById("weather").innerText = obj.weather
            document.getElementById("weather-image").src = getIcon(obj.weather)
            document.getElementById("weather-image").style.visibility = "visible"
        }
    }
}