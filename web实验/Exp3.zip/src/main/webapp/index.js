window.onload = () => {
    loadResume()
    loadTogglePanel()
    startPageViewService()
    startWeatherService()
}

window.onunload = () => {
    putObject(RESUME, getResumeObj())
}