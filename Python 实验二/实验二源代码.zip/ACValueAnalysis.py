# -*- coding: utf-8 -*-
import copy

import numpy as np
import pandas as pd
from PySide6.QtWidgets import QTableView
from matplotlib import pyplot as plt
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler

from PandasModel import PandasModel


def fetchOriginalData():
    airline_data = pd.read_csv("air_data.csv", encoding="gb18030")

    original_data_table = QTableView()
    original_data_table.horizontalHeader().setStretchLastSection(True)
    original_data_table.setAlternatingRowColors(True)
    original_data_table.setSelectionBehavior(QTableView.SelectRows)

    model = PandasModel(airline_data)
    original_data_table.setModel(model)

    # print("原始数据:", airline_data, sep='\n')

    return airline_data, original_data_table


def dataCleaning(airline_data):
    # 票价不为空
    exp = airline_data["SUM_YR_1"].notnull() & airline_data["SUM_YR_2"].notnull()
    # 保留满足条件的有效数据
    airline_notnull = airline_data.loc[exp, :]
    # 票价不为零
    index1 = (airline_notnull['SUM_YR_1'] != 0) & (airline_notnull['SUM_YR_2'] != 0)
    # 折扣率、飞行里程不为零
    index2 = (airline_notnull['SEG_KM_SUM'] > 0) & (airline_notnull['avg_discount'] != 0)
    # 年龄不大于 100 岁
    index3 = airline_notnull['AGE'] <= 100
    # 保留满足三个条件的正常数据
    airline = airline_notnull[index1 & index2 & index3]

    cleaned_data_table = QTableView()
    cleaned_data_table.horizontalHeader().setStretchLastSection(True)
    cleaned_data_table.setAlternatingRowColors(True)
    cleaned_data_table.setSelectionBehavior(QTableView.SelectRows)

    airline_copy = copy.deepcopy(airline)
    model = PandasModel(airline_copy)
    cleaned_data_table.setModel(model)

    # print("\n清洗后数据:", airline, sep='\n')

    return airline, cleaned_data_table


def constructModel(airline):
    # 选取需求特征
    airline_selection = airline[["FFP_DATE", "LOAD_TIME", "FLIGHT_COUNT", "LAST_TO_END", "avg_discount", "SEG_KM_SUM"]]
    # 构建L特征
    character_l = pd.to_datetime(airline_selection["LOAD_TIME"]) - pd.to_datetime(airline_selection["FFP_DATE"])
    character_l = character_l.astype("str").str.split().str[0]
    character_l = character_l.astype("int")

    # 合并特征
    airline_features = pd.concat([character_l, airline_selection.iloc[:, 2:]], axis=1)
    airline_features.columns = ['L', 'F', 'R', 'C', 'M']

    selected_data_table = QTableView()
    selected_data_table.horizontalHeader().setStretchLastSection(True)
    selected_data_table.setAlternatingRowColors(True)
    selected_data_table.setSelectionBehavior(QTableView.SelectRows)

    model = PandasModel(airline_features)
    selected_data_table.setModel(model)

    # print("\n特征值:", airline_features, sep='\n')

    # 标准化
    data = StandardScaler().fit_transform(airline_features)

    airline_features_copy = copy.deepcopy(airline_features)

    airline_features = pd.DataFrame(data)
    airline_features.columns = ['L', 'F', 'R', 'C', 'M']

    standard_data_table = QTableView()
    standard_data_table.horizontalHeader().setStretchLastSection(True)
    standard_data_table.setAlternatingRowColors(True)
    standard_data_table.setSelectionBehavior(QTableView.SelectRows)

    model = PandasModel(airline_features)
    standard_data_table.setModel(model)

    # print("\n标准特征值:", airline_features, sep='\n')

    return airline_features_copy, airline_features, selected_data_table, standard_data_table


def findBestK(airline_features, flag):
    # Elbow 方法确定最佳 K 值
    ssw = []
    for k in range(1, 11):
        estimator = KMeans(n_clusters=k)
        estimator.fit(airline_features[['L', 'F', 'R', 'C', 'M']])
        ssw.append(estimator.inertia_ / 10000)

    if flag is True:
        plt.rcParams["backend"] = 'QtAgg'
    else:
        plt.rcParams['figure.dpi'] = 300
    plt.rcParams['font.sans-serif'] = ['STKaiti']
    fig = plt.figure()
    fig = FigureCanvasQTAgg(fig)
    plt.xlabel('聚类的数量')
    plt.ylabel('各个点到 cluster 中心的距离的平方和(W)')
    x = range(1, 11)
    plt.plot(x, ssw, 'o-')

    if flag is True:
        return fig, 5


def modelTraining(airline_features, k):
    # 模型训练
    kmeans_model = KMeans(n_clusters=k, random_state=3721)
    kmeans_model.fit(airline_features)

    return kmeans_model


def characterAnalysis(kmeans_model, flag):
    # 输出聚类分群的结果
    type_count = pd.Series(kmeans_model.labels_).value_counts().sort_index()
    type_list = kmeans_model.labels_.tolist()
    cluster_center = pd.DataFrame(kmeans_model.cluster_centers_, columns=['L', 'F', 'R', 'C', 'M'], )
    total = sum(type_count)
    cluster_center.insert(0, 'Count', type_count)
    cluster_center.insert(0, 'Percentage', [i * 100 // total for i in type_count])
    cluster_center.insert(0, 'Type', [i + 1 for i in sorted(set(type_list), key=type_list.index)])

    # print("\n客户群的特征:", cluster_center, sep='\n')

    character_table = QTableView()
    character_table.horizontalHeader().setStretchLastSection(True)
    character_table.setAlternatingRowColors(True)
    character_table.setSelectionBehavior(QTableView.SelectRows)
    model = PandasModel(cluster_center)
    character_table.setModel(model)

    # 客户分群雷达图
    labels = ['L', 'F', 'R', 'C', 'M']
    labels = np.concatenate((labels, [labels[0]]))
    legen = ['客户群体 ' + str(i + 1) for i in cluster_center['Type']]  # 客户群命名，作为雷达图的图例
    lstype = ['-', '--', (0, (3, 5, 1, 5, 1, 5)), ':', '-.']
    kinds = list(cluster_center.iloc[:, 0])

    # 由于雷达图要保证数据闭合，因此再添加L列，并转换为 np.ndarray
    cluster_center = pd.concat([cluster_center, cluster_center[['L']]], axis=1)
    centers = np.array(cluster_center.iloc[:, 3:])

    # 分割圆周长，并让其闭合
    n = len(labels) - 1
    angle = np.linspace(0, 2 * np.pi, n, endpoint=False)
    angle = np.concatenate((angle, [angle[0]]))

    # 绘图
    if flag is True:
        plt.rcParams["backend"] = 'QtAgg'
    else:
        plt.rcParams['figure.dpi'] = 300
    plt.rcParams['font.sans-serif'] = ['STKaiti']
    plt.rcParams['axes.unicode_minus'] = False  # 用来正常显示负号
    fig = plt.figure()
    canvas = FigureCanvasQTAgg(fig)
    ax = fig.add_subplot(111, polar=True)  # 以极坐标的形式绘制图形
    ax.spines['polar'].set_visible(False)  # 不显示极坐标最外圈的圆
    ax.set_yticks([])  # 不显示坐标间隔

    # 画线
    for i in range(len(kinds)):
        ax.plot(angle, centers[i], linestyle=lstype[i], linewidth=2, label=kinds[i])

    floor = np.floor(centers.min())
    ceil = np.ceil(centers.max())
    for i in np.arange(floor, ceil, 0.7):
        ax.plot(angle, [i] * (n + 1), '--', lw=0.5, color='black')

    # 添加属性标签
    ax.set_thetagrids(angle * 180 / np.pi, labels)
    plt.title('客户特征分析雷达图')
    plt.legend(legen, loc="lower right")

    if flag is True:
        return cluster_center, character_table, canvas


def classifyCustomers(airline, kmeans_model, k):
    table_container = []
    data_container = []
    # 客户信息
    airline.insert(0, 'Group', [i + 1 for i in kmeans_model.labels_])

    # print("\n客户信息总表:\n", airline, sep='')

    view_table = QTableView()
    view_table.horizontalHeader().setStretchLastSection(True)
    view_table.setAlternatingRowColors(True)
    view_table.setSelectionBehavior(QTableView.SelectRows)
    model = PandasModel(airline)
    view_table.setModel(model)

    table_container.append(view_table)
    data_container.append(airline)

    for i in range(k):
        view_table = QTableView()
        view_table.horizontalHeader().setStretchLastSection(True)
        view_table.setAlternatingRowColors(True)
        view_table.setSelectionBehavior(QTableView.SelectRows)
        model = PandasModel(airline[airline['Group'] == i + 1].iloc[:, 1:])
        view_table.setModel(model)
        table_container.append(view_table)
        data_container.append(airline[airline['Group'] == i + 1].iloc[:, 1:])

        # print("\n客户群体 ", i + 1, " 信息表:\n", sep='')
        # print(airline[airline['Group'] == i + 1].iloc[:, 1:])

    return data_container, table_container
