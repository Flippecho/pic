import os
from pathlib import Path
from PySide6 import QtWidgets
from PySide6.QtCore import QThreadPool
from PySide6.QtGui import QIcon
from PySide6.QtWidgets import QMessageBox
from matplotlib import pyplot as plt

from ACValueAnalysis import fetchOriginalData, dataCleaning, constructModel, findBestK, modelTraining, \
    characterAnalysis, classifyCustomers
from MainWindow import Ui_MainWindow
from Worker import Worker


class MyMainWindow(QtWidgets.QMainWindow, Ui_MainWindow):

    def __init__(self):
        super(MyMainWindow, self).__init__()
        self.tables = []
        self.table_names = []
        self.setupUi(self)
        window_icon = QIcon()
        window_icon.addFile(':icon.png')
        self.setWindowIcon(window_icon)

        self.threadpool = QThreadPool()

        self.PBPrevious.clicked.connect(self.PBPreviousClicked)
        self.PBNext.clicked.connect(self.PBNextClicked)
        self.CBBPage.currentIndexChanged.connect(self.CBBIndexChanged)

        airline_data, original_data_table = fetchOriginalData()
        airline, cleaned_data_table = dataCleaning(airline_data)
        self.tabWidget2.addTab(original_data_table, '原始数据')
        self.tabWidget2.addTab(cleaned_data_table, '清洗后数据')
        self.tables.append(airline_data)
        self.tables.append(airline)
        self.table_names.append('原始数据.xls')
        self.table_names.append('清洗后数据.xls')

        airline_features_copy, self.airline_features, selected_data_table, standard_data_table = constructModel(airline)
        self.tabWidget3.addTab(selected_data_table, '特征值')
        self.tabWidget3.addTab(standard_data_table, '标准特征值')
        self.tables.append(airline_features_copy)
        self.tables.append(self.airline_features)
        self.table_names.append('特征值.xls')
        self.table_names.append('标准特征值.xls')

        fig, k = findBestK(self.airline_features, True)
        self.tabWidget4.addTab(fig, '肘子图')

        self.kmeans_model = modelTraining(self.airline_features, k)
        cluster_center, character_table, canvas = characterAnalysis(self.kmeans_model, True)
        self.tabWidget5.addTab(character_table, '客户特征分析表')
        self.tabWidget5.addTab(canvas, '客户特征雷达图')
        self.tables.append(cluster_center)
        self.table_names.append('客户特征分析表.xls')

        data_container, table_container = classifyCustomers(airline, self.kmeans_model, k)
        index = 0
        for table in table_container:
            if index == 0:
                name = '客户信息总表'
            else:
                name = '客户群体 ' + str(index)

            self.tabWidget6.addTab(table, name)
            self.tables.append(data_container[index])
            self.table_names.append(name+'.xls')
            index = index + 1

    def closeEvent(self, event):
        response = self.saveOrNot('正如你轻轻的来...', '即将退出，是否要保存产生的文件？')
        if response == 'Y':
            event.accept()
        else:
            event.ignore()

    def saveOrNot(self, title, msg):
        user_choice = QMessageBox.question(self, title, msg, QMessageBox.Yes | QMessageBox.No | QMessageBox.Cancel)
        # user_choice.button(QMessageBox.Yes).setText('保存')
        # user_choice.button(QMessageBox.No).setText('不保存')
        # user_choice.button(QMessageBox.Cancel).setText('再考虑一下')
        if user_choice == QMessageBox.Yes:
            worker = Worker(self.save_files)
            self.threadpool.start(worker)
            return 'Y'
        if user_choice == QMessageBox.No:
            return 'Y'
        if user_choice == QMessageBox.Cancel:
            return "N"

    def save_files(self, progress_callback):
        if not os.path.isdir("输出文件"):
            os.makedirs("输出文件")

        for i in range(11):
            if not os.path.isfile(Path("输出文件/" + self.table_names[i])):
                self.tables[i].to_excel(Path("输出文件/" + self.table_names[i]))

        if not os.path.isfile(Path('输出文件/肘子图.png')):
            findBestK(self.airline_features, False)
            plt.savefig(Path('输出文件/肘子图.png'))

        if not os.path.isfile(Path('输出文件/客户分析雷达图.png')):
            characterAnalysis(self.kmeans_model, False)
            plt.savefig(Path('输出文件/客户分析雷达图.png'))

    def PBPreviousClicked(self):
        self.PBNext.setEnabled(True)
        self.PBNext.setText('下一页')
        index = self.CBBPage.currentIndex()
        index = index - 1
        self.QSMain.setCurrentIndex(index)
        self.CBBPage.setCurrentIndex(index)
        if index == 0:
            self.PBPrevious.setText('到头啦')
            self.PBPrevious.setEnabled(False)

    def PBNextClicked(self):
        self.PBPrevious.setEnabled(True)
        self.PBPrevious.setText('上一页')
        index = self.CBBPage.currentIndex()
        index = index + 1
        self.QSMain.setCurrentIndex(index)
        self.CBBPage.setCurrentIndex(index)
        if index == 5:
            self.PBNext.setText('到底啦')
            self.PBNext.setEnabled(False)

    def CBBIndexChanged(self):
        index = self.CBBPage.currentIndex()
        self.QSMain.setCurrentIndex(index)
        if index == 0:
            self.PBPrevious.setText('到头啦')
            self.PBPrevious.setEnabled(False)
            self.PBNext.setEnabled(True)
            self.PBNext.setText('下一页')
        elif index == 5:
            self.PBNext.setText('到底啦')
            self.PBNext.setEnabled(False)
            self.PBPrevious.setEnabled(True)
            self.PBPrevious.setText('上一页')
        else:
            self.PBPrevious.setEnabled(True)
            self.PBPrevious.setText('上一页')
            self.PBNext.setEnabled(True)
            self.PBNext.setText('下一页')
