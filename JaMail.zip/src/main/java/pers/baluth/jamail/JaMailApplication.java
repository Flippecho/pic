package pers.baluth.jamail;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JaMailApplication {

    public static void main(String[] args) {
        SpringApplication.run(JaMailApplication.class, args);
    }

}
