package pers.baluth.jamail.web;

import com.google.gson.Gson;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import pers.baluth.jamail.mail.SMTP;

import javax.activation.DataHandler;
import javax.activation.FileDataSource;
import javax.mail.*;
import javax.mail.internet.*;
import java.util.Map;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Controller
public class WebServer {

    @ExceptionHandler(RuntimeException.class)
    public ModelAndView handleUnknowException(Exception ex) {
        return new ModelAndView("500.html",
                Map.of("error", ex.getClass().getSimpleName(), "message", ex.getMessage()));
    }

    @GetMapping("/")
    public ModelAndView index() {
        return new ModelAndView("index.html");
    }

    @PostMapping("/signin")
    public ModelAndView doSignin(@RequestParam("username") String username,
                                 @RequestParam("host") String host,
                                 @RequestParam("password") String password) {
        Properties prop = new Properties();
        prop.setProperty("mail.debug", "true");
        prop.setProperty("mail.host", "smtp.163.com");
        prop.setProperty("mail.transport.protocol", "smtp");
        prop.setProperty("mail.smtp.auth", "true");

        // 1、创建session
        Session session = Session.getInstance(prop);
        Transport ts = null;

        // 2、通过session得到transport对象
        try {
            ts = session.getTransport();
        } catch (NoSuchProviderException e) {
            e.printStackTrace();
        }

        // 3、连上邮件服务器
        try {
            assert ts != null;
            ts.connect("smtp.163.com", "flippecho@163.com", "NSVWWBLSDRVMDSXK");
        } catch (MessagingException e) {
            e.printStackTrace();
        }
        return new ModelAndView("index.html");
    }

    @PostMapping("/smtp")
    @ResponseBody
    public void SendEmail(@RequestParam("toList") String toListJson,
                          @RequestParam("ccList") String ccListJson,
                          @RequestParam("bccList") String bccListJson,
                          @RequestParam("aList") String aListJson,
                          @RequestParam("subject") String subject,
                          @RequestParam("contentHTML") String contentHTML) throws MessagingException {
        Gson gson = new Gson();
        String[] toList = gson.fromJson(toListJson, String[].class);
        String[] ccList = gson.fromJson(ccListJson, String[].class);
        String[] bccList = gson.fromJson(bccListJson, String[].class);
        String[] aList = gson.fromJson(aListJson, String[].class);

        String smtpServer = "smtp.163.com";
        String smtpPort = "25";
        String from = "flippecho@163.com";
        String password = "NSVWWBLSDRVMDSXK";

        String to = "2690695023@qq.com";
        String cc = "baluth@outlook.com";
        String bcc = "zyf929233@gmail.com";

        Properties props = new Properties();
        props.put("mail.smtp.host", smtpServer);
        props.put("mail.smtp.port", smtpPort);
        props.put("mail.smtp.auth", true);

        Session session = Session.getInstance(props, new Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(from, password);
            }
        });

        Message message = new MimeMessage(session);
        message.setFrom(new InternetAddress(from));

        for(int i = 0; i < toList.length; i++) {
            message.addRecipient(Message.RecipientType.TO, new InternetAddress(toList[i]));
        }

        for(int i = 0; i < ccList.length; i++) {
            message.addRecipient(Message.RecipientType.CC, new InternetAddress(ccList[i]));
        }

        for(int i = 0; i < bccList.length; i++) {
            message.addRecipient(Message.RecipientType.BCC, new InternetAddress(bccList[i]));
        }

        message.setSubject(subject);
        message.setContent(contentHTML, "text/html;charset=UTF-8");

        Transport.send(message);

    }

    @PostMapping("/pop3")
    @ResponseBody
    public void StoreEmail() throws MessagingException {
        Properties prop = new Properties();
        prop.setProperty("mail.debug", "true");
        prop.setProperty("mail.store.protocol", "pop3");
        prop.setProperty("mail.pop3.host", "pop.163.com");

        // 1、创建session
        Session session = Session.getInstance(prop);

        // 2、通过session得到Store对象
        Store store = session.getStore();

        // 3、连上邮件服务器
        store.connect("pop.163.com", "flippecho@163.com", "NSVWWBLSDRVMDSXK");

        // 4、获得邮箱内的邮件夹
        Folder folder = store.getFolder("inbox");
        folder.open(Folder.READ_ONLY);

        // 获得邮件夹Folder内的所有邮件Message对象
        Message[] messages = folder.getMessages();
        String regex = "(?<=\\<)[^\\>]+";
        Pattern pattern =Pattern.compile(regex);

        for (int i = 0; i < messages.length; i++) {
            String subject = messages[i].getSubject();
            String from = (messages[i].getFrom()[0]).toString();
            System.out.println("第 " + (i + 1) + "封邮件的主题：" + subject);
            Matcher matcher = pattern.matcher(from);
            System.out.println(from);
            System.out.println("第 " + (i + 1) + "封邮件的发件人地址：" + matcher.group());
        }

        // 5、关闭
        folder.close(false);
        store.close();
    }

}
