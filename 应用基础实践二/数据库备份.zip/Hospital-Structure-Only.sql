-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: localhost    Database: hospital
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `department`
--

DROP TABLE IF EXISTS `department`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `department` (
  `department_id` int unsigned NOT NULL AUTO_INCREMENT,
  `department_name` varchar(30) NOT NULL,
  `description` text,
  PRIMARY KEY (`department_id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `doctor`
--

DROP TABLE IF EXISTS `doctor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `doctor` (
  `doctor_id` int unsigned NOT NULL AUTO_INCREMENT,
  `doctor_name` varchar(20) NOT NULL,
  `title_id` tinyint unsigned NOT NULL,
  `sub_department_id` int unsigned NOT NULL,
  `working_years` tinyint unsigned NOT NULL,
  `patient_amount` int unsigned NOT NULL,
  `praise_amount` int unsigned NOT NULL,
  `criticize_amount` int unsigned NOT NULL,
  `telephone` char(11) DEFAULT NULL,
  `password` char(32) NOT NULL DEFAULT 'Hospital@2023',
  `verification_code` smallint DEFAULT NULL,
  PRIMARY KEY (`doctor_id`),
  KEY `fk_title_id` (`title_id`),
  KEY `fk_sub_department_id` (`sub_department_id`),
  CONSTRAINT `fk_sub_department_id` FOREIGN KEY (`sub_department_id`) REFERENCES `sub_department` (`sub_department_id`),
  CONSTRAINT `fk_title_id` FOREIGN KEY (`title_id`) REFERENCES `title` (`title_id`)
) ENGINE=InnoDB AUTO_INCREMENT=545 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `doctor_collection`
--

DROP TABLE IF EXISTS `doctor_collection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `doctor_collection` (
  `collection_id` int unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int unsigned NOT NULL,
  `doctor_id` int unsigned NOT NULL,
  PRIMARY KEY (`collection_id`),
  KEY `fk_doctor_collection_user_id` (`user_id`),
  KEY `fk_doctor_collection_doctor_id` (`doctor_id`),
  CONSTRAINT `fk_doctor_collection_doctor_id` FOREIGN KEY (`doctor_id`) REFERENCES `doctor` (`doctor_id`),
  CONSTRAINT `fk_doctor_collection_user_id` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders` (
  `order_id` int unsigned NOT NULL AUTO_INCREMENT,
  `sub_department_id` smallint unsigned NOT NULL,
  `doctor_id` int unsigned NOT NULL,
  `schedule_id` bigint unsigned NOT NULL,
  `is_morning` tinyint(1) NOT NULL,
  `cost` smallint unsigned NOT NULL,
  `payment_id` tinyint unsigned NOT NULL,
  `patient_id` int unsigned NOT NULL,
  `order_status` tinyint unsigned NOT NULL DEFAULT '0',
  `create_time` datetime NOT NULL,
  `user_id` int unsigned DEFAULT NULL,
  `qr_code` varchar(2083) DEFAULT NULL,
  PRIMARY KEY (`order_id`),
  KEY `fk_orders_doctor_id` (`doctor_id`),
  KEY `fk_orders_schedule_id` (`schedule_id`),
  KEY `fk_orders_user_id` (`user_id`),
  CONSTRAINT `fk_orders_doctor_id` FOREIGN KEY (`doctor_id`) REFERENCES `doctor` (`doctor_id`),
  CONSTRAINT `fk_orders_schedule_id` FOREIGN KEY (`schedule_id`) REFERENCES `schedule` (`schedule_id`),
  CONSTRAINT `fk_orders_user_id` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=123 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `schedule`
--

DROP TABLE IF EXISTS `schedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `schedule` (
  `schedule_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `date` tinyint unsigned DEFAULT NULL,
  `department_id` int unsigned NOT NULL,
  `morning` tinyint unsigned NOT NULL DEFAULT '0',
  `afternoon` tinyint unsigned NOT NULL DEFAULT '0',
  `doctor_id` int unsigned NOT NULL,
  PRIMARY KEY (`schedule_id`),
  KEY `fk_schedule_doctor_id` (`doctor_id`),
  CONSTRAINT `fk_schedule_doctor_id` FOREIGN KEY (`doctor_id`) REFERENCES `doctor` (`doctor_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3809 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sub_department`
--

DROP TABLE IF EXISTS `sub_department`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sub_department` (
  `sub_department_id` int unsigned NOT NULL AUTO_INCREMENT,
  `department_id` int unsigned NOT NULL,
  `sub_department_name` varchar(30) NOT NULL,
  PRIMARY KEY (`sub_department_id`),
  KEY `fk_sub_department_department_id` (`department_id`),
  CONSTRAINT `fk_sub_department_department_id` FOREIGN KEY (`department_id`) REFERENCES `department` (`department_id`)
) ENGINE=InnoDB AUTO_INCREMENT=137 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `title`
--

DROP TABLE IF EXISTS `title`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `title` (
  `title_id` tinyint unsigned NOT NULL AUTO_INCREMENT,
  `title_name` varchar(50) NOT NULL,
  `price` int unsigned NOT NULL,
  PRIMARY KEY (`title_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `user_id` int unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(20) DEFAULT NULL,
  `telephone` char(11) NOT NULL,
  `register_status` tinyint unsigned DEFAULT '0',
  `verification_code` smallint DEFAULT NULL,
  `id_card` char(18) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-01-10 17:04:29
