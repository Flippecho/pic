const KEY_DOCTOR_ID = "DOCTOR_ID"

const KEY_PAGE = "PAGE"
const PAGE_PATIENT = "0"
const PAGE_SCHEDULE = "1"

const KEY_PATIENT_ID = "PATIENT_ID"
const KEY_PATIENT_NAME = "PATIENT_NAME"

const KEY_FILTER = "FILTER"
const FILTER_THREE_DAY = "3"
const FILTER_WEEK = "7"
const FILTER_ALL = "0"

const loginLayout = document.querySelector("#login-card-container")
const contentLayout = document.querySelector("#main-content-container")

const patientLayout = document.querySelector("#patient-container")
const scheduleLayout = document.querySelector("#schedule-container")