const QUERY_HAS_FINISHED = "0"
const QUERY_OTHER_DOCTOR = "1"
const QUERY_NOT_FOUND = "2"

const queryRest = document.querySelector("#patient-container .content-container .query-rest")
const querySucceed = document.querySelector("#patient-container .content-container .query-succeed")
const queryFailed = document.querySelector("#patient-container .content-container .query-failed")
const patientCount = queryRest.querySelector(".patient-count")
const patientNameP = querySucceed.querySelector(".patient-name")

const queryInput = document.querySelector("#patient-container .query-container .patient-id-input")
const queryButton = document.querySelector("#patient-container .query-container .query-btn")
const finishButton = document.querySelector("#patient-container .query-container .finish-btn")
const scheduleButton = document.querySelector("#patient-container .schedule-and-exit-container .schedule-btn")
let exitButtonPatient = document.querySelector("#patient-container .schedule-and-exit-container .exit-btn")

queryInput.oninput = () => {
    const query = queryInput.value
    queryInput.value = query.replace(/\D/g, "").slice(0, 11)
}

queryButton.onclick = () => {
    const doctorId = sessionStorage.getItem(KEY_DOCTOR_ID)
    const patientId = queryInput.value

    if (patientId === "") return

    const Http = new XMLHttpRequest()
    const url = "http://localhost:8080/get_patient_order_status?doctor_id=" + doctorId + "&patient_id=" + patientId

    Http.open("GET", url)
    Http.send()

    Http.onreadystatechange = function () {
        if (Http.readyState === Http.DONE && Http.status === 200) {
            const status = Http.responseText
            if (/^[012]$/.test(status)) {
                queryRest.style.display = "none"
                querySucceed.style.display = "none"
                queryFailed.style.display = "block"
                finishButton.style.display = "none"
                sessionStorage.removeItem(KEY_PATIENT_ID)
                sessionStorage.removeItem(KEY_PATIENT_NAME)
            } else {
                queryRest.style.display = "none"
                querySucceed.style.display = "block"
                queryFailed.style.display = "none"
                patientNameP.innerText = status
                // queryInput.setAttribute("readonly", "true")
                // queryButton.style.display = "none"
                finishButton.style.display = "inline-block"
                sessionStorage.setItem(KEY_PATIENT_ID, patientId)
                sessionStorage.setItem(KEY_PATIENT_NAME, status)
            }

            if (status === QUERY_HAS_FINISHED) {
                queryFailed.innerText = "会诊已结束，如有需要请患者挂复诊"
            } else if (status === QUERY_OTHER_DOCTOR) {
                queryFailed.innerText = "请患者到预约的科室就诊"
            } else if (status === QUERY_NOT_FOUND) {
                queryFailed.innerText = "患者今天没有预约记录"
            }
        }
    }
}

finishButton.onclick = () => {
    const doctorId = sessionStorage.getItem(KEY_DOCTOR_ID)
    const patientId = sessionStorage.getItem(KEY_PATIENT_ID)

    const Http = new XMLHttpRequest()
    const url = "http://localhost:8080/finish_order?doctor_id=" + doctorId + "&patient_id=" + patientId

    Http.open("GET", url)
    Http.send()

    const oldCount = parseInt(patientCount.innerText)
    patientCount.innerText = (oldCount - 1).toString()
    const oldAmount = parseInt(patientAmount.innerText)
    patientAmount.innerText = (oldAmount - 1).toString()
    queryRest.style.display = "block"
    querySucceed.style.display = "none"
    queryInput.value = ""
    // queryInput.removeAttribute("readonly")
    // queryButton.style.display = "inline-block"
    finishButton.style.display = "none"
    sessionStorage.removeItem(KEY_PATIENT_ID)
    sessionStorage.removeItem(KEY_PATIENT_NAME)
}

scheduleButton.onclick = () => {
    scheduleLayout.style.display = "block"
    patientLayout.style.display = "none"
    sessionStorage.setItem(KEY_PAGE, PAGE_SCHEDULE)
    if (scheduleList === null) {
        getSchedule()
    }
}

exitButtonPatient.onclick = () => {
    sessionStorage.clear()
    location.reload()
    // loginLayout.style.display = "flex"
    // contentLayout.style.display = "none"
    // queryInput.value = ""
    // queryRest.style.display = "block"
    // querySucceed.style.display = "none"
    // queryFailed.style.display = "none"
}

function getPatientCount() {
    const doctorId = sessionStorage.getItem(KEY_DOCTOR_ID)
    if (doctorId == null) return

    const Http = new XMLHttpRequest()
    const url = "http://localhost:8080/get_patient_count?doctor_id=" + doctorId

    Http.open("GET", url)
    Http.send()

    Http.onreadystatechange = function () {
        if (Http.readyState === Http.DONE && Http.status === 200) {
            patientCount.innerText = Http.responseText
        }
    }
}