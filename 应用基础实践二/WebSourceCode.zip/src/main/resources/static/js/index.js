window.onload = () => {
    const doctorId = sessionStorage.getItem(KEY_DOCTOR_ID)
    if (doctorId == null) {
        loginLayout.style.display = "flex"
        contentLayout.style.display = "none"
    } else {
        getDoctorInfo(doctorId)
        loginLayout.style.display = "none"
        contentLayout.style.display = "flex"
    }

    const page = sessionStorage.getItem(KEY_PAGE)
    if (page == null || page === PAGE_PATIENT) {
        getPatientCount()
        setInterval(getPatientCount, 1000)
        patientLayout.style.display = "block"
        scheduleLayout.style.display = "none"
    } else{
        getSchedule()
        patientLayout.style.display = "none"
        scheduleLayout.style.display = "block"
    }

    const patientId = sessionStorage.getItem(KEY_PATIENT_ID)
    if (patientId != null) {
        const patientName = sessionStorage.getItem(KEY_PATIENT_NAME)
        queryInput.value = patientId
        patientNameP.innerText = patientName
        querySucceed.style.display = "block"
        queryRest.style.display = "none"
        // queryInput.setAttribute("readonly", "true")
        // queryButton.style.display = "none"
        finishButton.style.display = "inline-block"
    }
}