const telephoneInput = document.querySelector("#login-card .content-container .input-telephone")
const codeInput = document.querySelector("#login-card .content-container .input-code")
const passwordInput = document.querySelector("#login-card .content-container .input-password")
const codeButton = document.querySelector("#login-card .content-container .btn-code")
const loginButton = document.querySelector("#login-card .content-container .btn-login")

telephoneInput.oninput = () => {
    const telephone = telephoneInput.value
    telephoneInput.value = telephone.replace(/\D/g, "").slice(0, 11)
}

codeInput.oninput = () => {
    const code = codeInput.value
    codeInput.value = code.replace(/\D/g, "").slice(0, 4)
}

codeButton.onclick = () => {
    const telephone = telephoneInput.value
    const regex = /^1[3-9]\d{9}$/
    if (!regex.test(telephone)) {
        alert("手机号码格式不正确！")
    } else {
        const Http = new XMLHttpRequest()
        const url = "http://localhost:8080/get_verification_code_for_doctor?telephone=" + telephone
        Http.open("GET", url)
        Http.send()
    }
}

loginButton.onclick = () => {
    const telephone = telephoneInput.value
    const regex = /^1[3-9]\d{9}$/
    if (!regex.test(telephone)) {
        alert("手机号码格式不正确！")
    } else {
        const code = codeInput.value
        const regex = /^[1-9]\d{3}$/
        
        if (!regex.test(code)) {
            alert("验证码格式不正确！")
        } else {
            const password = passwordInput.value
            const regex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%^&*()_+=-])(?=.*\d).{8,}$/
            
            if (!regex.test(password)) {
                alert("密码需要含有至少一个大写字母、一个小写字母、一个数字和一个特殊字符 !@#$%^&*()_+=- 且长度在 8-32 之间")
            } else {
                const Http = new XMLHttpRequest()
                const url = "http://localhost:8080/check_info_for_doctor?telephone=" + telephone + "&code=" + code + "&password=" + password
                
                Http.open("GET", url)
                Http.send()

                Http.onreadystatechange = function () {
                    if (Http.readyState === Http.DONE && Http.status === 200) {
                        const doctorId = Http.responseText
                        if (doctorId === "0") {
                            alert("登录失败")
                        } else {
                            sessionStorage.setItem(KEY_DOCTOR_ID, doctorId)
                            getDoctorInfo(doctorId)
                            getPatientCount(doctorId)
                            loginLayout.style.display = "none"
                            contentLayout.style.display = "flex"
                            telephoneInput.value = ""
                            codeInput.value = ""
                            passwordInput.value = ""
                        }
                    }
                }
            }
        }
    }
}