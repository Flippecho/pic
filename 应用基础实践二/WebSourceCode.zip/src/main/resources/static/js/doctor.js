const name = document.querySelector("#info-card .text-container .name")
const title = document.querySelector("#info-card .text-container .title")
const department = document.querySelector("#info-card .text-container .department")

const workingYear = document.querySelector("#info-card .info-static .working-year")
const patientAmount = document.querySelector("#info-card .info-static .patient-amount")
const praiseAmount = document.querySelector("#info-card .info-static .praise-amount")
const criticizeAmount = document.querySelector("#info-card .info-static .criticize-amount")

function getDoctorInfo(doctorId) {
    const Http = new XMLHttpRequest()
    const url = "http://localhost:8080/get_doctor_info?doctor_id=" + doctorId

    Http.open("GET", url)
    Http.send()

    Http.onreadystatechange = function () {
        if (Http.readyState === Http.DONE && Http.status === 200) {
            const info = JSON.parse(Http.response)[0]
            name.innerText = info.doctor_name
            title.innerText = info.title_name
            department.innerText = info.sub_department_name
            workingYear.innerText = info.working_years
            patientAmount.innerText = info.patient_amount
            praiseAmount.innerText = info.praise_amount
            criticizeAmount.innerText = info.criticize_amount
        }
    }
}