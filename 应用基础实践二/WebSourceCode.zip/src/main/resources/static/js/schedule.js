const placeholderTemplate = document.querySelector("#placeholder-template")
const emptyHintTemplate = document.querySelector("#empty-hint-template")
const scheduleTemplate = document.querySelector("#schedule-template")

const contentContainer = document.querySelector("#schedule-container .content-container")
const threeDayButton = document.querySelector("#schedule-container .control-container .three-day-btn")
const weekButton = document.querySelector("#schedule-container .control-container .week-btn")
const allButton = document.querySelector("#schedule-container .control-container .all-btn")
const patientButton = document.querySelector("#schedule-container .control-container .patient-btn")
const exitButtonSchedule = document.querySelector("#schedule-container .control-container .exit-btn")

const weekList = ["周日", "周一", "周二", "周三", "周四", "周五", "周六"]
let scheduleList = null

threeDayButton.onclick = () => {
    const filterMode = sessionStorage.getItem(KEY_FILTER)
    if (filterMode === FILTER_THREE_DAY) return
    sessionStorage.setItem(KEY_FILTER, FILTER_THREE_DAY)
    applyScheduleList(3)
}

weekButton.onclick = () => {
    const filterMode = sessionStorage.getItem(KEY_FILTER)
    if (filterMode === FILTER_WEEK) return
    sessionStorage.setItem(KEY_FILTER, FILTER_WEEK)
    applyScheduleList(7)
}

allButton.onclick = () => {
    const filterMode = sessionStorage.getItem(KEY_FILTER)
    if (filterMode == null || filterMode === FILTER_ALL) return
    sessionStorage.setItem(KEY_FILTER, FILTER_ALL)
    applyScheduleList(0)
}

patientButton.onclick = () => {
    scheduleLayout.style.display = "none"
    patientLayout.style.display = "block"
    sessionStorage.setItem(KEY_PAGE, PAGE_PATIENT)
}

exitButtonSchedule.onclick = () => {
    sessionStorage.clear()
    location.reload()
    // loginLayout.style.display = "flex"
    // contentLayout.style.display = "none"
    //
    // const queryRest = document.querySelector("#patient-container .content-container .query-rest")
    // const querySucceed = document.querySelector("#patient-container .content-container .query-succeed")
    // const queryFailed = document.querySelector("#patient-container .content-container .query-failed")
    // const queryInput = document.querySelector("#patient-container .query-container .patient-id-input")
    //
    // queryInput.value = ""
    // queryRest.style.display = "block"
    // querySucceed.style.display = "none"
    // queryFailed.style.display = "none"
}

function getSchedule() {
    const doctorId = sessionStorage.getItem(KEY_DOCTOR_ID)
    const Http = new XMLHttpRequest()
    const url = "http://localhost:8080/get_schedule_doctor?doctor_id=" + doctorId

    Http.open("GET", url)
    Http.send()

    Http.onreadystatechange = function () {
        if (Http.readyState === Http.DONE && Http.status === 200) {
            scheduleList = JSON.parse(Http.response)
            if (scheduleList.length === 0) {
                contentContainer.innerHTML = ""
                const clone = document.importNode(emptyHintTemplate.content, true)
                contentContainer.append(clone)
            } else {
                const filterMode = sessionStorage.getItem(KEY_FILTER)
                if (filterMode == null || filterMode === FILTER_ALL) {
                    applyScheduleList(0)
                } else if (filterMode === FILTER_WEEK) {
                    applyScheduleList(7)
                } else if (filterMode === FILTER_THREE_DAY) {
                    applyScheduleList(3)
                }
            }
        }
    }
}

function applyScheduleList(mode) {
    contentContainer.innerHTML = ""

    if (mode === 0) {
        threeDayButton.className = "btn btn-animate three-day-btn"
        weekButton.className = "btn btn-animate week-btn"
        allButton.className = "btn btn-selected all-btn"
    } else if (mode === 3) {
        threeDayButton.className = "btn btn-selected three-day-btn"
        weekButton.className = "btn btn-animate week-btn"
        allButton.className = "btn btn-animate all-btn"
    } else if (mode === 7) {
        threeDayButton.className = "btn btn-animate three-day-btn"
        weekButton.className = "btn btn-selected week-btn"
        allButton.className = "btn btn-animate all-btn"
    }

    for (const schedule of scheduleList) {
        if (schedule.date > mode && mode !== 0) return

        const date = new Date()
        date.setDate(date.getDate() + schedule.date - 1)
        const month = (date.getMonth() + 1).toString().padStart(2, '0')
        const day = (date.getDate()).toString().padStart(2, '0')

        let week = weekList[date.getDay()]
        if (schedule.date === 1) {
            week = "今天"
        } else if (schedule.date === 2) {
            week = "明天"
        } else if (schedule.date === 3) {
            week = "后天"
        }

        const clone = document.importNode(scheduleTemplate.content, true)
        clone.querySelector(".week").innerText = week
        clone.querySelector(".date").innerText = month + " 月 " + day + " 日"
        clone.querySelector(".morning-count").innerText = 20 - schedule.morning
        clone.querySelector(".afternoon-count").innerText = 20 - schedule.afternoon
        contentContainer.append(clone)
    }

    const clone = document.importNode(placeholderTemplate.content, true)
    contentContainer.append(clone)
}