package per.baluth

import com.zaxxer.hikari.HikariConfig
import com.zaxxer.hikari.HikariDataSource
import per.baluth.dao.*
import java.sql.Connection
import java.sql.SQLException
import javax.sql.DataSource

object Repository {
    private var dataSource: DataSource? = null

    private fun getDataSource(): DataSource {
        if (dataSource == null) {
            val config = HikariConfig()
            config.jdbcUrl = "jdbc:mysql://localhost:3306/hospital"
            config.username = "root"
            config.password = "Baluth@2002"
            config.connectionTimeout = 1000
            config.idleTimeout = 60 * 1000
            dataSource = HikariDataSource(config)
        }
        return dataSource!!
    }

    fun getDepartment() = DepartmentDao.getDepartment(getDataSource())

    fun getDepartmentSchedule(id: String) = ScheduleDao.getDepartmentSchedule(getDataSource(), id)

    fun getDoctorSchedule(id: String) = ScheduleDao.getDoctorSchedule(getDataSource(), id)

    fun updateVerificationCode(telephone: String, code: String) =
        VerificationDao.updateVerificationCode(getDataSource(), telephone, code)

    fun updateVerificationCodeForDoctor(telephone: String, code: String) =
        VerificationDao.updateVerificationCodeForDoctor(getDataSource(), telephone, code)

    fun changeTelephone(id: String, telephone: String) = VerificationDao.changeTelephone(getDataSource(), id, telephone)

    fun sendSMS(code: String) = VerificationDao.sendSMS(code)

    fun isCodeMatch(telephone: String, code: String) = VerificationDao.isCodeMatch(getDataSource(), telephone, code)

    fun isInfoMatchForDoctor(telephone: String, code: String, password: String) =
        VerificationDao.isInfoMatchForDoctor(getDataSource(), telephone, code, password)

    fun registerIfHasNot(telephone: String) = VerificationDao.registerIfHasNot(getDataSource(), telephone)

    fun hasRegistered(telephone: String) = VerificationDao.hasRegistered(getDataSource(), telephone)

    fun getRegisterStatus(telephone: String) = RegisterStatusDao.getRegisterStatus(getDataSource(), telephone)

    fun updateInfo(telephone: String, id: String, name: String) =
        RegisterStatusDao.updateInfo(getDataSource(), telephone, id, name)

    fun getIdentifier(telephone: String) = RegisterStatusDao.getIdentifier(getDataSource(), telephone)

    fun createOrder(order: String) = OrderDao.createOrder(getDataSource(), order)

    fun setQrCode(id: String, qrCode: String) = OrderDao.setQrCode(getDataSource(), id, qrCode)

    fun getQrCode(id: String) = OrderDao.getQrCode(getDataSource(), id)

    fun cancelIfNotPaid(order: String, id: Long) = OrderDao.cancelIfNotPaid(getDataSource(), order, id)

    fun getFirstTenOrders(id: String) = OrderDao.getFirstTenOrders(getDataSource(), id)

    fun getRest(id: String) = RestDao.getRest(getDataSource(), id)

    fun getOrderStatus(id: String) = OrderDao.getOrderStatus(getDataSource(), id)

    fun setOrderStatus(id: Int, status: Int) = OrderDao.setOrderStatus(getDataSource(), id, status)

    fun cancelOrder(id: String) = OrderDao.cancelOrder(getDataSource(), id)

    fun getCancelCount(id: String) = OrderDao.getCancelCount(getDataSource(), id)

    fun getDoctorInfo(id: String) = DoctorDao.getDoctorInfo(getDataSource(), id)

    fun collectDoctor(userId: String, doctorId: String) = DoctorDao.collectDoctor(getDataSource(), userId, doctorId)

    fun unCollectDoctor(userId: String, doctorId: String) = DoctorDao.unCollectDoctor(getDataSource(), userId, doctorId)

    fun checkIsCollected(userId: String, doctorId: String) =
        DoctorDao.checkIsCollected(getDataSource(), userId, doctorId)

    fun getDoctorCollection(userId: String) = DoctorDao.getDoctorCollection(getDataSource(), userId)

    fun getDepartmentId(id: String) = DepartmentDao.getDepartmentId(getDataSource(), id)

    fun getOrderCountStatus(userId: String, scheduleId: String, isMorning: Boolean, departmentId: String) =
        OrderDao.getOrderCountStatus(getDataSource(), userId, scheduleId, isMorning, departmentId)

    fun getPatientCount(doctorId: String) = DoctorDao.getPatientCount(getDataSource(), doctorId)

    fun getPatientOrderStatus(patientId: String, doctorId: String) =
        OrderDao.getPatientOrderStatus(getDataSource(), patientId, doctorId)

    fun increasePatientAmount(doctorId: String) = DoctorDao.increasePatientAmount(getDataSource(), doctorId)

    fun getOrderId(doctorId: String, patientId: String) = OrderDao.getOrderId(getDataSource(), doctorId, patientId)
}