package per.baluth.dao

import per.baluth.model.Identifier
import java.sql.Connection
import java.sql.SQLException
import javax.sql.DataSource

object RegisterStatusDao {
    fun getRegisterStatus(dataSource: DataSource, telephone: String): Int {
        var status = 0
        var connection: Connection? = null
        try {
            connection = dataSource.connection
            val preparedStatement =
                connection.prepareStatement("select register_status from user where register_status != 3 and telephone = ?")
            preparedStatement.setObject(1, telephone)
            val resultSet = preparedStatement.executeQuery()
            if (resultSet.next()) {
                status = resultSet.getInt(1)
            }
        } catch (e: SQLException) {
            e.printStackTrace()
        } finally {
            connection?.close()
        }
        return status
    }

    fun updateInfo(dataSource: DataSource, telephone: String, id: String, name: String): Int {
        var userId = 0
        var connection: Connection? = null
        try {
            connection = dataSource.connection
            var preparedStatement =
                connection.prepareStatement("update user set username=?, register_status = 2, id_card=? where register_status !=3 and telephone = ?")
            preparedStatement.setObject(1, name)
            preparedStatement.setObject(2, id)
            preparedStatement.setObject(3, telephone)
            preparedStatement.executeUpdate()

            preparedStatement =
                connection.prepareStatement("select user_id from user where register_status!=3 and telephone = ?")
            preparedStatement.setObject(1, telephone)

            val resultSet = preparedStatement.executeQuery()
            if (resultSet.next()) {
                userId = resultSet.getInt(1)
            }

        } catch (e: SQLException) {
            e.printStackTrace()
        } finally {
            connection?.close()
        }

        return userId
    }

    fun getIdentifier(dataSource: DataSource, telephone: String): Identifier? {
        var identifier: Identifier? = null
        var connection: Connection? = null
        try {
            connection = dataSource.connection
            val preparedStatement =
                connection.prepareStatement("select user_id, username, id_card from user where register_status != 3 and telephone = ?")
            preparedStatement.setObject(1, telephone)
            val resultSet = preparedStatement.executeQuery()
            if (resultSet.next()) {
                val id = resultSet.getInt(1)
                val username = resultSet.getString(2)
                val idCard = resultSet.getString(3)
                identifier = Identifier(id, username, telephone, idCard)
            }
        } catch (e: SQLException) {
            e.printStackTrace()
        } finally {
            connection?.close()
        }

        return identifier
    }
}