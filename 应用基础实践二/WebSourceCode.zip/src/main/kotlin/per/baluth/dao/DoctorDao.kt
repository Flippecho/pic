package per.baluth.dao

import java.sql.Connection
import java.sql.SQLException
import javax.sql.DataSource

object DoctorDao {
    fun collectDoctor(dataSource: DataSource, userId: String, doctorId: String): Boolean {
        var succeed = false
        var connection: Connection? = null
        try {
            connection = dataSource.connection
            val preparedStatement =
                connection.prepareStatement("insert into doctor_collection(user_id, doctor_id) value (?,?)")
            preparedStatement.setObject(1, userId)
            preparedStatement.setObject(2, doctorId)
            preparedStatement.executeUpdate()
            succeed = true
        } catch (e: SQLException) {
            e.printStackTrace()
        } finally {
            connection?.close()
        }
        return succeed
    }

    fun unCollectDoctor(dataSource: DataSource, userId: String, doctorId: String): Boolean {
        var succeed = false
        var connection: Connection? = null
        try {
            connection = dataSource.connection
            val preparedStatement =
                connection.prepareStatement("delete from doctor_collection where user_id = ? and  doctor_id = ?")
            preparedStatement.setObject(1, userId)
            preparedStatement.setObject(2, doctorId)
            preparedStatement.executeUpdate()
            succeed = true
        } catch (e: SQLException) {
            e.printStackTrace()
        } finally {
            connection?.close()
        }
        return succeed
    }

    fun getDoctorCollection(dataSource: DataSource, userId: String): String {
        var result = "[]"
        var connection: Connection? = null
        try {
            connection = dataSource.connection
            val preparedStatement = connection.prepareStatement(
                "select JSON_ARRAYAGG(JSON_OBJECT(\n" +
                        "        'doctor_id', d.doctor_id,\n" +
                        "        'doctor_name', doctor_name,\n" +
                        "        'title_name', title_name,\n" +
                        "        'sub_department_name', sub_department_name\n" +
                        "    ))\n" +
                        "from doctor_collection\n" +
                        "         inner join doctor d on doctor_collection.doctor_id = d.doctor_id\n" +
                        "         inner join title t on d.title_id = t.title_id\n" +
                        "         inner join sub_department sd on d.sub_department_id = sd.sub_department_id\n" +
                        "where user_id = ?"
            )
            preparedStatement.setObject(1, userId)
            val resultSet = preparedStatement.executeQuery()
            if (resultSet.next()) {
                val tempObject = resultSet.getObject(1)
                if (tempObject != null) {
                    result = tempObject.toString()
                }
            }
        } catch (e: SQLException) {
            e.printStackTrace()
        } finally {
            connection?.close()
        }
        return result
    }

    fun checkIsCollected(dataSource: DataSource, userId: String, doctorId: String): Boolean {
        var succeed = false
        var connection: Connection? = null
        try {
            connection = dataSource.connection
            val preparedStatement =
                connection.prepareStatement("select collection_id from doctor_collection where user_id = ? and doctor_id = ?")
            preparedStatement.setObject(1, userId)
            preparedStatement.setObject(2, doctorId)
            val resultSet = preparedStatement.executeQuery()
            if (resultSet.next()) {
                succeed = true
            }
        } catch (e: SQLException) {
            e.printStackTrace()
        } finally {
            connection?.close()
        }
        return succeed
    }

    fun getDoctorInfo(dataSource: DataSource, doctorId: String): String {
        var result = "FAILURE"
        var connection: Connection? = null
        try {
            connection = dataSource.connection
            val preparedStatement = connection.prepareStatement(
                "select JSON_ARRAYAGG(JSON_OBJECT(\n" +
                        "        'doctor_id', doctor_id,\n" +
                        "        'doctor_name', doctor_name,\n" +
                        "        'title_name', title_name,\n" +
                        "        'price', price,\n" +
                        "        'sub_department_id', sd.sub_department_id,\n" +
                        "        'sub_department_name', sub_department_name,\n" +
                        "        'working_years', working_years,\n" +
                        "        'patient_amount', patient_amount,\n" +
                        "        'praise_amount', praise_amount,\n" +
                        "        'criticize_amount', criticize_amount))\n" +
                        "from doctor\n" +
                        "         inner join title t on doctor.title_id = t.title_id\n" +
                        "         inner join sub_department sd on doctor.sub_department_id = sd.sub_department_id\n" +
                        "where doctor_id = ?"
            )
            preparedStatement.setObject(1, doctorId)
            val resultSet = preparedStatement.executeQuery()
            if (resultSet.next()) {
                result = resultSet.getString(1)
            }
        } catch (e: SQLException) {
            e.printStackTrace()
        } finally {
            connection?.close()
        }
        return result
    }

    fun getPatientCount(dataSource: DataSource, doctorId: String): Int {
        var count = 0
        var connection: Connection? = null
        try {
            connection = dataSource.connection
            val preparedStatement = connection.prepareStatement(
                "select count(*)\n" +
                        "from orders\n" +
                        "         inner join schedule s on orders.schedule_id = s.schedule_id\n" +
                        "where date = 1\n" +
                        "  and order_status = 1\n" +
                        "  and s.doctor_id = ?"
            )
            preparedStatement.setObject(1, doctorId)
            val resultSet = preparedStatement.executeQuery()
            if (resultSet.next()) {
                count = resultSet.getInt(1)
            }
        } catch (e: SQLException) {
            e.printStackTrace()
        } finally {
            connection?.close()
        }
        return count
    }

    fun increasePatientAmount(dataSource: DataSource, doctorId: String) {
        var connection: Connection? = null
        try {
            connection = dataSource.connection
            val preparedStatement =
                connection.prepareStatement("update doctor set patient_amount = patient_amount + 1 where doctor_id = ?")
            preparedStatement.setObject(1, doctorId)
            preparedStatement.executeUpdate()
        } catch (e: SQLException) {
            e.printStackTrace()
        } finally {
            connection?.close()
        }
    }
}