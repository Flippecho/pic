package per.baluth.dao

import com.aliyun.dysmsapi20170525.Client
import com.aliyun.dysmsapi20170525.models.SendSmsRequest
import com.aliyun.teaopenapi.models.Config
import java.sql.Connection
import java.sql.SQLException
import javax.sql.DataSource

object VerificationDao {

    fun registerIfHasNot(dataSource: DataSource, telephone: String) {
        if (!hasRegistered(dataSource, telephone)) {
            register(dataSource, telephone)
        }
    }

    fun hasRegistered(dataSource: DataSource, telephone: String): Boolean {
        var hasRegistered = false
        var connection: Connection? = null
        try {
            connection = dataSource.connection
            val preparedStatement =
                connection.prepareStatement("select user_id from user where register_status != 3 and telephone = ?")
            preparedStatement.setObject(1, telephone)
            val resultSet = preparedStatement.executeQuery()
            if (resultSet.next()) {
                hasRegistered = true
            }
        } catch (e: SQLException) {
            e.printStackTrace()
        } finally {
            connection?.close()
        }
        return hasRegistered
    }

    private fun register(dataSource: DataSource, telephone: String) {
        var connection: Connection? = null
        try {
            connection = dataSource.connection
            val preparedStatement = connection.prepareStatement("insert into user(telephone) value (?)")
            preparedStatement.setObject(1, telephone)
            preparedStatement.executeUpdate()
        } catch (e: SQLException) {
            e.printStackTrace()
        } finally {
            connection?.close()
        }
    }

    fun updateVerificationCode(dataSource: DataSource, telephone: String, code: String) {
        var connection: Connection? = null
        try {
            connection = dataSource.connection
            val preparedStatement =
                connection.prepareStatement("update user set verification_code = ? WHERE register_status !=3 and telephone = ?")
            preparedStatement.setObject(1, code)
            preparedStatement.setObject(2, telephone)
            preparedStatement.executeUpdate()
        } catch (e: SQLException) {
            e.printStackTrace()
        } finally {
            connection?.close()
        }
    }

    fun updateVerificationCodeForDoctor(dataSource: DataSource, telephone: String, code: String) {
        var connection: Connection? = null
        try {
            connection = dataSource.connection
            val preparedStatement =
                connection.prepareStatement("update doctor set verification_code = ? WHERE  telephone = ?")
            preparedStatement.setObject(1, code)
            preparedStatement.setObject(2, telephone)
            preparedStatement.executeUpdate()
        } catch (e: SQLException) {
            e.printStackTrace()
        } finally {
            connection?.close()
        }
    }

    fun changeTelephone(dataSource: DataSource, id: String, telephone: String) {
        var connection: Connection? = null
        try {
            connection = dataSource.connection
            val preparedStatement =
                connection.prepareStatement("update user set telephone = ? WHERE register_status !=3 and user_id = ?")
            preparedStatement.setObject(1, telephone)
            preparedStatement.setObject(2, id)
            preparedStatement.executeUpdate()
        } catch (e: SQLException) {
            e.printStackTrace()
        } finally {
            connection?.close()
        }

    }

    fun isCodeMatch(dataSource: DataSource, telephone: String, code: String): Boolean {
        var result = false
        var connection: Connection? = null
        try {
            connection = dataSource.connection
            val preparedStatement =
                connection.prepareStatement("select verification_code from user where register_status !=3 and telephone = ?")
            preparedStatement.setObject(1, telephone)
            val resultSet = preparedStatement.executeQuery()
            if (resultSet.next()) {
                result = resultSet.getString(1) == code
            }
        } catch (e: SQLException) {
            e.printStackTrace()
        } finally {
            connection?.close()
        }
        return result
    }

    fun isInfoMatchForDoctor(dataSource: DataSource, telephone: String, code: String, password: String): Int {
        var result = 0
        var connection: Connection? = null
        try {
            connection = dataSource.connection
            val preparedStatement =
                connection.prepareStatement("select verification_code, password, doctor_id from doctor where telephone = ?")
            preparedStatement.setObject(1, telephone)
            val resultSet = preparedStatement.executeQuery()
            if (resultSet.next()) {
                if (resultSet.getString(1) == code && resultSet.getString(2) == password) {
                    result = resultSet.getInt(3)
                }
            }
        } catch (e: SQLException) {
            e.printStackTrace()
        } finally {
            connection?.close()
        }
        return result
    }

    fun sendSMS(code: String) {
        // use your own config
        val config = Config()
        config.accessKeyId = ""
        config.accessKeySecret = ""
        val client = Client(config)

        val sendRequest = SendSmsRequest()
        // use your own config
        sendRequest.phoneNumbers = ""
        sendRequest.signName = "阿里云短信测试"
        sendRequest.templateCode = "SMS_154950909"
        sendRequest.templateParam = "{\"code\":\"$code\"}"

        val sendResponse = client.sendSms(sendRequest)

        val responseCode = sendResponse.body.code
        if (responseCode != "OK") {
            println("错误信息: ${sendResponse.body.message}")
        }
    }
}