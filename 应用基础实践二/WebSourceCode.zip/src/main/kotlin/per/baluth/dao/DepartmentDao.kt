package per.baluth.dao

import java.sql.Connection
import java.sql.SQLException
import javax.sql.DataSource

object DepartmentDao {
    fun getDepartment(dataSource: DataSource): String {
        var json = ""
        var connection: Connection? = null
        try {
            connection = dataSource.connection
            val preparedStatement =
                connection.prepareStatement("select JSON_ARRAYAGG(JSON_OBJECT('department_id', department_id, 'department_name', department_name, 'description', description)) from department")
            val resultSet = preparedStatement.executeQuery()
            resultSet.next()
            json = resultSet.getString(1)
        } catch (e: SQLException) {
            e.printStackTrace()
        } finally {
            connection?.close()
        }
        return json
    }

    fun getDepartmentId(dataSource: DataSource, subDepartmentId: String): Int {
        var departmentId = 0
        var connection: Connection? = null
        try {
            connection = dataSource.connection
            val preparedStatement =
                connection.prepareStatement("select department_id from sub_department where sub_department_id = ?")
            preparedStatement.setObject(1, subDepartmentId)
            val resultSet = preparedStatement.executeQuery()
            if (resultSet.next()) {
                departmentId = resultSet.getInt(1)
            }
        } catch (e: SQLException) {
            e.printStackTrace()
        } finally {
            connection?.close()
        }
        return departmentId
    }
}