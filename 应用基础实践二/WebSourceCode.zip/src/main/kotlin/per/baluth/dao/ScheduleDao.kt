package per.baluth.dao

import com.google.gson.Gson
import per.baluth.model.DetailedSchedule
import java.sql.Connection
import java.sql.SQLException
import javax.sql.DataSource

object ScheduleDao {

    private const val department_query = "select JSON_ARRAYAGG(JSON_OBJECT(\n" +
            "        'schedule_id', schedule_id,\n" +
            "        'doctor_id', d.doctor_id,\n" +
            "        'doctor_name', doctor_name,\n" +
            "        'title_name', title_name,\n" +
            "        'price', price,\n" +
            "        'sub_department_id', s.sub_department_id,\n" +
            "        'sub_department_name', sub_department_name,\n" +
            "        'date', date,\n" +
            "        'morning', morning,\n" +
            "        'afternoon', afternoon,\n" +
            "        'working_years', working_years,\n" +
            "        'patient_amount', patient_amount,\n" +
            "        'praise_amount', praise_amount,\n" +
            "        'criticize_amount', criticize_amount))\n" +
            "from schedule\n" +
            "         inner join doctor d on schedule.doctor_id = d.doctor_id\n" +
            "         inner join sub_department s on d.sub_department_id = s.sub_department_id\n" +
            "         inner join title t on d.title_id = t.title_id\n" +
            "where s.department_id = ?\n" +
            "group by date"

    private const val doctor_query = "select JSON_ARRAYAGG(JSON_OBJECT(\n" +
            "        'id', schedule_id,\n" +
            "        'date', date,\n" +
            "        'morning', morning,\n" +
            "        'afternoon', afternoon))\n" +
            "from schedule\n" +
            "where doctor_id = ?"

    fun getDepartmentSchedule(dataSource: DataSource, department_id: String): String {
        val scheduleList = ArrayList<Array<DetailedSchedule>>()
        var connection: Connection? = null
        try {
            connection = dataSource.connection
            val preparedStatement = connection.prepareStatement(department_query)
            preparedStatement.setObject(1, department_id)
            val resultSet = preparedStatement.executeQuery()
            while (resultSet.next()) {
                val json = resultSet.getString(1)
                val schedule = Gson().fromJson(json, Array<DetailedSchedule>::class.java)
                scheduleList.add(schedule)
            }
        } catch (e: SQLException) {
            e.printStackTrace()
        } finally {
            connection?.close()
        }
        return Gson().toJson(scheduleList)
    }

    fun getDoctorSchedule(dataSource: DataSource, doctor_id: String): String {
        var json = ""
        var connection: Connection? = null
        try {
            connection = dataSource.connection
            val preparedStatement = connection.prepareStatement(doctor_query)
            preparedStatement.setObject(1, doctor_id)
            val resultSet = preparedStatement.executeQuery()
            if (resultSet.next()) {
                json = resultSet.getString(1)
            }
        } catch (e: SQLException) {
            e.printStackTrace()
        } finally {
            connection?.close()
        }
        return json
    }
}