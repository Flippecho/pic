package per.baluth.dao

import com.google.gson.Gson
import per.baluth.model.OrderInfo
import per.baluth.model.QrCode
import per.baluth.pay.AliPay
import java.sql.Connection
import java.sql.SQLException
import java.sql.Statement
import javax.sql.DataSource

object OrderDao {
    private const val top_ten_orders_query = "select JSON_ARRAYAGG(JSON_OBJECT(\n" +
            "        'order_id', order_id,\n" +
            "        'sub_department_name', sub_department_name,\n" +
            "        'doctor_id', d.doctor_id,\n" +
            "        'doctor_name', doctor_name,\n" +
            "        'patient_name', username,\n" +
            "        'id_card', id_card,\n" +
            "        'telephone', d.telephone,\n" +
            "        'date', date,\n" +
            "        'is_morning', is_morning,\n" +
            "        'cost', cost,\n" +
            "        'order_status', order_status\n" +
            "    ))\n" +
            "from orders\n" +
            "         inner join sub_department sd on orders.sub_department_id = sd.sub_department_id\n" +
            "         inner join doctor d on orders.doctor_id = d.doctor_id\n" +
            "         inner join schedule s on orders.schedule_id = s.schedule_id\n" +
            "         inner join user u on patient_id = u.user_id\n" +
            "where patient_id = ?\n" +
            "  and order_status != 3\n" +
            "order by date, create_time desc\n" +
            "limit 10"

    private const val orders_query = "select order_id,\n" +
            "       sub_department_name,\n" +
            "       d.doctor_id,\n" +
            "       doctor_name,\n" +
            "       username,\n" +
            "       id_card,\n" +
            "       telephone,\n" +
            "       date,\n" +
            "       is_morning,\n" +
            "       cost,\n" +
            "       order_status\n" +
            "from orders\n" +
            "         inner join sub_department sd on orders.sub_department_id = sd.sub_department_id\n" +
            "         inner join doctor d on orders.doctor_id = d.doctor_id\n" +
            "         inner join schedule s on orders.schedule_id = s.schedule_id\n" +
            "         inner join user u on patient_id = u.user_id\n" +
            "where patient_id = ?\n" +
            "  and order_status != 3\n" +
            "order by order_status, date, create_time"

    fun createOrder(dataSource: DataSource, order: String): Long {
        var id = 0L
        var connection: Connection? = null
        try {
            connection = dataSource.connection
            val orderInfo = Gson().fromJson(order, OrderInfo::class.java)
            val preparedStatement =
                connection.prepareStatement(
                    "insert into orders(sub_department_id, doctor_id, schedule_id, is_morning, cost, payment_id, patient_id, create_time, user_id) VALUE(?,?,?,?,?,?,?,now(),?)",
                    Statement.RETURN_GENERATED_KEYS
                )
            preparedStatement.setObject(1, orderInfo.sub_department_id)
            preparedStatement.setObject(2, orderInfo.doctor_id)
            preparedStatement.setObject(3, orderInfo.schedule_id)
            preparedStatement.setObject(4, orderInfo.isMorning)
            preparedStatement.setObject(5, orderInfo.cost)
            preparedStatement.setObject(6, orderInfo.payment_id)
            preparedStatement.setObject(7, orderInfo.patient_id)
            preparedStatement.setObject(8, orderInfo.patient_id)
            preparedStatement.executeUpdate()

            val resultSet = preparedStatement.generatedKeys
            if (resultSet.next()) {
                id = resultSet.getLong(1)
            }

            restDecrease(dataSource, orderInfo.isMorning, orderInfo.schedule_id)

        } catch (e: SQLException) {
            e.printStackTrace()
        } finally {
            connection?.close()
        }

        return id
    }

    fun setQrCode(dataSource: DataSource, id: String, qrCode: String) {
        var connection: Connection? = null
        try {
            connection = dataSource.connection
            val preparedStatement = connection.prepareStatement("update orders set qr_code = ? where order_id = ?")
            preparedStatement.setObject(1, qrCode)
            preparedStatement.setObject(2, id)
            preparedStatement.executeUpdate()
        } catch (e: SQLException) {
            e.printStackTrace()
        } finally {
            connection?.close()
        }
    }

    fun getQrCode(dataSource: DataSource, id: String): String {
        val qrCode = QrCode(false, "")
        var connection: Connection? = null
        try {
            connection = dataSource.connection
            val preparedStatement = connection.prepareStatement("select qr_code from orders where order_id = ?")
            preparedStatement.setObject(1, id)
            val resultSet = preparedStatement.executeQuery()
            if (resultSet.next()) {
                qrCode.qrCode = resultSet.getString(1)
                qrCode.succeed = true
            }
        } catch (e: SQLException) {
            e.printStackTrace()
        } finally {
            connection?.close()
        }
        return Gson().toJson(qrCode)
    }

    private fun restDecrease(dataSource: DataSource, isMorning: Boolean, id: Int) {
        var connection: Connection? = null
        try {
            connection = dataSource.connection
            val preparedStatement =
                if (isMorning) connection.prepareStatement("update schedule set morning = morning-1 where schedule_id = ?")
                else connection.prepareStatement("update schedule set afternoon = afternoon -1 where schedule_id = ?")
            preparedStatement.setObject(1, id)
            preparedStatement.executeUpdate()
        } catch (e: SQLException) {
            e.printStackTrace()
        } finally {
            connection?.close()
        }
    }

    fun cancelIfNotPaid(dataSource: DataSource, order: String, id: Long) {
        if (checkIsUnpaid(dataSource, id)) {
            val orderInfo = Gson().fromJson(order, OrderInfo::class.java)
            restIncrease(dataSource, orderInfo.isMorning, orderInfo.schedule_id)
            var connection: Connection? = null
            try {
                connection = dataSource.connection
                val preparedStatement =
                    connection.prepareStatement("update orders set order_status = 3 where order_id = ?")
                preparedStatement.setObject(1, id)
                preparedStatement.executeUpdate()
            } catch (e: SQLException) {
                e.printStackTrace()
            } finally {
                connection?.close()
            }
        }
    }

    private fun checkIsUnpaid(dataSource: DataSource, id: Long): Boolean {
        var state = true
        var connection: Connection? = null
        try {
            connection = dataSource.connection
            val preparedStatement = connection.prepareStatement("select order_status from orders where order_id = ?")
            preparedStatement.setObject(1, id)
            val resultSet = preparedStatement.executeQuery()

            if (resultSet.next()) {
                val status = resultSet.getInt(1)
                state = status == 0
            }

        } catch (e: SQLException) {
            e.printStackTrace()
        } finally {
            connection?.close()
        }
        return state
    }

    private fun restIncrease(dataSource: DataSource, isMorning: Boolean, id: Int) {
        var connection: Connection? = null
        try {
            connection = dataSource.connection
            val preparedStatement =
                if (isMorning) connection.prepareStatement("update schedule set morning = morning + 1 where schedule_id = ?")
                else connection.prepareStatement("update schedule set afternoon = afternoon + 1 where schedule_id = ?")
            preparedStatement.setObject(1, id)
            preparedStatement.executeUpdate()
        } catch (e: SQLException) {
            e.printStackTrace()
        } finally {
            connection?.close()
        }
    }

    fun getFirstTenOrders(dataSource: DataSource, id: String): String {
        var json: String? = null
        var connection: Connection? = null
        try {
            connection = dataSource.connection
            val preparedStatement = connection.prepareStatement(top_ten_orders_query)
            preparedStatement.setObject(1, id)
            val resultSet = preparedStatement.executeQuery()
            if (resultSet.next()) {
                json = resultSet.getString(1)
            }
        } catch (e: SQLException) {
            e.printStackTrace()
        } finally {
            connection?.close()
        }
        return json ?: "[]"
    }

    fun getOrderStatus(dataSource: DataSource, id: String): Int {
        var status = 0
        var connection: Connection? = null
        try {
            connection = dataSource.connection
            val preparedStatement = connection.prepareStatement("select order_status from orders where order_id = ?")
            preparedStatement.setObject(1, id)
            val resultSet = preparedStatement.executeQuery()
            if (resultSet.next()) {
                status = resultSet.getInt(1)
            }
        } catch (e: SQLException) {
            e.printStackTrace()
        } finally {
            connection?.close()
        }
        return status
    }

    fun setOrderStatus(dataSource: DataSource, id: Int, status: Int) {
        var connection: Connection? = null
        try {
            connection = dataSource.connection
            val preparedStatement = connection.prepareStatement("update orders set order_status = ? where order_id = ?")
            preparedStatement.setObject(1, status)
            preparedStatement.setObject(2, id)
            preparedStatement.executeUpdate()
        } catch (e: SQLException) {
            e.printStackTrace()
        } finally {
            connection?.close()
        }
    }

    private fun getOrderCost(dataSource: DataSource, id: String): Int {
        var cost = 0
        var connection: Connection? = null
        try {
            connection = dataSource.connection
            val preparedStatement = connection.prepareStatement("select cost from orders where order_id = ?")
            preparedStatement.setObject(1, id)
            val resultSet = preparedStatement.executeQuery()
            if (resultSet.next()) {
                cost = resultSet.getInt(1)
            }
        } catch (e: SQLException) {
            e.printStackTrace()
        } finally {
            connection?.close()
        }
        return cost
    }

     fun getOrderId(dataSource: DataSource, doctorId: String, patientId: String): Int {
        var id = 0
        var connection: Connection? = null
        try {
            connection = dataSource.connection
            val preparedStatement = connection.prepareStatement("select order_id\n" +
                    "from orders\n" +
                    "         inner join schedule s on orders.schedule_id = s.schedule_id\n" +
                    "where date = 1\n" +
                    "  and s.doctor_id = ?\n" +
                    "  and patient_id = ?")
            preparedStatement.setObject(1, doctorId)
            preparedStatement.setObject(2, patientId)
            val resultSet = preparedStatement.executeQuery()
            if (resultSet.next()) {
                id = resultSet.getInt(1)
            }
        } catch (e: SQLException) {
            e.printStackTrace()
        } finally {
            connection?.close()
        }
        return id
    }

    private fun getOrderIsMorning(dataSource: DataSource, id: String): Boolean {
        var isMorning = true
        var connection: Connection? = null
        try {
            connection = dataSource.connection
            val preparedStatement = connection.prepareStatement("select is_morning from orders where order_id = ?")
            preparedStatement.setObject(1, id)
            val resultSet = preparedStatement.executeQuery()
            if (resultSet.next()) {
                isMorning = resultSet.getBoolean(1)
            }
        } catch (e: SQLException) {
            e.printStackTrace()
        } finally {
            connection?.close()
        }
        return isMorning
    }

    fun cancelOrder(dataSource: DataSource, id: String): Boolean {
        val cost = getOrderCost(dataSource, id)
        val result = AliPay.tradeRefund(id, cost)
        if (result) {
            setOrderStatus(dataSource, id.toInt(), 4)
            val isMorning = getOrderIsMorning(dataSource, id)
            restIncrease(dataSource, isMorning, id.toInt())
        }
        return result
    }

    fun getCancelCount(dataSource: DataSource, id: String): Int {
        var count = 0
        var connection: Connection? = null
        try {
            connection = dataSource.connection
            val preparedStatement =
                connection.prepareStatement("select count(*) from orders where user_id = ? and order_status = 4 and DATE_SUB(now(), INTERVAL 30 DAY) <= create_time")
            preparedStatement.setObject(1, id)
            val resultSet = preparedStatement.executeQuery()
            if (resultSet.next()) {
                count = resultSet.getInt(1)
            }
        } catch (e: SQLException) {
            e.printStackTrace()
        } finally {
            connection?.close()
        }
        return count
    }

    fun getOrderCountStatus(
        dataSource: DataSource,
        userId: String,
        scheduleId: String,
        isMorning: Boolean,
        departmentId: String
    ): Int {
        var count = getScheduleCount(dataSource, userId, scheduleId, isMorning)
        if (count >= 1) return 1
        count = getDepartmentCount(dataSource, userId, departmentId)
        if (count >= 3) return 2
        count = getUserCount(dataSource, userId)
        if (count >= 7) return 3
        return 0
    }

    private fun getScheduleCount(dataSource: DataSource, userId: String, scheduleId: String, isMorning: Boolean): Int {
        val query = "select count(*)\n" +
                "from orders\n" +
                "         inner join sub_department sd on orders.sub_department_id = sd.sub_department_id\n" +
                "where user_id = ?\n" +
                "  and (order_status = 0 or order_status = 1)\n" +
                "  and schedule_id = ?\n" +
                "  and is_morning = ?"

        var count = 0
        var connection: Connection? = null
        try {
            connection = dataSource.connection
            val prepareStatement = connection.prepareStatement(query)
            prepareStatement.setObject(1, userId)
            prepareStatement.setObject(2, scheduleId)
            prepareStatement.setObject(3, isMorning)
            val resultSet = prepareStatement.executeQuery()
            if (resultSet.next()) {
                count = resultSet.getInt(1)
            }
        } catch (e: SQLException) {
            e.printStackTrace()
        } finally {
            connection?.close()
        }
        return count
    }

    private fun getDepartmentCount(dataSource: DataSource, userId: String, departmentId: String): Int {
        val query = "select count(*)\n" +
                "from orders\n" +
                "         inner join sub_department sd on orders.sub_department_id = sd.sub_department_id\n" +
                "where user_id = ?\n" +
                "  and (order_status = 0 or order_status = 1)\n" +
                "  and department_id = ?"

        var count = 0
        var connection: Connection? = null
        try {
            connection = dataSource.connection
            val prepareStatement = connection.prepareStatement(query)
            prepareStatement.setObject(1, userId)
            prepareStatement.setObject(2, departmentId)
            val resultSet = prepareStatement.executeQuery()
            if (resultSet.next()) {
                count = resultSet.getInt(1)
            }
        } catch (e: SQLException) {
            e.printStackTrace()
        } finally {
            connection?.close()
        }
        return count
    }

    private fun getUserCount(dataSource: DataSource, userId: String): Int {
        val query = "select count(*)\n" +
                "from orders\n" +
                "         inner join sub_department sd on orders.sub_department_id = sd.sub_department_id\n" +
                "where user_id = ?\n" +
                "  and (order_status = 0 or order_status = 1)"

        var count = 0
        var connection: Connection? = null
        try {
            connection = dataSource.connection
            val prepareStatement = connection.prepareStatement(query)
            prepareStatement.setObject(1, userId)
            val resultSet = prepareStatement.executeQuery()
            if (resultSet.next()) {
                count = resultSet.getInt(1)
            }
        } catch (e: SQLException) {
            e.printStackTrace()
        } finally {
            connection?.close()
        }
        return count
    }

    fun getPatientOrderStatus(dataSource: DataSource, patientId: String, doctorId: String): String {
        val queryHasFinished = "0"
        val queryOtherDoctor = "1"
        val queryNotFound = "2"

        return if (checkIfHasDoctorOrder(dataSource, patientId, doctorId)) {
            getPatientName(dataSource, patientId)
        } else if (checkIfOrderFinished(dataSource, patientId, doctorId)) {
            queryHasFinished
        } else if (checkIfHasOtherOrder(dataSource, patientId)) {
            queryOtherDoctor
        } else {
            queryNotFound
        }
    }

    private fun getPatientName(dataSource: DataSource, patientId: String): String {
        var name = ""
        var connection: Connection? = null
        try {
            connection = dataSource.connection
            val prepareStatement = connection.prepareStatement("select username from user where user_id = ?")
            prepareStatement.setObject(1, patientId)
            val resultSet = prepareStatement.executeQuery()
            if (resultSet.next()) {
                name = resultSet.getString(1)
            }
        } catch (e: SQLException) {
            e.printStackTrace()
        } finally {
            connection?.close()
        }
        return name
    }

    private fun checkIfHasDoctorOrder(dataSource: DataSource, patientId: String, doctorId: String): Boolean {
        var result = false
        var connection: Connection? = null
        try {
            connection = dataSource.connection
            val prepareStatement = connection.prepareStatement(
                "select count(*)\n" +
                        "from orders\n" +
                        "         inner join schedule s on orders.schedule_id = s.schedule_id\n" +
                        "where date = 1\n" +
                        "  and patient_id = ?\n" +
                        "  and s.doctor_id = ?\n" +
                        "  and order_status = 1"
            )
            prepareStatement.setObject(1, patientId)
            prepareStatement.setObject(2, doctorId)
            val resultSet = prepareStatement.executeQuery()
            if (resultSet.next()) {
                result = resultSet.getInt(1) >= 1
            }
        } catch (e: SQLException) {
            e.printStackTrace()
        } finally {
            connection?.close()
        }
        return result
    }

    private fun checkIfOrderFinished(dataSource: DataSource, patientId: String, doctorId: String): Boolean {
        var result = false
        var connection: Connection? = null
        try {
            connection = dataSource.connection
            val prepareStatement = connection.prepareStatement(
                "select count(*)\n" +
                        "from orders\n" +
                        "         inner join schedule s on orders.schedule_id = s.schedule_id\n" +
                        "where date = 1\n" +
                        "  and patient_id = ?\n" +
                        "  and s.doctor_id = ?\n" +
                        "  and order_status = 2"
            )
            prepareStatement.setObject(1, patientId)
            prepareStatement.setObject(2, doctorId)
            val resultSet = prepareStatement.executeQuery()
            if (resultSet.next()) {
                result = resultSet.getInt(1) >= 1
            }
        } catch (e: SQLException) {
            e.printStackTrace()
        } finally {
            connection?.close()
        }
        return result
    }

    private fun checkIfHasOtherOrder(dataSource: DataSource, patientId: String): Boolean {
        var result = false
        var connection: Connection? = null
        try {
            connection = dataSource.connection
            val prepareStatement = connection.prepareStatement(
                "select count(*)\n" +
                        "from orders\n" +
                        "         inner join schedule s on orders.schedule_id = s.schedule_id\n" +
                        "where date = 1\n" +
                        "  and patient_id = ?\n" +
                        "  and order_status = 1"
            )
            prepareStatement.setObject(1, patientId)
            val resultSet = prepareStatement.executeQuery()
            if (resultSet.next()) {
                result = resultSet.getInt(1) >= 1
            }
        } catch (e: SQLException) {
            e.printStackTrace()
        } finally {
            connection?.close()
        }
        return result
    }
}