package per.baluth.dao

import com.google.gson.Gson
import per.baluth.model.Rest
import java.sql.Connection
import java.sql.SQLException
import javax.sql.DataSource

object RestDao {

    fun getRest(dataSource: DataSource, id: String): String {
        var morning = 0
        var afternoon = 0
        var connection: Connection? = null
        try {
            connection = dataSource.connection
            val preparedStatement =
                connection.prepareStatement("select morning, afternoon from schedule where schedule_id = ?")
            preparedStatement.setObject(1, id)
            val resultSet = preparedStatement.executeQuery()
            if (resultSet.next()) {
                morning = resultSet.getInt(1)
                afternoon = resultSet.getInt(2)
            }
        } catch (e: SQLException) {
            e.printStackTrace()
        } finally {
            connection?.close()
        }

        return Gson().toJson(Rest(morning, afternoon))
    }
}