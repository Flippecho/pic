package per.baluth.plugins

import com.alipay.api.domain.AlipayTradePrecreateModel
import com.google.gson.Gson
import io.ktor.http.*
import io.ktor.server.application.*
import io.ktor.server.http.content.*
import io.ktor.server.response.*
import io.ktor.server.routing.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import per.baluth.Repository
import per.baluth.model.Identifier
import per.baluth.model.PayResponse
import per.baluth.pay.AliPay
import per.baluth.widthTo


fun Application.configureRouting() {

    routing {
        static {
            defaultResource("index.html", "static")
            resources("static")
        }

        get("/test") {
            call.respondText("https://www.baidu.com")
        }

        // schedule related
        get("/get_department") {
            val json = Repository.getDepartment()
            call.respondText(json, ContentType.Application.Json)
        }

        get("/get_schedule_department") {
            val id = call.parameters["department_id"]
            if (id != null) {
                val json = Repository.getDepartmentSchedule(id)
                call.respondText(json, ContentType.Application.Json)
            }
        }

        get("/get_schedule_doctor") {
            val id = call.parameters["doctor_id"]
            if (id != null) {
                val json = Repository.getDoctorSchedule(id)
                call.respondText(json, ContentType.Application.Json)
            }
        }

        get("/get_rest") {
            val id = call.parameters["schedule_id"]
            if (id != null) {
                val json = Repository.getRest(id)
                call.respondText(json, ContentType.Application.Json)
            }
        }


        // doctor related
        get("/get_doctor_info") {
            val id = call.parameters["doctor_id"]
            if (id != null) {
                val json = Repository.getDoctorInfo(id)
                call.respondText(json, ContentType.Application.Json)
            }
        }

        get("/collect_doctor") {
            val userId = call.parameters["user_id"]
            val doctorId = call.parameters["doctor_id"]
            if (userId != null && doctorId != null) {
                call.respondText(Repository.collectDoctor(userId, doctorId).toString())
            }
        }

        get("/un_collect_doctor") {
            val userId = call.parameters["user_id"]
            val doctorId = call.parameters["doctor_id"]
            if (userId != null && doctorId != null) {
                call.respondText(Repository.unCollectDoctor(userId, doctorId).toString())
            }
        }

        get("/check_is_collected") {
            val userId = call.parameters["user_id"]
            val doctorId = call.parameters["doctor_id"]
            if (userId != null && doctorId != null) {
                call.respondText(Repository.checkIsCollected(userId, doctorId).toString())
            }
        }

        get("/get_doctor_collection") {
            val id = call.parameters["user_id"]
            if (id != null) {
                val json = Repository.getDoctorCollection(id)
                call.respondText(json, ContentType.Application.Json)
            }
        }

        get("/get_patient_count") {
            val id = call.parameters["doctor_id"]
            if (id != null) {
                call.respondText(Repository.getPatientCount(id.toInt().toString()).toString())
            }
        }


        // login related
        get("/get_verification_code") {
            val telephone = call.parameters["telephone"] ?: return@get

            Repository.registerIfHasNot(telephone)
            val code = (Math.random() * 8999 + 1000).toInt().toString()
            Repository.updateVerificationCode(telephone, code)
            Repository.sendSMS(code)

            // code expire after 5 minutes
            CoroutineScope(Job()).launch {
                delay(1000 * 60 * 5)
                if (Repository.isCodeMatch(telephone, code)) {
                    val newCode = (Math.random() * 8999 + 1000).toInt().toString()
                    Repository.updateVerificationCode(telephone, newCode)
                }
            }
            call.respondText("true")
        }

        get("/check_verification_code") {
            val telephone = call.parameters["telephone"]
            val code = call.parameters["code"]
            var result = false
            if (telephone != null && code != null) {
                result = Repository.isCodeMatch(telephone, code)
            }
            call.respondText(result.toString())
        }

        get("/get_register_status") {
            val telephone = call.parameters["telephone"]
            var status = 0
            if (telephone != null) {
                status = Repository.getRegisterStatus(telephone)
            }
            call.respondText(status.toString())
        }

        get("/check_identifier") {
            val id = call.parameters["id"]
            val name = call.parameters["name"]
            var result = false
            if (id != null && name != null) {
                result = name.startsWith("张")
            }
            call.respondText(result.toString())
        }

        get("/update_info") {
            var result = 0

            val telephone = call.parameters["telephone"]
            val id = call.parameters["id"]
            val name = call.parameters["name"]

            if (telephone != null && id != null && name != null) {
                result = Repository.updateInfo(telephone, id, name)
            }

            call.respondText(result.toString())
        }

        get("/get_identifier") {
            var identifier: Identifier? = null
            val telephone = call.parameters["telephone"]
            if (telephone != null) {
                identifier = Repository.getIdentifier(telephone)
            }
            call.respondText(Gson().toJson(identifier), ContentType.Application.Json)
        }

        get("/send_code") {
            val telephone = call.parameters["telephone"]
            val code = call.parameters["code"]
            if (telephone != null && code != null) {
                val hasRegistered = Repository.hasRegistered(telephone)
                if (hasRegistered) {
                    call.respondText("false")
                } else {
                    Repository.sendSMS(code)
                    call.respondText("true")
                }
            }
        }

        get("/change_telephone") {
            val id = call.parameters["user_id"]
            val telephone = call.parameters["telephone"]
            if (id != null && telephone != null) {
                Repository.changeTelephone(id, telephone)
                call.respondText("true")
            }
        }

        // web login related
        get("/get_verification_code_for_doctor") {
            val telephone = call.parameters["telephone"] ?: return@get

            val code = (Math.random() * 8999 + 1000).toInt().toString()
            Repository.updateVerificationCodeForDoctor(telephone, code)
            Repository.sendSMS(code)
            call.respondText("true")
        }

        get("/check_info_for_doctor") {
            val telephone = call.parameters["telephone"]
            val code = call.parameters["code"]
            val password = call.parameters["password"]
            var result = 0
            if (telephone != null && code != null && password != null) {
                result = Repository.isInfoMatchForDoctor(telephone, code, password)
            }
            call.respondText(result.toString())
        }


        // order related
        get("/submit_order") {
            val json = call.parameters["order"]
            val id: Long
            if (json != null) {
                id = Repository.createOrder(json)

                val model = AlipayTradePrecreateModel()
                model.timeoutExpress = "15m"
                model.qrCodeTimeoutExpress = "15m"
                model.outTradeNo = id.widthTo(11)
                model.totalAmount = "0.01"
                model.subject = "Hospital 挂号费 测试"
                val payResponse = AliPay.preCreate(model)
                val qrCode = Gson().fromJson(payResponse, PayResponse::class.java).qr_code
                Repository.setQrCode(id.toString(), qrCode)

                // order expire after 15 minutes
                CoroutineScope(Job()).launch {
                    delay(1000 * 60 * 15)
                    Repository.cancelIfNotPaid(json, id)
                }
                call.respondText(payResponse, ContentType.Application.Json)
            }
        }

        get("/get_qr_code") {
            val id = call.parameters["order_id"]
            if (id != null) {
                call.respondText(Repository.getQrCode(id))
            }
        }

        get("/get_order_status") {
            val id = call.parameters["order_id"]
            if (id != null) {
                val status = Repository.getOrderStatus(id)
                call.respondText(status.toString())
            }
        }

        get("/get_first_ten_orders") {
            val id = call.parameters["patient_id"]
            if (id != null) {
                val json = Repository.getFirstTenOrders(id)
                call.respondText(json, ContentType.Application.Json)
            }
        }

        get("/cancel_order") {
            val id = call.parameters["order_id"]
            if (id != null) {
                call.respondText(Repository.cancelOrder(id).toString())
            }
        }

        get("/get_cancel_count") {
            val id = call.parameters["user_id"]
            if (id != null) {
                call.respondText(Repository.getCancelCount(id).toString())
            }
        }

        get("/get_order_count_status") {
            val userId = call.parameters["user_id"]
            val scheduleId = call.parameters["schedule_id"]
            val isMorning = call.parameters["is_morning"]
            val subDepartmentId = call.parameters["sub_department_id"]
            if (userId != null && scheduleId != null && isMorning != null && subDepartmentId != null) {
                val departmentId = Repository.getDepartmentId(subDepartmentId).toString()
                val status = Repository.getOrderCountStatus(userId, scheduleId, isMorning.toBoolean(), departmentId)
                call.respondText(status.toString())
            }
        }

        get("/get_patient_order_status") {
            val patientId = call.parameters["patient_id"]
            val doctorId = call.parameters["doctor_id"]
            if (patientId != null && doctorId != null) {
                call.respondText(Repository.getPatientOrderStatus(patientId, doctorId))
            }
        }

        get("/finish_order") {
            val patientId = call.parameters["patient_id"]
            val doctorId = call.parameters["doctor_id"]
            if (patientId != null && doctorId != null) {
                Repository.increasePatientAmount(doctorId)
                val orderId = Repository.getOrderId(doctorId, patientId)
                Repository.setOrderStatus(orderId, 2)
            }
        }
    }

}
