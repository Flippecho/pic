package per.baluth.pay

import com.alipay.api.AlipayClient
import com.alipay.api.AlipayConfig
import com.alipay.api.DefaultAlipayClient
import com.alipay.api.domain.AlipayTradeCancelModel
import com.alipay.api.domain.AlipayTradePrecreateModel
import com.alipay.api.domain.AlipayTradeQueryModel
import com.alipay.api.domain.AlipayTradeRefundModel
import com.alipay.api.request.AlipayTradeCancelRequest
import com.alipay.api.request.AlipayTradePrecreateRequest
import com.alipay.api.request.AlipayTradeQueryRequest
import com.alipay.api.request.AlipayTradeRefundRequest
import com.alipay.api.response.AlipayTradePrecreateResponse
import com.google.gson.Gson
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import per.baluth.Repository
import per.baluth.model.AlipayPreCreateBody
import per.baluth.model.AlipayRefundBody
import per.baluth.model.AlipayTradeQueryBody


object AliPay {
    private const val url = "https://openapi.alipay.com/gateway.do"
    // use your own config
    private const val privateKey = ""
    private const val alipayPublicKey = ""
    private const val appId = ""

    fun preCreate(model: AlipayTradePrecreateModel): String {
        var payResponse = ""
        val alipayConfig = AlipayConfig()
        alipayConfig.serverUrl = url
        alipayConfig.appId = appId
        alipayConfig.privateKey = privateKey
        alipayConfig.format = "json"
        alipayConfig.alipayPublicKey = alipayPublicKey
        alipayConfig.charset = "UTF8"
        alipayConfig.signType = "RSA2"
        val alipayClient: AlipayClient = DefaultAlipayClient(alipayConfig)
        val request = AlipayTradePrecreateRequest()
        request.bizModel = model
        val response: AlipayTradePrecreateResponse = alipayClient.execute(request)
        println(response.body)
        if (response.isSuccess) {
            println("调用成功")
            val body = Gson().fromJson(response.body, AlipayPreCreateBody::class.java)
            val outTradeNo = body.alipay_trade_precreate_response.out_trade_no
            val orderId = outTradeNo.toInt()
            payResponse = Gson().toJson(body.alipay_trade_precreate_response)

            val job = Job()
            CoroutineScope(job).launch {
                repeat(12 * 15) {
                    val hasPaid = tradeQuery(body.alipay_trade_precreate_response.out_trade_no)
                    if (hasPaid) {
                        Repository.setOrderStatus(orderId, 1)
                        job.cancel()
                    }
                    delay(5 * 1000)
                }
                val hasPaid = tradeQuery(body.alipay_trade_precreate_response.out_trade_no)
                if (hasPaid) {
                    Repository.setOrderStatus(orderId, 1)
                } else {
                    tradeCancel(outTradeNo)
                }
            }
        } else {
            println("调用失败")
        }

        return payResponse
    }

    private fun tradeQuery(outTradeNo: String): Boolean {
        var hasPaid = false
        val alipayConfig = AlipayConfig()
        alipayConfig.serverUrl = url
        alipayConfig.appId = appId
        alipayConfig.privateKey = privateKey
        alipayConfig.format = "json"
        alipayConfig.alipayPublicKey = alipayPublicKey
        alipayConfig.charset = "UTF8"
        alipayConfig.signType = "RSA2"
        val alipayClient: AlipayClient = DefaultAlipayClient(alipayConfig)
        val request = AlipayTradeQueryRequest()
        val model = AlipayTradeQueryModel()
        model.outTradeNo = outTradeNo
        request.bizModel = model
        val response = alipayClient.execute(request)
        if (response.isSuccess) {
            println("调用成功")
            val tradeStatus = Gson().fromJson(
                response.body,
                AlipayTradeQueryBody::class.java
            ).alipay_trade_query_response.trade_status
            hasPaid = tradeStatus == "TRADE_SUCCESS"
        } else {
            println("调用失败")
        }
        return hasPaid
    }

    private fun tradeCancel(outTradeNo: String) {
        val alipayConfig = AlipayConfig()
        alipayConfig.serverUrl = url
        alipayConfig.appId = appId
        alipayConfig.privateKey = privateKey
        alipayConfig.format = "json"
        alipayConfig.alipayPublicKey = alipayPublicKey
        alipayConfig.charset = "UTF8"
        alipayConfig.signType = "RSA2"
        val alipayClient: AlipayClient = DefaultAlipayClient(alipayConfig)
        val request = AlipayTradeCancelRequest()
        val model = AlipayTradeCancelModel()
        model.outTradeNo = outTradeNo
        request.bizModel = model
        val response = alipayClient.execute(request)
        if (response.isSuccess) {
            println("调用成功")
        } else {
            println("调用失败")
        }
    }

    fun tradeRefund(outTradeNo: String, cost: Int): Boolean {
        var isSuccess = false
        val alipayConfig = AlipayConfig()
        alipayConfig.serverUrl = url
        alipayConfig.appId = appId
        alipayConfig.privateKey = privateKey
        alipayConfig.format = "json"
        alipayConfig.alipayPublicKey = alipayPublicKey
        alipayConfig.charset = "UTF8"
        alipayConfig.signType = "RSA2"
        val alipayClient: AlipayClient = DefaultAlipayClient(alipayConfig)
        val request = AlipayTradeRefundRequest()
        val model = AlipayTradeRefundModel()
        model.outTradeNo = outTradeNo
//        model.refundAmount = cost.toString()
        model.refundAmount = "0.01"     // test only
        request.bizModel = model
        val response = alipayClient.execute(request)
        println(response.body)
        if (response.isSuccess) {
            val refundResponse = Gson().fromJson(response.body, AlipayRefundBody::class.java).alipay_trade_refund_response
            val status = refundResponse.code
            isSuccess = status == 10000 && refundResponse.fund_change == "Y"
            println("调用成功")
        } else {
            println("调用失败")
            println(outTradeNo)
        }

        return isSuccess
    }
}