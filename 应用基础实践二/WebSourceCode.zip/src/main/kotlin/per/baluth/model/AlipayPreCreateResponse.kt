package per.baluth.model

data class AlipayPreCreateResponse(val code: Int, val msg: String, val out_trade_no: String, val qr_code: String)
