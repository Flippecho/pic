package per.baluth.model

data class BriefSchedule(val id: Int, val date: Int, val morning: Int, val afternoon: Int)
