package per.baluth.model

data class OrderInfo(
    val sub_department_id: Int,
    val sub_department_name: String,
    val doctor_id: Int,
    val doctor_name: String,
    val schedule_id: Int,
    val date: Int,
    val isMorning: Boolean,
    val cost: Int,
    val patient_id: Int,
    val payment_id: Int
)
