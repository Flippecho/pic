package per.baluth.model

data class AlipayPreCreateBody(val alipay_trade_precreate_response: AlipayPreCreateResponse)
