package per.baluth.model

data class AlipayTradeQueryResponse(val code: Int, val out_trade_no: Int, val trade_status: String)
