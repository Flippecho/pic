package per.baluth.model

data class Identifier(val id: Int, val username: String, val telephone: String, val id_card: String)