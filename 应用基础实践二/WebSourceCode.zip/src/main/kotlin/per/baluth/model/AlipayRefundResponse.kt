package per.baluth.model

data class AlipayRefundResponse(
    val code: Int,
    val msg: String,
    val sub_code: String,
    val sub_msg: String,
    val refund_fee: Double,
    val send_back_fee: Double,
    val fund_change: String
)
