package per.baluth.model

data class Rest(val morning: Int, val afternoon: Int)
