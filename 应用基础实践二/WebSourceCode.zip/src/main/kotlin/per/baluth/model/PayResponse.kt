package per.baluth.model

data class PayResponse(
    val code: Int,
    val msg: String,
    val out_trade_no: String,
    val qr_code: String
)
