package per.baluth.model

data class AlipayRefundBody(val alipay_trade_refund_response: AlipayRefundResponse)
