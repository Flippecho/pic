package per.baluth.model

data class AlipayTradeQueryBody(val alipay_trade_query_response: AlipayTradeQueryResponse)
