package per.baluth.model

data class QrCode(var succeed: Boolean ,var qrCode: String)
