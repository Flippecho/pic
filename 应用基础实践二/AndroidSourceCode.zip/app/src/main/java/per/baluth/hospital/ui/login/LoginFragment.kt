package per.baluth.hospital.ui.login

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import androidx.core.content.ContextCompat
import androidx.core.widget.doAfterTextChanged
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import kotlinx.coroutines.*
import per.baluth.hospital.R
import per.baluth.hospital.clickFeedback
import per.baluth.hospital.databinding.FragmentLoginBinding
import per.baluth.hospital.isValidId
import per.baluth.hospital.logic.model.Identifier
import per.baluth.hospital.toast
import java.time.Duration
import java.time.LocalTime
import java.util.*

class LoginFragment : Fragment() {
    private var job: Job? = null
    private var _binding: FragmentLoginBinding? = null
    private val binding: FragmentLoginBinding get() = _binding!!
    private val viewModel by lazy { ViewModelProvider(this)[LoginViewModel::class.java] }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentLoginBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val imm =
            requireContext().getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager

        hideProgress()

        binding.telephoneEditText.doAfterTextChanged {
            val telephone = binding.telephoneEditText.text.toString()
            if (telephone.length == 11) {
                binding.telephoneEditText.imeOptions = EditorInfo.IME_ACTION_NEXT
                imm.restartInput(binding.telephoneEditText)
                binding.codeButton.isEnabled = true

                binding.telephoneFormatState.text = getString(R.string.login_hint)
                val color =
                    ContextCompat.getColor(requireContext(), R.color.telephone_format_default)
                binding.telephoneFormatState.setTextColor(color)
            } else {
                binding.telephoneEditText.imeOptions = EditorInfo.IME_ACTION_DONE
                imm.restartInput(binding.telephoneEditText)
                binding.codeButton.isEnabled = false
            }
        }

        binding.telephoneEditText.setOnFocusChangeListener { _, hasFocus ->
            val telephone = binding.telephoneEditText.text.toString()

            if (!hasFocus && telephone.length != 11) {
                binding.telephoneFormatState.text = getString(R.string.login_hint_error)
                val colorRed = ContextCompat.getColor(requireContext(), R.color.red)
                binding.telephoneFormatState.setTextColor(colorRed)
            }
        }

        binding.codeButton.setOnClickListener {
            clickFeedback(it)

            val telephone = binding.telephoneEditText.text.toString()
            binding.telephoneEditText.isEnabled = false
            binding.codeButton.isEnabled = false
            viewModel.getVerificationCode(telephone)

            var countDown = viewModel.startWaiting(telephone)

            viewModel.increaseRetry()
            binding.verificationEditText.requestFocus()

            job = Job()
            CoroutineScope(job!!).launch {
                repeat(countDown) {
                    withContext(Dispatchers.Main) {
                        binding.codeButton.text = "等待 $countDown 秒"
                        countDown--
                    }
                    delay(1000)
                }

                withContext(Dispatchers.Main) {
                    binding.telephoneEditText.isEnabled = true
                    binding.codeButton.text = getString(R.string.get_verification)
                    binding.codeButton.isEnabled = binding.telephoneEditText.text.length == 11
                }
            }
        }

        binding.verificationEditText.doAfterTextChanged {
            val telephone = binding.telephoneEditText.text.toString()
            val code = binding.verificationEditText.text.toString()

            if (code.length == 4) {
                binding.title.text = "正在登录 Hospital"
                showProgress()

                CoroutineScope(Job()).launch {
                    val result = viewModel.checkVerificationCode(telephone, code)
                    withContext(Dispatchers.Main) {
                        delay(1000)
                        hideProgress()
                        binding.title.text = "欢迎登录 Hospital"

                        if (result) {
                            "登录成功".toast()
                            viewModel.resetRetry()
                            val registerStatus = viewModel.getRegisterStatus(telephone)
                            if (registerStatus == 0) {
                                binding.loginLayout.visibility = View.GONE
                                binding.authenticationLayout.visibility = View.VISIBLE
                                binding.title.text = "补全实名信息"
                                binding.cardId.requestFocus()
                            } else {
                                val identifier = viewModel.getIdentifier(telephone)
                                viewModel.setIdentifier(identifier)
                                requireActivity().finish()
                            }
                        } else {
                            "登录失败".toast()
                            binding.verificationEditText.setText("")
                            binding.verificationEditText.requestFocus()
                        }
                    }
                }
            }
        }

        binding.cardId.doAfterTextChanged {
            val content = binding.cardId.text.toString()
            if (content.isValidId()) {
                val color =
                    ContextCompat.getColor(requireContext(), R.color.telephone_format_default)
                binding.authenticationState.setTextColor(color)
                binding.authenticationState.text = getString(R.string.hint_authentication_default)
                binding.cardId.imeOptions = EditorInfo.IME_ACTION_NEXT
                imm.restartInput(binding.cardId)
                if (binding.realName.text.length >= 2) {
                    binding.authenticationButton.isEnabled = true
                }
            } else {
                binding.cardId.imeOptions = EditorInfo.IME_ACTION_DONE
            }
        }

        binding.cardId.setOnFocusChangeListener { _, hasFocus ->
            val content = binding.cardId.text.toString().replace("\\s".toRegex(), "")
            if (!hasFocus && !content.isValidId()) {
                val colorRed = ContextCompat.getColor(requireContext(), R.color.red)
                binding.authenticationState.setTextColor(colorRed)
                binding.authenticationState.text = getString(R.string.hint_authentication_error)
            }
        }

        binding.realName.doAfterTextChanged {
            val content = binding.realName.text.toString().replace("\\s".toRegex(), "")
            if (content.length >= 2 && binding.cardId.text.toString().isValidId()) {
                binding.authenticationButton.isEnabled = true
                binding.realName.imeOptions = EditorInfo.IME_ACTION_SEND
            } else {
                binding.authenticationButton.isEnabled = false
                binding.realName.imeOptions = EditorInfo.IME_ACTION_DONE
            }
            imm.restartInput(binding.realName)
        }

        binding.authenticationButton.setOnClickListener {
            clickFeedback(it)

            val name = binding.realName.text.toString()
            val id = binding.cardId.text.toString()
            val telephone = binding.telephoneEditText.text.toString()
            showProgress()

            binding.cardId.isEnabled = false
            binding.realName.isEnabled = false

            CoroutineScope(Job()).launch {
                val passed = viewModel.checkIdentifier(id, name)
                delay(1000)
                hideProgress()

                if (passed) {
                    val userId = viewModel.updateInfo(telephone, id, name)
                    val identifier = Identifier(userId, name, telephone, id)
                    viewModel.setIdentifier(identifier)
                    requireActivity().finish()
                } else {
                    "实名认证失败".toast()
                    withContext(Dispatchers.Main) {
                        binding.cardId.isEnabled = true
                        binding.realName.isEnabled = true
                    }
                }

            }
        }
    }

    override fun onResume() {
        super.onResume()

        viewModel.restoreTimer()

        if (viewModel.isWaiting()) {
            binding.telephoneEditText.setText(viewModel.getTelephone())
            binding.telephoneEditText.isEnabled = false
            binding.codeButton.isEnabled = false
            var countDown = Date().time - viewModel.getEndTime()

            job = Job()
            CoroutineScope(job!!).launch {
                repeat(countDown.toInt()) {
                    withContext(Dispatchers.Main) {
                        binding.codeButton.text = "等待 $countDown 秒"
                        countDown--
                    }
                    delay(1000)
                }

                withContext(Dispatchers.Main) {
                    binding.telephoneEditText.isEnabled = true
                    binding.codeButton.text = getString(R.string.get_verification)
                    binding.codeButton.isEnabled = binding.telephoneEditText.text.length == 11
                }
            }
        }
    }

    override fun onPause() {
        super.onPause()
        viewModel.storeTimer()
        job?.cancel()
        job = null
    }

    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }

    private fun showProgress() {
        CoroutineScope(Job()).launch {
            withContext(Dispatchers.Main) {
                binding.progress.visibility = View.VISIBLE
                binding.divider.visibility = View.GONE
            }
        }
    }

    private fun hideProgress() {
        CoroutineScope(Job()).launch {
            withContext(Dispatchers.Main) {
                binding.progress.visibility = View.GONE
                binding.divider.visibility = View.VISIBLE
            }
        }
    }
}