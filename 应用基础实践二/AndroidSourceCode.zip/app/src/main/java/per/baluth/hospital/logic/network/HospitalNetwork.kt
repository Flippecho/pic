package per.baluth.hospital.logic.network

import android.util.Log
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.coroutines.suspendCoroutine

object HospitalNetwork {
    private val service = ServiceCreator.create(HospitalService::class.java)

    suspend fun getDepartment() = service.getDepartment().await()

    suspend fun getDepartmentSchedule(id: Int) = service.getDepartmentSchedule(id).await()

    suspend fun getDoctorSchedule(id: Int) = service.getDoctorSchedule(id).await()

    suspend fun getVerificationCode(telephone: String) =
        service.getVerificationCode(telephone).await()

    suspend fun checkVerificationCode(telephone: String, code: String) =
        service.checkVerificationCode(telephone, code).await()

    suspend fun getRegisterStatus(telephone: String) = service.getRegisterStatus(telephone).await()

    suspend fun updateInfo(telephone: String, id: String, name: String) =
        service.updateInfo(telephone, id, name).await()

    suspend fun checkIdentifier(id: String, name: String) =
        service.checkIdentifier(id, name).await()

    suspend fun getIdentifier(telephone: String) = service.getIdentifier(telephone).await()

    suspend fun submitOrder(order: String) = service.submitOrder(order).await()

    suspend fun getFirstTenOrders(id: Int) = service.getFirstTenOrders(id).await()

    suspend fun getRest(id: Int) = service.getRest(id).await()

    suspend fun getOrderStatus(id: Int) = service.getOrderStatus(id).await()

    suspend fun cancelOrder(id: String) = service.cancelOrder(id).await()

    suspend fun getCancelCount(id: Int) = service.getCancelCount(id).await()

    suspend fun getQrCode(id: String) = service.getQrCode(id).await()

    suspend fun getDoctorInfo(id: Int) = service.getDoctorInfo(id).await()

    suspend fun collectDoctor(userId: Int, doctorId: Int) =
        service.collectDoctor(userId, doctorId).await()

    suspend fun unCollectDoctor(userId: Int, doctorId: Int) =
        service.unCollectDoctor(userId, doctorId).await()

    suspend fun checkIsCollected(userId: Int, doctorId: Int) =
        service.checkIsCollected(userId, doctorId).await()

    suspend fun getDoctorCollection(id: Int) = service.getDoctorCollection(id).await()

    suspend fun sendCode(telephone: String, code: Int) = service.sendCode(telephone, code).await()

    suspend fun changeTelephone(id: Int, telephone: String) =
        service.changeTelephone(id, telephone).await()

    suspend fun getOrderCountStatus(
        userId: Int,
        scheduleId: Int,
        isMorning: Boolean,
        subDepartmentId: Int
    ) = service.getOrderCountStatus(userId, scheduleId, isMorning, subDepartmentId).await()

    private suspend fun <T> Call<T>.await(): T {
        return suspendCoroutine { continuation ->
            enqueue(object : Callback<T> {
                override fun onResponse(call: Call<T>, response: Response<T>) {
                    val body = response.body()
                    if (body != null) continuation.resume(body)
                    else continuation.resumeWithException(RuntimeException("response body is null"))
                }

                override fun onFailure(call: Call<T>, t: Throwable) {
                    continuation.resumeWithException(t)
                }
            })
        }
    }
}