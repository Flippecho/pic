package per.baluth.hospital.ui.change_telephone

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import per.baluth.hospital.databinding.ActivityChangeTelephoneBinding

class ChangeTelephoneActivity : AppCompatActivity() {
    private lateinit var binding: ActivityChangeTelephoneBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityChangeTelephoneBinding.inflate(layoutInflater)
        setContentView(binding.root)
    }
}