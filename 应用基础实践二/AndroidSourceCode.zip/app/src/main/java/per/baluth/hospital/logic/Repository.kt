package per.baluth.hospital.logic

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import per.baluth.hospital.logic.dao.IdentifierDao
import per.baluth.hospital.logic.dao.LoginDao
import per.baluth.hospital.logic.dao.OrderDao
import per.baluth.hospital.logic.model.Identifier
import per.baluth.hospital.logic.network.HospitalNetwork
import retrofit2.await
import java.time.LocalTime

object Repository {
    suspend fun getDepartment() =
        withContext(Dispatchers.IO) {
            HospitalNetwork.getDepartment()
        }

    suspend fun getDepartmentSchedule(id: Int) =
        withContext(Dispatchers.IO) {
            HospitalNetwork.getDepartmentSchedule(id)
        }

    suspend fun getDoctorSchedule(id: Int) =
        withContext(Dispatchers.IO) {
            HospitalNetwork.getDoctorSchedule(id)
        }

    suspend fun getVerificationCode(telephone: String) =
        withContext(Dispatchers.IO) {
            HospitalNetwork.getVerificationCode(telephone)
        }

    suspend fun checkVerificationCode(telephone: String, code: String) =
        withContext(Dispatchers.IO) {
            HospitalNetwork.checkVerificationCode(telephone, code)
        }

    suspend fun getRegisterStatus(telephone: String) =
        withContext(Dispatchers.IO) {
            HospitalNetwork.getRegisterStatus(telephone)
        }

    suspend fun updateInfo(telephone: String, id: String, name: String) =
        withContext(Dispatchers.IO) {
            HospitalNetwork.updateInfo(telephone, id, name)
        }

    suspend fun checkIdentifier(id: String, name: String) =
        withContext(Dispatchers.IO) {
            HospitalNetwork.checkIdentifier(id, name)
        }

    suspend fun getIdentifier(telephone: String) =
        withContext(Dispatchers.IO) {
            HospitalNetwork.getIdentifier(telephone)
        }

    suspend fun submitOrder(order: String) =
        withContext(Dispatchers.IO) {
            HospitalNetwork.submitOrder(order)
        }

    suspend fun getFirstTenOrders(id: Int) =
        withContext(Dispatchers.IO) {
            HospitalNetwork.getFirstTenOrders(id)
        }

    suspend fun getRest(id: Int) = withContext(Dispatchers.IO) {
        HospitalNetwork.getRest(id)
    }

    suspend fun getOrderStatus(id: Int) = withContext(Dispatchers.IO) {
        HospitalNetwork.getOrderStatus(id)
    }

    suspend fun cancelOrder(id: String) = withContext(Dispatchers.IO) {
        HospitalNetwork.cancelOrder(id)
    }

    suspend fun getQrCode(id: String) = withContext(Dispatchers.IO) {
        HospitalNetwork.getQrCode(id)
    }

    suspend fun getDoctorInfo(id: Int) = withContext(Dispatchers.IO) {
        HospitalNetwork.getDoctorInfo(id)
    }

    suspend fun collectDoctor(userId: Int, doctorId: Int) = withContext(Dispatchers.IO) {
        HospitalNetwork.collectDoctor(userId, doctorId)
    }

    suspend fun unCollectDoctor(userId: Int, doctorId: Int) = withContext(Dispatchers.IO) {
        HospitalNetwork.unCollectDoctor(userId, doctorId)
    }

    suspend fun checkIsCollected(userId: Int, doctorId: Int) = withContext(Dispatchers.IO) {
        HospitalNetwork.checkIsCollected(userId, doctorId)
    }

    suspend fun getDoctorCollection(id: Int) = withContext(Dispatchers.IO) {
        HospitalNetwork.getDoctorCollection(id)
    }

    suspend fun sendCode(telephone: String, code: Int) = withContext(Dispatchers.IO) {
        HospitalNetwork.sendCode(telephone, code)
    }

    suspend fun changeTelephone(id: Int, telephone: String) = withContext(Dispatchers.IO) {
        HospitalNetwork.changeTelephone(id, telephone)
    }

    suspend fun getOrderCountStatus(
        userId: Int,
        scheduleId: Int,
        isMorning: Boolean,
        subDepartmentId: Int
    ) = withContext(Dispatchers.IO) {
        HospitalNetwork.getOrderCountStatus(userId, scheduleId, isMorning, subDepartmentId)
    }

    fun getCancelCount() = OrderDao.getCancelCount()

    fun updateCancelCount() = OrderDao.updateCancelCount()

    // LoginDao
    fun startWaiting(telephone: String): Int = LoginDao.startWaiting(telephone)
    fun isWaiting(): Boolean = LoginDao.isWaiting()
    fun getEndTime(): Long = LoginDao.getEndTime()
    fun increaseRetry() = LoginDao.increaseRetry()
    fun resetRetry() = LoginDao.resetRetry()
    fun storeTimer() = LoginDao.storeTimer()
    fun restoreTimer() = LoginDao.restoreTimer()
    fun getTelephone() = LoginDao.getTelephone()


    // IdentifierDao
    fun hasIdentifier() = IdentifierDao.hasIdentifier()
    fun setIdentifier(identifier: Identifier) = IdentifierDao.setIdentifier(identifier)
    fun getIdentifier() = IdentifierDao.getIdentifier()
    fun deleteIdentifier() = IdentifierDao.deleteIdentifier()
}