package per.baluth.hospital.ui.schedule

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.google.android.material.tabs.TabLayoutMediator
import per.baluth.hospital.databinding.FragmentScheduleBinding
import per.baluth.hospital.widthTo
import java.text.SimpleDateFormat
import java.util.*

class ScheduleFragment : Fragment() {
    private var _binding: FragmentScheduleBinding? = null
    private val binding: FragmentScheduleBinding get() = _binding!!
    private lateinit var adapter: PageAdapter
    private val viewModel by lazy { ViewModelProvider(this)[ScheduleViewModel::class.java] }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentScheduleBinding.inflate(inflater, container, false)
        return binding.root
    }

    @SuppressLint("NotifyDataSetChanged")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val viewPager = binding.pager
        val tabLayout = binding.tabLayout

        val id = requireActivity().intent.getIntExtra("id", 1)
        adapter = PageAdapter(this, viewModel.scheduleList)
        viewPager.adapter = adapter

        TabLayoutMediator(tabLayout, viewPager) { tab, position ->
            val calendar = Calendar.getInstance()
            calendar.add(Calendar.DAY_OF_WEEK, position)
            val week = when (position) {
                0 -> "今天"
                1 -> "明天"
                2 -> "后天"
                else -> SimpleDateFormat("EE", Locale.CHINA).format(calendar.time)
            }
            val month = calendar.get(Calendar.MONTH) + 1
            val day = calendar.get(Calendar.DAY_OF_MONTH)
            tab.text = "${week}\n${month.widthTo(2)}-${day.widthTo(2)}"
        }.attach()

        viewModel.refresh(id)
        viewModel.scheduleLiveData.observe(viewLifecycleOwner) {
            viewModel.scheduleList.clear()
            viewModel.scheduleList.addAll(viewModel.scheduleLiveData.value!!)
            adapter.notifyDataSetChanged()
        }
    }

}