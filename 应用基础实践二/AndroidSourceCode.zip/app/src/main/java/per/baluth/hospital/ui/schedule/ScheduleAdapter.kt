package per.baluth.hospital.ui.schedule

import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.google.gson.Gson
import kotlinx.coroutines.*
import per.baluth.hospital.clickFeedback
import per.baluth.hospital.databinding.FragmentSchedulePageItemBinding
import per.baluth.hospital.logic.Repository
import per.baluth.hospital.logic.model.ScheduleInfo
import per.baluth.hospital.logic.model.OrderInfo
import per.baluth.hospital.ui.doctor.DoctorActivity
import per.baluth.hospital.ui.order_preview.OrderPreviewActivity

class ScheduleAdapter(
    private val fragment: ScheduleFragment,
    private val scheduleList: Array<ScheduleInfo>,
    private val page: Int
) : RecyclerView.Adapter<ScheduleAdapter.BindViewHolder>() {
    inner class BindViewHolder(private var itemBinding: FragmentSchedulePageItemBinding) :
        RecyclerView.ViewHolder(itemBinding.root) {

        private var job: Job? = null

        fun bind(schedule: ScheduleInfo) {
            itemBinding.name.text = schedule.doctor_name
            itemBinding.title.text = schedule.title_name
            itemBinding.department.text = schedule.sub_department_name
            itemBinding.price.text = "${schedule.price}￥"
            itemBinding.restMorning.text = "上午余 ${schedule.morning}"
            itemBinding.restAfternoon.text = "下午余 ${schedule.afternoon}"

            itemBinding.card.setOnClickListener {
                clickFeedback(it)
                val intent = Intent(fragment.requireContext(), DoctorActivity::class.java)
                intent.putExtra("DOCTOR_ID", schedule.doctor_id)
                fragment.startActivity(intent)
            }

            itemBinding.bookMorning.isEnabled = Repository.getCancelCount() < 3
            itemBinding.bookAfternoon.isEnabled = Repository.getCancelCount() < 3

            itemBinding.bookMorning.setOnClickListener {
                clickFeedback(it)
                val orderInfo = OrderInfo(
                    schedule.sub_department_id,
                    schedule.sub_department_name,
                    schedule.doctor_id,
                    schedule.doctor_name,
                    schedule.schedule_id,
                    page,
                    true,
                    schedule.price,
                    0
                )

                val json = Gson().toJson(orderInfo)
                val intent = Intent(fragment.requireContext(), OrderPreviewActivity::class.java)
                intent.putExtra("ORDER_INFO", json)
                fragment.startActivity(intent)
            }

            itemBinding.bookAfternoon.setOnClickListener {
                clickFeedback(it)
                val orderInfo = OrderInfo(
                    schedule.sub_department_id,
                    schedule.sub_department_name,
                    schedule.doctor_id,
                    schedule.doctor_name,
                    schedule.schedule_id,
                    page,
                    false,
                    schedule.price,
                    0
                )

                val json = Gson().toJson(orderInfo)
                val intent = Intent(fragment.requireContext(), OrderPreviewActivity::class.java)
                intent.putExtra("ORDER_INFO", json)
                fragment.startActivity(intent)
            }
        }

        fun startRefreshService(id: Int) {
            job = Job()
            CoroutineScope(job!!).launch {
                repeat(Int.MAX_VALUE) {
                    val rest = Repository.getRest(id)
                    withContext(Dispatchers.Main) {
                        itemBinding.restMorning.text = "上午余 ${rest.morning}"
                        itemBinding.restAfternoon.text = "下午余 ${rest.afternoon}"
                    }
                }
            }
        }

        fun stopRefreshService() {
            job?.cancel()
            job = null
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BindViewHolder {
        val itemBinding = FragmentSchedulePageItemBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return BindViewHolder(itemBinding)
    }

    override fun onBindViewHolder(holder: BindViewHolder, position: Int) {
        val schedule = scheduleList[position]
        holder.bind(schedule)
        holder.startRefreshService(schedule.schedule_id)
    }

    override fun onViewDetachedFromWindow(holder: BindViewHolder) {
        super.onViewDetachedFromWindow(holder)
        holder.stopRefreshService()
    }

    override fun getItemCount() = scheduleList.size
}