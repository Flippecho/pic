package per.baluth.hospital.ui.doctor

import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.google.gson.Gson
import per.baluth.hospital.clickFeedback
import per.baluth.hospital.databinding.FragmentDoctorScheduleItemBinding
import per.baluth.hospital.logic.Repository
import per.baluth.hospital.logic.model.ScheduleInfoBrief
import per.baluth.hospital.logic.model.DoctorInfo
import per.baluth.hospital.logic.model.OrderInfo
import per.baluth.hospital.ui.order_preview.OrderPreviewActivity
import per.baluth.hospital.widthTo
import java.text.SimpleDateFormat
import java.util.*

class BriefScheduleAdapter(
    private val fragment: DoctorFragment,
    private val info: DoctorInfo,
    private val scheduleList: List<ScheduleInfoBrief>
) : RecyclerView.Adapter<BriefScheduleAdapter.BindViewHolder>() {

    inner class BindViewHolder(private var itemBinding: FragmentDoctorScheduleItemBinding) :
        RecyclerView.ViewHolder(itemBinding.root) {
        fun bind(schedule: ScheduleInfoBrief, info: DoctorInfo) {

            val position = schedule.date - 1
            val calendar = Calendar.getInstance()
            calendar.add(Calendar.DAY_OF_WEEK, position)
            val week = when (position) {
                0 -> "今天"
                1 -> "明天"
                2 -> "后天"
                else -> SimpleDateFormat("EE", Locale.CHINA).format(calendar.time)
            }
            val month = calendar.get(Calendar.MONTH) + 1
            val day = calendar.get(Calendar.DAY_OF_MONTH)

            itemBinding.date.text = "$week  |  ${month.widthTo(2)} - ${day.widthTo(2)}"
            itemBinding.price.text = "${info.price}￥"
            itemBinding.restMorning.text = "上午余 ${schedule.morning}"
            itemBinding.restAfternoon.text = "下午余 ${schedule.afternoon}"

            itemBinding.bookMorning.isEnabled = Repository.getCancelCount() < 3
            itemBinding.bookAfternoon.isEnabled = Repository.getCancelCount() < 3

            itemBinding.bookMorning.setOnClickListener {
                clickFeedback(it)
                val orderInfo = OrderInfo(
                    info.sub_department_id,
                    info.sub_department_name,
                    info.doctor_id,
                    info.doctor_name,
                    schedule.id,
                    schedule.date - 1,
                    true,
                    info.price,
                    0
                )

                val intent = Intent(fragment.requireContext(), OrderPreviewActivity::class.java)
                intent.putExtra("ORDER_INFO", Gson().toJson(orderInfo))
                fragment.startActivity(intent)
            }

            itemBinding.bookAfternoon.setOnClickListener {
                clickFeedback(it)
                val orderInfo = OrderInfo(
                    info.sub_department_id,
                    info.sub_department_name,
                    info.doctor_id,
                    info.doctor_name,
                    schedule.id,
                    schedule.date - 1,
                    false,
                    info.price,
                    0
                )

                val intent = Intent(fragment.requireContext(), OrderPreviewActivity::class.java)
                intent.putExtra("ORDER_INFO", Gson().toJson(orderInfo))
                fragment.startActivity(intent)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BindViewHolder {
        val itemBinding = FragmentDoctorScheduleItemBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return BindViewHolder(itemBinding)
    }

    override fun onBindViewHolder(holder: BindViewHolder, position: Int) {
        val schedule = scheduleList[position]
        holder.bind(schedule, info)
    }

    override fun getItemCount() = scheduleList.size
}