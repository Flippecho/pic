package per.baluth.hospital.ui.change_telephone

import android.content.Context
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import androidx.core.content.ContextCompat
import androidx.core.widget.doAfterTextChanged
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import kotlinx.coroutines.*
import per.baluth.hospital.R
import per.baluth.hospital.clickFeedback
import per.baluth.hospital.databinding.FragmentChangeTelephoneBinding
import per.baluth.hospital.isValidId
import per.baluth.hospital.logic.model.Identifier
import per.baluth.hospital.toast
import java.time.Duration
import java.time.LocalTime
import java.util.Date

class ChangeTelephoneFragment : Fragment() {
    private var job: Job? = null
    private var _binding: FragmentChangeTelephoneBinding? = null
    private val binding: FragmentChangeTelephoneBinding get() = _binding!!
    private val viewModel by lazy { ViewModelProvider(this)[ChangeTelephoneViewModel::class.java] }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentChangeTelephoneBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val identifier = viewModel.getIdentifier()

        val imm =
            requireContext().getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager

        hideProgress()

        binding.telephoneHint.setText(identifier.telephone.substring(0, 7))

        binding.oldTelephoneEditText.doAfterTextChanged {
            val telephone = binding.oldTelephoneEditText.text.toString()
            if (telephone.length == 4) {
                binding.oldTelephoneEditText.imeOptions = EditorInfo.IME_ACTION_NEXT
                imm.restartInput(binding.oldTelephoneEditText)
                binding.oldCodeButton.isEnabled = true

                binding.oldTelephoneFormatState.text = "请补全尾号，若尾号正确则会发送验证码"
                val color =
                    ContextCompat.getColor(requireContext(), R.color.telephone_format_default)
                binding.oldTelephoneFormatState.setTextColor(color)
            } else {
                binding.oldTelephoneEditText.imeOptions = EditorInfo.IME_ACTION_DONE
                imm.restartInput(binding.oldTelephoneEditText)
                binding.oldCodeButton.isEnabled = false
            }
        }

        binding.oldTelephoneEditText.setOnFocusChangeListener { _, hasFocus ->
            val telephone = binding.oldTelephoneEditText.text.toString()

            if (!hasFocus && telephone.length != 4) {
                binding.oldTelephoneFormatState.text = "格式错误，尾号应为 4 位"
                val colorRed = ContextCompat.getColor(requireContext(), R.color.red)
                binding.oldTelephoneFormatState.setTextColor(colorRed)
            }
        }

        binding.oldCodeButton.setOnClickListener {
            clickFeedback(it)
            val telephone = binding.oldTelephoneEditText.text.toString()
            binding.oldTelephoneEditText.isEnabled = false
            binding.oldCodeButton.isEnabled = false

            if (identifier.telephone.substring(7, 11) == telephone
            ) {
                viewModel.getVerificationCode(identifier.telephone)
            }

            var countDown = viewModel.startWaiting(identifier.telephone)

            viewModel.increaseRetry()
            binding.oldVerificationEditText.requestFocus()

            job = Job()
            CoroutineScope(job!!).launch {
                repeat(countDown) {
                    withContext(Dispatchers.Main) {
                        binding.oldCodeButton.text = "等待 $countDown 秒"
                        countDown--
                    }
                    delay(1000)
                }

                withContext(Dispatchers.Main) {
                    binding.oldTelephoneEditText.isEnabled = true
                    binding.oldCodeButton.text = getString(R.string.get_verification)
                    binding.oldCodeButton.isEnabled = binding.oldTelephoneEditText.text.length == 11
                }
            }
        }

        binding.oldVerificationEditText.doAfterTextChanged {
            val code = binding.oldVerificationEditText.text.toString()

            if (code.length == 4) {
                binding.title.text = "正在验证..."
                showProgress()

                CoroutineScope(Job()).launch {
                    val result = viewModel.checkVerificationCode(identifier.telephone, code)
                    withContext(Dispatchers.Main) {
                        delay(1000)
                        hideProgress()
                        binding.title.text = "换绑手机号"

                        if (result) {
                            viewModel.resetRetry()
                            showAuthLayout()
                            binding.title.text = "验证身份信息"
                            binding.cardId.requestFocus()
                        } else {
                            "验证码错误".toast()
                            binding.oldVerificationEditText.setText("")
                            binding.oldVerificationEditText.requestFocus()
                        }
                    }
                }
            }
        }

        binding.cardId.doAfterTextChanged {
            val content = binding.cardId.text.toString()
            if (content.isValidId()) {
                val color =
                    ContextCompat.getColor(requireContext(), R.color.telephone_format_default)
                binding.authenticationState.setTextColor(color)
                binding.authenticationState.text = getString(R.string.hint_authentication_default)
                binding.cardId.imeOptions = EditorInfo.IME_ACTION_NEXT
                imm.restartInput(binding.cardId)
                if (binding.realName.text.length >= 2) {
                    binding.authenticationButton.isEnabled = true
                }
            } else {
                binding.cardId.imeOptions = EditorInfo.IME_ACTION_DONE
            }
        }

        binding.cardId.setOnFocusChangeListener { _, hasFocus ->
            val content = binding.cardId.text.toString().replace("\\s".toRegex(), "")
            if (!hasFocus && !content.isValidId()) {
                val colorRed = ContextCompat.getColor(requireContext(), R.color.red)
                binding.authenticationState.setTextColor(colorRed)
                binding.authenticationState.text = getString(R.string.hint_authentication_error)
            }
        }



        binding.realName.doAfterTextChanged {
            val content = binding.realName.text.toString().replace("\\s".toRegex(), "")
            if (content.length >= 2 && binding.cardId.text.toString().isValidId()) {
                binding.authenticationButton.isEnabled = true
                binding.realName.imeOptions = EditorInfo.IME_ACTION_SEND
            } else {
                binding.authenticationButton.isEnabled = false
                binding.realName.imeOptions = EditorInfo.IME_ACTION_DONE
            }
            imm.restartInput(binding.realName)
        }

        binding.authenticationButton.setOnClickListener {
            clickFeedback(it)

            val name = binding.realName.text.toString()
            val id = binding.cardId.text.toString()

            binding.cardId.isEnabled = false
            binding.realName.isEnabled = false

            val passed = id == identifier.id_card && name == identifier.username
            if (passed) {
                showNewLayout()
                binding.title.text = "换绑手机号"
            } else {
                "身份信息验证不通过".toast()
                binding.cardId.isEnabled = true
                binding.realName.isEnabled = true
                hideProgress()
            }
        }

        binding.newTelephoneEditText.doAfterTextChanged {
            val telephone = binding.newTelephoneEditText.text.toString()
            if (telephone.length == 11) {
                binding.newTelephoneEditText.imeOptions = EditorInfo.IME_ACTION_NEXT
                imm.restartInput(binding.newTelephoneEditText)
                binding.newCodeButton.isEnabled = true

                binding.newTelephoneFormatState.text = "请输入新的手机号码"
                val color =
                    ContextCompat.getColor(requireContext(), R.color.telephone_format_default)
                binding.newTelephoneFormatState.setTextColor(color)
            } else {
                binding.newTelephoneEditText.imeOptions = EditorInfo.IME_ACTION_DONE
                imm.restartInput(binding.newTelephoneEditText)
                binding.newCodeButton.isEnabled = false
            }
        }

        binding.newTelephoneEditText.setOnFocusChangeListener { _, hasFocus ->
            val telephone = binding.newTelephoneEditText.text.toString()

            if (!hasFocus && telephone.length != 11) {
                binding.newTelephoneFormatState.text = getString(R.string.login_hint_error)
                val colorRed = ContextCompat.getColor(requireContext(), R.color.red)
                binding.newTelephoneFormatState.setTextColor(colorRed)
            }
        }

        binding.newCodeButton.setOnClickListener {
            clickFeedback(it)

            val telephone = binding.newTelephoneEditText.text.toString()
            binding.newTelephoneEditText.isEnabled = false
            binding.newCodeButton.isEnabled = false

            val code = (Math.random() * 8999 + 1000).toInt()
            Log.d("Baluth", "code: $code")
            viewModel.code = code
            viewModel.sendCode(telephone, code)
        }

        viewModel.sendCodeLiveData.observe(viewLifecycleOwner) {
            if (it) {
                val telephone = binding.newTelephoneEditText.text.toString()
                var countDown = viewModel.startWaiting(telephone)

                viewModel.increaseRetry()
                binding.oldVerificationEditText.requestFocus()

                job = Job()
                CoroutineScope(job!!).launch {
                    repeat(countDown) {
                        withContext(Dispatchers.Main) {
                            binding.oldCodeButton.text = "等待 $countDown 秒"
                            countDown--
                        }
                        delay(1000)
                    }

                    withContext(Dispatchers.Main) {
                        binding.oldTelephoneEditText.isEnabled = true
                        binding.oldCodeButton.text = getString(R.string.get_verification)
                        binding.oldCodeButton.isEnabled =
                            binding.oldTelephoneEditText.text.length == 11
                    }
                }
            } else {
                "该手机号已绑定其它账号".toast()
                binding.newTelephoneEditText.isEnabled = true
                binding.newCodeButton.isEnabled = true
            }
        }


        binding.newVerificationEditText.doAfterTextChanged {
            val telephone = binding.newTelephoneEditText.text.toString()
            val code = binding.newVerificationEditText.text.toString()

            if (code.length == 4) {
                if (code.toInt() == viewModel.code) {
                    binding.title.text = "正在修改手机号"
                    showProgress()
                    viewModel.changeTelephone(telephone)
                } else {
                    "验证码错误".toast()
                    binding.newVerificationEditText.setText("")
                    binding.newVerificationEditText.requestFocus()
                }
            }
        }

        viewModel.changeTelephoneLiveData.observe(viewLifecycleOwner) {
            if (it) {
                "换绑手机号成功 : ）".toast()
                val telephone = binding.newTelephoneEditText.text.toString()
                viewModel.setIdentifier(
                    Identifier(
                        identifier.id,
                        identifier.username,
                        telephone,
                        identifier.id_card
                    )
                )
                requireActivity().finish()
            } else {
                "换绑手机号失败 : （".toast()
            }
        }

    }

    override fun onResume() {
        super.onResume()

        viewModel.restoreTimer()

        if (viewModel.isWaiting()) {
            binding.oldTelephoneEditText.setText(viewModel.getTelephone())
            binding.oldTelephoneEditText.isEnabled = false
            binding.oldCodeButton.isEnabled = false
            var countDown = Date().time - viewModel.getEndTime()

            job = Job()
            CoroutineScope(job!!).launch {
                repeat(countDown.toInt()) {
                    withContext(Dispatchers.Main) {
                        binding.oldCodeButton.text = "等待 $countDown 秒"
                        countDown--
                    }
                    delay(1000)
                }

                withContext(Dispatchers.Main) {
                    binding.oldTelephoneEditText.isEnabled = true
                    binding.oldCodeButton.text = getString(R.string.get_verification)
                    binding.oldCodeButton.isEnabled = binding.oldTelephoneEditText.text.length == 11
                }
            }
        }
    }

    override fun onPause() {
        super.onPause()
        viewModel.storeTimer()
        job?.cancel()
        job = null
    }

    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }

    private fun showProgress() {
        CoroutineScope(Job()).launch {
            withContext(Dispatchers.Main) {
                binding.progress.visibility = View.VISIBLE
                binding.divider.visibility = View.GONE
            }
        }
    }

    private fun hideProgress() {
        CoroutineScope(Job()).launch {
            withContext(Dispatchers.Main) {
                binding.progress.visibility = View.GONE
                binding.divider.visibility = View.VISIBLE
            }
        }
    }

    private fun showAuthLayout() {
        CoroutineScope(Job()).launch {
            withContext(Dispatchers.Main) {
                binding.oldLayout.visibility = View.GONE
                binding.authenticationLayout.visibility = View.VISIBLE
                binding.newLayout.visibility = View.GONE
            }
        }
    }

    private fun showNewLayout() {
        CoroutineScope(Job()).launch {
            withContext(Dispatchers.Main) {
                // show progress
                binding.progress.visibility = View.VISIBLE
                binding.divider.visibility = View.GONE

                delay(1000)

                // hide progress
                binding.progress.visibility = View.GONE
                binding.divider.visibility = View.VISIBLE

                "手机验证通过".toast()

                binding.oldLayout.visibility = View.GONE
                binding.authenticationLayout.visibility = View.GONE
                binding.newLayout.visibility = View.VISIBLE

                binding.newTelephoneEditText.requestFocus()
            }
        }
    }
}