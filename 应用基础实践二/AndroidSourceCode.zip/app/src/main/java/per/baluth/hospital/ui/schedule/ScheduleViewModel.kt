package per.baluth.hospital.ui.schedule

import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import per.baluth.hospital.logic.Repository
import per.baluth.hospital.logic.model.ScheduleInfo

class ScheduleViewModel : ViewModel() {
    internal val scheduleList = ArrayList<Array<ScheduleInfo>>()
    internal val scheduleLiveData = MutableLiveData<List<Array<ScheduleInfo>>>()

    fun refresh(id: Int) {
        CoroutineScope(Job()).launch {
            Log.d("Baluth", id.toString())
            scheduleLiveData.postValue(Repository.getDepartmentSchedule(id))
        }
    }
}