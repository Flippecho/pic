package per.baluth.hospital.logic.network

import per.baluth.hospital.logic.model.*
import per.baluth.hospital.logic.model.OrderInfoDetailed
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Query

interface HospitalService {
    @GET("get_department")
    fun getDepartment(): Call<List<Department>>

    @GET("get_schedule_department")
    fun getDepartmentSchedule(@Query("department_id") department_id: Int): Call<ArrayList<Array<ScheduleInfo>>>

    @GET("get_schedule_doctor?")
    fun getDoctorSchedule(@Query("doctor_id") doctor_id: Int): Call<List<ScheduleInfoBrief>>

    @GET("get_rest")
    fun getRest(@Query("schedule_id") schedule_id: Int): Call<Rest>

    @GET("get_verification_code?")
    fun getVerificationCode(@Query("telephone") telephone: String): Call<Boolean>

    @GET("check_verification_code?")
    fun checkVerificationCode(
        @Query("telephone") telephone: String,
        @Query("code") code: String
    ): Call<Boolean>

    @GET("get_register_status?")
    fun getRegisterStatus(@Query("telephone") telephone: String): Call<Int>

    @GET("check_identifier?")
    fun checkIdentifier(@Query("id") id: String, @Query("name") name: String): Call<Boolean>

    @GET("update_info?")
    fun updateInfo(
        @Query("telephone") telephone: String,
        @Query("id") id: String,
        @Query("name") name: String
    ): Call<Int>

    @GET("get_identifier?")
    fun getIdentifier(@Query("telephone") telephone: String): Call<Identifier>

    @GET("submit_order?")
    fun submitOrder(@Query("order") order: String): Call<PayResponse>

    @GET("get_first_ten_orders?")
    fun getFirstTenOrders(@Query("patient_id") id: Int): Call<List<OrderInfoDetailed>>

    @GET("get_order_status?")
    fun getOrderStatus(@Query("order_id") id: Int): Call<Int>

    @GET("cancel_order?")
    fun cancelOrder(@Query("order_id") id: String): Call<Boolean>

    @GET("get_cancel_count?")
    fun getCancelCount(@Query("user_id") id: Int): Call<Int>

    @GET("get_qr_code?")
    fun getQrCode(@Query("order_id") id: String): Call<QrCode>

    @GET("get_doctor_info?")
    fun getDoctorInfo(@Query("doctor_id") id: Int): Call<List<DoctorInfo>>

    @GET("collect_doctor?")
    fun collectDoctor(
        @Query("user_id") userId: Int,
        @Query("doctor_id") doctorId: Int
    ): Call<Boolean>

    @GET("un_collect_doctor?")
    fun unCollectDoctor(
        @Query("user_id") userId: Int,
        @Query("doctor_id") doctorId: Int
    ): Call<Boolean>

    @GET("check_is_collected?")
    fun checkIsCollected(
        @Query("user_id") userId: Int,
        @Query("doctor_id") doctorId: Int
    ): Call<Boolean>

    @GET("get_doctor_collection?")
    fun getDoctorCollection(@Query("user_id") id: Int): Call<List<DoctorInfoBrief>>

    @GET("send_code?")
    fun sendCode(@Query("telephone") telephone: String, @Query("code") code: Int): Call<Boolean>

    @GET("change_telephone?")
    fun changeTelephone(
        @Query("user_id") id: Int,
        @Query("telephone") telephone: String
    ): Call<Boolean>

    @GET("get_order_count_status?")
    fun getOrderCountStatus(
        @Query("user_id") userId: Int,
        @Query("schedule_id") schedule_id: Int,
        @Query("is_morning") isMorning: Boolean,
        @Query("sub_department_id") subDepartment_id: Int
    ): Call<Int>
}