package per.baluth.hospital.ui.main.department

import android.app.AlertDialog
import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import per.baluth.hospital.clickFeedback
import per.baluth.hospital.databinding.FragmentDepartmentItemBinding
import per.baluth.hospital.logic.model.Department
import per.baluth.hospital.ui.schedule.ScheduleActivity

class DepartmentAdapter(
    private val fragment: DepartmentFragment,
    private val departmentList: List<Department>
) : RecyclerView.Adapter<DepartmentAdapter.BindViewHolder>() {
    inner class BindViewHolder(private var itemBinding: FragmentDepartmentItemBinding) :
        RecyclerView.ViewHolder(itemBinding.root) {
        fun bind(department: Department) {
            itemBinding.name.text = department.department_name

            itemBinding.about.setOnClickListener {
                clickFeedback(it)
                AlertDialog.Builder(fragment.requireContext()).apply {
                    setTitle("${department.department_name}说明")
                    setMessage(department.description)
                    setCancelable(true)
                    show()
                }
            }

            itemBinding.card.setOnClickListener {
                clickFeedback(it)
                val intent = Intent(fragment.requireContext(), ScheduleActivity::class.java)
                intent.putExtra("id", department.department_id)
                fragment.startActivity(intent)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BindViewHolder {
        val itemBinding = FragmentDepartmentItemBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return BindViewHolder(itemBinding)
    }

    override fun onBindViewHolder(holder: BindViewHolder, position: Int) {
        val department = departmentList[position]
        holder.bind(department)
    }

    override fun getItemCount() = departmentList.size
}