package per.baluth.hospital.logic.model

data class DoctorInfoBrief(
    val doctor_id: Int,
    val doctor_name: String,
    val title_name: String,
    val price: Int,
    val sub_department_name: String,
)
