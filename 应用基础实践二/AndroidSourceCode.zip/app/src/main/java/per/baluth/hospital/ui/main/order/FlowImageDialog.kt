package per.baluth.hospital.ui.main.order

import android.app.Activity
import android.os.Bundle
import android.view.ViewGroup.MarginLayoutParams
import android.widget.FrameLayout
import android.widget.RelativeLayout
import per.baluth.hospital.R
import per.baluth.hospital.databinding.CustomDialogFlowBinding

class FlowImageDialog: Activity() {
    private lateinit var binding: CustomDialogFlowBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = CustomDialogFlowBinding.inflate(layoutInflater)
        setContentView(binding.root)
        this.setFinishOnTouchOutside(false)
    }

    override fun onResume() {
        super.onResume()
        val displayMetrics = this.resources.displayMetrics
        val layoutParams = MarginLayoutParams(binding.image.layoutParams)
        layoutParams.width = (displayMetrics.widthPixels * 0.95).toInt()
        layoutParams.width = displayMetrics.widthPixels - (11 * displayMetrics.density).toInt() * 2
        val frameLayoutParams = FrameLayout.LayoutParams(layoutParams)
        binding.image.layoutParams = frameLayoutParams
        binding.image.setImageResource(R.drawable.diagram_flow)
    }
}