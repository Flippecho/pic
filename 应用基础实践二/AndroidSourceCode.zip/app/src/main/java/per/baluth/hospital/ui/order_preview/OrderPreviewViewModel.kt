package per.baluth.hospital.ui.order_preview

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import per.baluth.hospital.logic.Repository

class OrderPreviewViewModel : ViewModel() {

    internal var firstResume = true
    internal var paymentId = 0
    internal var orderId = 0

    fun hasIdentifier() = Repository.hasIdentifier()

    fun getIdentifier() = Repository.getIdentifier()

    suspend fun submitOrder(order: String) = Repository.submitOrder(order)

    suspend fun getRest(id: Int) = Repository.getRest(id)

    suspend fun getOrderStatus(id: Int) = Repository.getOrderStatus(id)

    internal val orderCountStatusLiveData = MutableLiveData<Int>()

    fun getOrderCountStatus(scheduleId: Int, isMorning: Boolean, subDepartmentId: Int) {
        CoroutineScope(Job()).launch {
            val userId = Repository.getIdentifier().id
            orderCountStatusLiveData.postValue(
                Repository.getOrderCountStatus(
                    userId,
                    scheduleId,
                    isMorning,
                    subDepartmentId
                )
            )
        }
    }
}