package per.baluth.hospital.ui.main

import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.fragment.app.Fragment
import androidx.viewpager2.adapter.FragmentStateAdapter
import per.baluth.hospital.R
import per.baluth.hospital.clickFeedback
import per.baluth.hospital.databinding.ActivityMainBinding
import per.baluth.hospital.ui.main.department.DepartmentFragment
import per.baluth.hospital.ui.main.order.OrderFragment
import per.baluth.hospital.ui.main.personal.PersonalFragment

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    inner class PagerAdapter(
        fragmentActivity: MainActivity,
        private val fragments: ArrayList<Fragment>
    ) :
        FragmentStateAdapter(fragmentActivity) {

        override fun createFragment(position: Int) = fragments[position]

        override fun getItemCount(): Int = fragments.size
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val fragments = ArrayList<Fragment>()

        fragments.add(DepartmentFragment())
        fragments.add(OrderFragment())
        fragments.add(PersonalFragment())

        binding.pager.adapter = PagerAdapter(this, fragments)

        binding.pager.isUserInputEnabled = false

        binding.bottomNavigation.setOnItemSelectedListener {
            clickFeedback(binding.bottomNavigation)
            when (it.itemId) {
                R.id.page_registration -> {
                    binding.pager.currentItem = 0
                    true
                }

                R.id.page_order -> {
                    binding.pager.currentItem = 1
                    true
                }

                R.id.page_personal -> {
                    binding.pager.currentItem = 2
                    true
                }
                else -> super.onOptionsItemSelected(it)
            }
        }
    }
}