package per.baluth.hospital.logic.dao

import android.content.Context
import android.content.SharedPreferences
import androidx.core.content.edit
import per.baluth.hospital.getSharedContext
import java.util.Date

object LoginDao {

    private var endTime = 0L
    private var retryTime = 0
    private var telephone = ""
    private const val SP_NAME = "TIMER"
    private const val KEY_END_TIME = "END_TIME"
    private const val KEY_RETRY_TIME = "RETRY_TIME"
    private const val KEY_TELEPHONE = "TELEPHONE"

    private fun sharedPreferences(): SharedPreferences =
        getSharedContext().getSharedPreferences(SP_NAME, Context.MODE_PRIVATE)

    fun startWaiting(newTelephone: String): Int {

        val waiting = when (retryTime) {
            0 -> 16
            1 -> 32
            2 -> 64
            3 -> 128
            else -> 256
        }

        endTime = Date().time + waiting * 1000
        telephone = newTelephone
        return waiting
    }

    fun getTelephone() = telephone

    fun isWaiting(): Boolean {
        return endTime > Date().time
    }

    fun getEndTime() = endTime

    fun increaseRetry() {
        retryTime++
    }

    fun resetRetry() {
        retryTime = 0
        endTime = Date().time
    }

    fun storeTimer() {
        sharedPreferences().edit {
            putLong(KEY_END_TIME, endTime)
            putInt(KEY_RETRY_TIME, retryTime)
            putString(KEY_TELEPHONE, telephone)
        }
    }

    fun restoreTimer() {
        retryTime = sharedPreferences().getInt(KEY_RETRY_TIME, 0)
        telephone = sharedPreferences().getString(KEY_TELEPHONE, "").toString()
//        endTime = sharedPreferences().getLong(KEY_END_TIME, 0)
    }
}