package per.baluth.hospital.ui.main.department

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import per.baluth.hospital.logic.Repository
import per.baluth.hospital.logic.model.Department

class DepartmentViewModel: ViewModel() {
    internal val departmentList = ArrayList<Department>()
    internal val departmentLiveData = MutableLiveData<List<Department>>()

    fun refresh() {
        CoroutineScope(Job()).launch {
            departmentLiveData.postValue(Repository.getDepartment())
        }
    }

    fun updateCancelCount() = Repository.updateCancelCount()
}