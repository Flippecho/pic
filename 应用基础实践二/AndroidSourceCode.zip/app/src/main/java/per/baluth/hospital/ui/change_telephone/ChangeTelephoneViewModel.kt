package per.baluth.hospital.ui.change_telephone

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import per.baluth.hospital.logic.Repository
import per.baluth.hospital.logic.model.Identifier
import java.time.LocalTime

class ChangeTelephoneViewModel : ViewModel() {
    fun startWaiting(telephone: String): Int = Repository.startWaiting(telephone)

    fun isWaiting(): Boolean = Repository.isWaiting()

    fun getEndTime(): Long = Repository.getEndTime()

    fun getTelephone() = Repository.getTelephone()

    fun increaseRetry() = Repository.increaseRetry()

    fun resetRetry() = Repository.resetRetry()

    fun storeTimer() = Repository.storeTimer()

    fun restoreTimer() = Repository.restoreTimer()

    fun getVerificationCode(telephone: String) {
        CoroutineScope(Job()).launch {
            Repository.getVerificationCode(telephone)
        }
    }

    suspend fun checkVerificationCode(telephone: String, code: String) =
        Repository.checkVerificationCode(telephone, code)

    suspend fun getRegisterStatus(telephone: String) = Repository.getRegisterStatus(telephone)

    suspend fun updateInfo(telephone: String, id: String, name: String) =
        Repository.updateInfo(telephone, id, name)

    suspend fun checkIdentifier(id: String, name: String) = Repository.checkIdentifier(id, name)

    suspend fun getIdentifier(telephone: String) = Repository.getIdentifier(telephone)

    internal var code = 0

    internal val sendCodeLiveData = MutableLiveData<Boolean>()

    fun sendCode(telephone: String, code: Int) {
        CoroutineScope(Job()).launch {
            sendCodeLiveData.postValue(Repository.sendCode(telephone, code))
        }
    }

    internal val changeTelephoneLiveData = MutableLiveData<Boolean>()

    fun changeTelephone(telephone: String) {
        CoroutineScope(Job()).launch {
            delay(1000)
            val id = Repository.getIdentifier().id
            changeTelephoneLiveData.postValue(Repository.changeTelephone(id, telephone))
        }
    }

    fun getIdentifier() = Repository.getIdentifier()

    fun setIdentifier(identifier: Identifier) = Repository.setIdentifier(identifier)
}