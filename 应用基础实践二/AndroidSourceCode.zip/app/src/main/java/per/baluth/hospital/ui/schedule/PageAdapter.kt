package per.baluth.hospital.ui.schedule

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import per.baluth.hospital.databinding.FragmentSchedulePageBinding
import per.baluth.hospital.logic.model.ScheduleInfo

class PageAdapter(
    private val fragment: ScheduleFragment,
    private val scheduleList: List<Array<ScheduleInfo>>
) :
    RecyclerView.Adapter<PageAdapter.BindViewHolder>() {

    private lateinit var adapter: ScheduleAdapter

    inner class BindViewHolder(private var itemBinding: FragmentSchedulePageBinding) :
        RecyclerView.ViewHolder(itemBinding.root) {
        fun bind(dailySchedule: Array<ScheduleInfo>, page: Int) {
            adapter = ScheduleAdapter(fragment, dailySchedule, page)
            itemBinding.scheduleList.adapter = adapter
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BindViewHolder {
        val itemBinding = FragmentSchedulePageBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return BindViewHolder(itemBinding)
    }

    override fun onBindViewHolder(holder: BindViewHolder, position: Int) {
        val dailySchedule = scheduleList[position]
        holder.bind(dailySchedule, position)
    }

    override fun getItemCount(): Int = scheduleList.size
}