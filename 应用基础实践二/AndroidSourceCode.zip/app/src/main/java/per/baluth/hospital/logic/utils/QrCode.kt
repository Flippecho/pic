package per.baluth.hospital.logic.utils

import android.graphics.Bitmap
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.WriterException
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel
import com.journeyapps.barcodescanner.BarcodeEncoder

object QrCode {
    fun createQr(json: String, size: Int): Bitmap? {
        val map = HashMap<EncodeHintType, Any>()
        map[EncodeHintType.CHARACTER_SET] = "utf-8"
        map[EncodeHintType.ERROR_CORRECTION] = ErrorCorrectionLevel.M
        map[EncodeHintType.MARGIN] = 1

        val barcodeEncoder = BarcodeEncoder()
        var bitmap: Bitmap? = null
        try {
            bitmap = barcodeEncoder.encodeBitmap(json, BarcodeFormat.QR_CODE, size, size, map)
        } catch (e: WriterException) {
            e.printStackTrace()
        }
        return bitmap
    }
}