package per.baluth.hospital.logic.model

data class ScheduleInfo(
    val schedule_id: Int,
    val date: Int,
    val price: Int,
    val morning: Int,
    val afternoon: Int,
    val doctor_id: Int,
    val title_name: String,
    val doctor_name: String,
    val praise_amount: Int,
    val working_years: Int,
    val patient_amount: Int,
    val criticize_amount: Int,
    val sub_department_id: Int,
    val sub_department_name: String
)
