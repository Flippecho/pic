package per.baluth.hospital.logic.dao

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import androidx.core.content.edit
import kotlinx.coroutines.*
import per.baluth.hospital.getSharedContext
import per.baluth.hospital.logic.Repository
import per.baluth.hospital.logic.network.HospitalNetwork

object OrderDao {
    private const val SP_NAME = "ORDER"
    private var cancelCount = 0

    private fun sharedPreferences(): SharedPreferences =
        getSharedContext().getSharedPreferences(SP_NAME, Context.MODE_PRIVATE)

    fun getCancelCount() = cancelCount

    fun updateCancelCount() {
        CoroutineScope(Job()).launch {
            withContext(Dispatchers.IO) {
                if (Repository.hasIdentifier()) {
                    val id = Repository.getIdentifier().id
                    cancelCount = HospitalNetwork.getCancelCount(id)
                }
            }
        }
    }
}