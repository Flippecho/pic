package per.baluth.hospital.ui.doctor

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import per.baluth.hospital.logic.Repository
import per.baluth.hospital.logic.model.ScheduleInfoBrief
import per.baluth.hospital.logic.model.DoctorInfo

class DoctorViewModel : ViewModel() {
    internal val scheduleList = ArrayList<ScheduleInfoBrief>()
    internal val scheduleLiveData = MutableLiveData<List<ScheduleInfoBrief>>()

    fun refresh(id: Int) {
        CoroutineScope(Job()).launch {
            scheduleLiveData.postValue(Repository.getDoctorSchedule(id))
        }
    }

    internal val doctorInfoLiveData = MutableLiveData<DoctorInfo>()

    fun refreshDoctorInfo(id: Int) {
        CoroutineScope(Job()).launch {
            doctorInfoLiveData.postValue(Repository.getDoctorInfo(id)[0])
        }
    }

    internal val hasCollectedLiveData = MutableLiveData<Boolean>()

    fun checkIsCollected(doctorId: Int) {
        CoroutineScope(Job()).launch {
            if (Repository.hasIdentifier()) {
                val userId = Repository.getIdentifier().id
                hasCollectedLiveData.postValue(Repository.checkIsCollected(userId, doctorId))
            } else {
                hasCollectedLiveData.postValue(false)
            }
        }
    }

    suspend fun getIsCollected(doctorId: Int): Boolean {
        val userId = Repository.getIdentifier().id
        return Repository.checkIsCollected(userId, doctorId)
    }

    fun collectDoctor(doctorId: Int) {
        CoroutineScope(Job()).launch {
            val userId = Repository.getIdentifier().id
            Repository.collectDoctor(userId, doctorId)
        }
    }

    fun unCollectDoctor(doctorId: Int) {
        CoroutineScope(Job()).launch {
            val userId = Repository.getIdentifier().id
            Repository.unCollectDoctor(userId, doctorId)
        }
    }

    fun hasIdentifier() = Repository.hasIdentifier()
}