package per.baluth.hospital.ui.doctor_collection

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import per.baluth.hospital.logic.Repository
import per.baluth.hospital.logic.model.DoctorInfoBrief

class DoctorCollectionViewModel: ViewModel() {
    internal val doctorList = ArrayList<DoctorInfoBrief>()
    internal val doctorLiveData = MutableLiveData<List<DoctorInfoBrief>>()

    fun getDoctorCollection() {
        CoroutineScope(Job()).launch {
            val userId = Repository.getIdentifier().id
            doctorLiveData.postValue(Repository.getDoctorCollection(userId))
        }
    }
}