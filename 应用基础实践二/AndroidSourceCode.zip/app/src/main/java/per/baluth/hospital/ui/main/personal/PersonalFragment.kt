package per.baluth.hospital.ui.main.personal

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import per.baluth.hospital.R
import per.baluth.hospital.clickFeedback
import per.baluth.hospital.databinding.FragmentPersonalBinding
import per.baluth.hospital.ui.change_telephone.ChangeTelephoneActivity
import per.baluth.hospital.ui.doctor_collection.DoctorCollectionActivity
import per.baluth.hospital.ui.login.LoginActivity
import per.baluth.hospital.widthTo

class PersonalFragment : Fragment() {
    private var _binding: FragmentPersonalBinding? = null
    private val binding: FragmentPersonalBinding get() = _binding!!
    private val viewModel by lazy { ViewModelProvider(this)[PersonalViewModel::class.java] }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentPersonalBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.loginButton.setOnClickListener {
            clickFeedback(it)
            val intent = Intent(requireContext(), LoginActivity::class.java)
            startActivity(intent)
        }

        binding.logoutButton.setOnClickListener {
            clickFeedback(it)
            viewModel.deleteIdentifier()
            binding.name.text = getString(R.string.default_user_name)
            binding.id.text = getString(R.string.default_user_id)
            showLoginButton()
        }

        binding.qrCode.setOnClickListener {
            clickFeedback(it)
            if (viewModel.hasIdentifier()) {
                val intent = Intent(requireContext(), QrCodeDialog::class.java)
                startActivity(intent)
            } else {
                val intent = Intent(requireContext(), LoginActivity::class.java)
                startActivity(intent)
            }
        }

        binding.doctorCollection.setOnClickListener {
            clickFeedback(it)
            if (viewModel.hasIdentifier()) {
                val intent = Intent(requireContext(), DoctorCollectionActivity::class.java)
                startActivity(intent)
            } else {
                val intent = Intent(requireContext(), LoginActivity::class.java)
                startActivity(intent)
            }
        }

        binding.changeTelephone.setOnClickListener {
            clickFeedback(it)
            if (viewModel.hasIdentifier()) {
                val intent = Intent(requireContext(), ChangeTelephoneActivity::class.java)
                startActivity(intent)
            } else {
                val intent = Intent(requireContext(), LoginActivity::class.java)
                startActivity(intent)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (viewModel.hasIdentifier()) {
            val identifier = viewModel.getIdentifier()
            binding.name.text = identifier.username
            binding.id.text = "用户ID:\n${identifier.id.widthTo(8)}"
            showLogoutButton()
        } else {
            binding.name.text = getString(R.string.default_user_name)
            binding.id.text = getString(R.string.default_user_id)
            showLoginButton()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }

    private fun showLoginButton() {
        binding.loginButton.visibility = View.VISIBLE
        binding.logoutButton.visibility = View.GONE
    }

    private fun showLogoutButton() {
        binding.loginButton.visibility = View.GONE
        binding.logoutButton.visibility = View.VISIBLE
    }
}