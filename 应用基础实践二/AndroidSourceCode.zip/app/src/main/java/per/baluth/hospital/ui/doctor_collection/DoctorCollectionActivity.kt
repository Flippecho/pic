package per.baluth.hospital.ui.doctor_collection

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import per.baluth.hospital.databinding.ActivityDoctorCollectionBinding

class DoctorCollectionActivity : AppCompatActivity() {
    private lateinit var binding: ActivityDoctorCollectionBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDoctorCollectionBinding.inflate(layoutInflater)
        setContentView(binding.root)
    }
}