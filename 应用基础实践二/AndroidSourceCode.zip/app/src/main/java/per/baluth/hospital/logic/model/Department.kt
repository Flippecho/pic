package per.baluth.hospital.logic.model

data class Department(val department_id: Int, val department_name: String, val description: String)
