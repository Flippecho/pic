package per.baluth.hospital.logic.model

data class DoctorInfo(
    val doctor_id: Int,
    val doctor_name: String,
    val title_name: String,
    val price: Int,
    val sub_department_id: Int,
    val sub_department_name: String,
    val working_years: Int,
    val patient_amount: Int,
    val praise_amount: Int,
    val criticize_amount: Int
)
