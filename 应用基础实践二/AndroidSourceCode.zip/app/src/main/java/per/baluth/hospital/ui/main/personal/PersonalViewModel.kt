package per.baluth.hospital.ui.main.personal

import androidx.lifecycle.ViewModel
import per.baluth.hospital.logic.Repository

class PersonalViewModel: ViewModel() {
    fun hasIdentifier() = Repository.hasIdentifier()

    fun getIdentifier() = Repository.getIdentifier()

    fun deleteIdentifier() = Repository.deleteIdentifier()
}