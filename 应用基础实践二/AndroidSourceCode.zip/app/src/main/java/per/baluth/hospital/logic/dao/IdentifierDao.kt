package per.baluth.hospital.logic.dao

import android.content.Context
import android.content.SharedPreferences
import androidx.core.content.edit
import com.google.gson.Gson
import per.baluth.hospital.getSharedContext
import per.baluth.hospital.logic.model.Identifier

object IdentifierDao {
    private const val SP_NAME = "IDENTIFIER"
    private const val KEY_IDENTIFIER = "IDENTIFIER"

    private fun sharedPreferences(): SharedPreferences =
        getSharedContext().getSharedPreferences(SP_NAME, Context.MODE_PRIVATE)

    fun hasIdentifier() = sharedPreferences().contains(KEY_IDENTIFIER)

    fun setIdentifier(identifier: Identifier) = sharedPreferences().edit {
        putString(KEY_IDENTIFIER, Gson().toJson(identifier))
    }

    fun getIdentifier(): Identifier {
        val json = sharedPreferences().getString(KEY_IDENTIFIER, "")
        return Gson().fromJson(json, Identifier::class.java)
    }

    fun deleteIdentifier() {
        sharedPreferences().edit().clear().commit()
    }
}