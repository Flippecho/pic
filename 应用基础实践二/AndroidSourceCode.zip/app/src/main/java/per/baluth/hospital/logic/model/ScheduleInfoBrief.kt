package per.baluth.hospital.logic.model

data class ScheduleInfoBrief(val id: Int, val date: Int, val morning: Int, val afternoon: Int)
