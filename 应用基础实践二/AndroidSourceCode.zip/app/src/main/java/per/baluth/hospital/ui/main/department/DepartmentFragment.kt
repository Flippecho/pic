package per.baluth.hospital.ui.main.department

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.widget.doAfterTextChanged
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import per.baluth.hospital.databinding.FragmentDepartmentBinding
import per.baluth.hospital.logic.model.Department

class DepartmentFragment : Fragment() {
    private var _binding: FragmentDepartmentBinding? = null
    private val binding: FragmentDepartmentBinding get() = _binding!!
    private val viewModel by lazy { ViewModelProvider(this)[DepartmentViewModel::class.java] }
    private lateinit var adapter: DepartmentAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentDepartmentBinding.inflate(inflater, container, false)
        return binding.root
    }

    @SuppressLint("NotifyDataSetChanged")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        adapter = DepartmentAdapter(this, viewModel.departmentList)
        binding.departmentList.adapter = adapter
        viewModel.refresh()
        viewModel.departmentLiveData.observe(viewLifecycleOwner) {
            viewModel.departmentList.clear()
            viewModel.departmentList.addAll(viewModel.departmentLiveData.value!!)
            adapter.notifyDataSetChanged()
        }

        binding.searchDepartmentEditText.doAfterTextChanged {
            // remove blank characters
            val content = binding.searchDepartmentEditText.text.toString().replace("\\s".toRegex(), "")

            if (content.isNotEmpty()) {
                val departmentList = viewModel.departmentLiveData.value!!
                val departmentListFiltered = ArrayList<Department>()

                for (department in departmentList) {
                    if (department.department_name.contains(content)) {
                        departmentListFiltered.add(department)
                    }
                }

                viewModel.departmentList.clear()
                viewModel.departmentList.addAll(departmentListFiltered)
                adapter.notifyDataSetChanged()
            } else {
                // show all if empty
                viewModel.departmentList.clear()
                viewModel.departmentList.addAll(viewModel.departmentLiveData.value!!)
                adapter.notifyDataSetChanged()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.updateCancelCount()
    }

    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }
}