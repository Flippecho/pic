package per.baluth.hospital.ui.main.order

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import kotlinx.coroutines.*
import per.baluth.hospital.clickFeedback
import per.baluth.hospital.databinding.FragmentOrderBinding
import per.baluth.hospital.ui.login.LoginActivity

class OrderFragment : Fragment() {
    private var _binding: FragmentOrderBinding? = null
    private val binding: FragmentOrderBinding get() = _binding!!
    private val viewModel by lazy { ViewModelProvider(this)[OrderViewModel::class.java] }
    private lateinit var adapter: OrderAdapter
    private var refreshJob: Job? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentOrderBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        adapter = OrderAdapter(this, viewModel.orderList)
        binding.orderList.adapter = adapter

        binding.loginButton.setOnClickListener {
            clickFeedback(it)
            val intent = Intent(requireContext(), LoginActivity::class.java)
            startActivity(intent)
        }

        viewModel.orderLiveData.observe(viewLifecycleOwner) {
            viewModel.orderList.clear()
            viewModel.orderList.addAll(it)
            adapter.notifyDataSetChanged()

            if (it.isEmpty()) {
                binding.orderList.visibility = View.GONE
                binding.placeholder.visibility = View.VISIBLE
                binding.emptyHint.visibility = View.VISIBLE
                binding.loginButton.visibility = View.GONE
            } else {
                binding.orderList.visibility = View.VISIBLE
                binding.placeholder.visibility = View.GONE
            }
        }

    }

    override fun onResume() {
        super.onResume()
        if (viewModel.hasIdentifier()) {
            val identifier = viewModel.getIdentifier()

            if (refreshJob == null) {
                refreshJob = Job()
                CoroutineScope(refreshJob!!).launch {
                    repeat(Int.MAX_VALUE) {
                        viewModel.refresh(identifier.id)
                        delay(1000)
                    }
                }
            }

        } else {
            binding.loginButton.visibility = View.VISIBLE
            binding.placeholder.visibility = View.VISIBLE
            binding.orderList.visibility = View.GONE
            refreshJob?.cancel()
            refreshJob = null
        }
    }

    override fun onPause() {
        super.onPause()
        refreshJob?.cancel()
        refreshJob = null
    }

    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }
}