package per.baluth.hospital.ui.doctor_collection

import android.content.Intent
import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import per.baluth.hospital.clickFeedback
import per.baluth.hospital.databinding.FragmentDoctorBasicBinding
import per.baluth.hospital.logic.model.DoctorInfoBrief
import per.baluth.hospital.ui.doctor.DoctorActivity

class DoctorAdapter(
    private val fragment: DoctorCollectionFragment,
    private val doctorList: List<DoctorInfoBrief>
) : RecyclerView.Adapter<DoctorAdapter.BindViewHolder>() {

    inner class BindViewHolder(private var itemBinding: FragmentDoctorBasicBinding) :
        RecyclerView.ViewHolder(itemBinding.root) {

        fun bind(doctor: DoctorInfoBrief) {
            itemBinding.name.text = doctor.doctor_name
            itemBinding.title.text = doctor.title_name
            itemBinding.subDepartment.text = doctor.sub_department_name
            itemBinding.root.setOnClickListener {
                clickFeedback(it)
                val intent = Intent(fragment.requireContext(), DoctorActivity::class.java)
                intent.putExtra("DOCTOR_ID", doctor.doctor_id)
                fragment.startActivity(intent)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BindViewHolder {
        val itemBinding = FragmentDoctorBasicBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return BindViewHolder(itemBinding)
    }

    override fun onBindViewHolder(holder: BindViewHolder, position: Int) {
        val doctor = doctorList[position]
        holder.bind(doctor)
    }

    override fun getItemCount() = doctorList.size
}