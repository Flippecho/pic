package per.baluth.hospital.ui.doctor

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import kotlinx.coroutines.*
import per.baluth.hospital.clickFeedback
import per.baluth.hospital.databinding.FragmentDoctorBinding
import per.baluth.hospital.ui.login.LoginActivity

class DoctorFragment : Fragment() {
    private var _binding: FragmentDoctorBinding? = null
    private val binding: FragmentDoctorBinding get() = _binding!!
    private val viewModel by lazy { ViewModelProvider(this)[DoctorViewModel::class.java] }
    private lateinit var adapter: BriefScheduleAdapter
    private var refreshJob: Job? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentDoctorBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val intent = requireActivity().intent
        val id = intent.getIntExtra("DOCTOR_ID", 0)

        viewModel.refreshDoctorInfo(id)

        binding.introductionLayout.collectButton.setOnClickListener {
            clickFeedback(it)

            if (viewModel.hasIdentifier()) {
                CoroutineScope(Job()).launch {
                    viewModel.checkIsCollected(id)
                    val isCollected = viewModel.getIsCollected(id)
                    if (isCollected) {
                        viewModel.unCollectDoctor(id)
                    } else {
                        viewModel.collectDoctor(id)
                    }
                    viewModel.refreshDoctorInfo(id)
                }
            } else {
                val intent2 = Intent(requireContext(), LoginActivity::class.java)
                startActivity(intent2)
            }
        }

        viewModel.hasCollectedLiveData.observe(viewLifecycleOwner) {
            if (it) {
                binding.introductionLayout.collectButton.text = "取消收藏"
            } else {
                binding.introductionLayout.collectButton.text = "加入收藏"
            }
        }

        viewModel.doctorInfoLiveData.observe(viewLifecycleOwner) {
            binding.basicLayout.name.text = it.doctor_name
            binding.basicLayout.title.text = it.title_name
            binding.basicLayout.subDepartment.text = it.sub_department_name

            binding.figureLayout.workingYears.text = "从医时长: ${it.working_years} 年"
            binding.figureLayout.patientAmount.text = "接诊人次: ${it.patient_amount}"
            binding.figureLayout.praiseAmount.text = "好评个数: ${it.praise_amount}"
            binding.figureLayout.criticizeAmount.text = "差评个数: ${it.criticize_amount}"

            binding.introductionLayout.introduction.text = "这个医生有点懒，什么都没有留下，但不要担心，沉默是金，应该是个实力派。"

            adapter = BriefScheduleAdapter(this, it, viewModel.scheduleList)
            binding.scheduleLayout.scheduleList.adapter = adapter

            viewModel.checkIsCollected(id)

            viewModel.scheduleLiveData.observe(viewLifecycleOwner) {
                viewModel.scheduleList.clear()
                viewModel.scheduleList.addAll(it)
                adapter.notifyDataSetChanged()
            }
        }
    }

    override fun onResume() {
        super.onResume()

        val intent = requireActivity().intent
        val id = intent.getIntExtra("DOCTOR_ID", 0)

        if (refreshJob == null) {
            refreshJob = Job()
            CoroutineScope(refreshJob!!).launch {
                repeat(Int.MAX_VALUE) {
                    viewModel.refresh(id)
                    delay(1000)
                }
            }
        }
    }

    override fun onPause() {
        super.onPause()
        refreshJob?.cancel()
        refreshJob = null
    }

    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }
}