package per.baluth.hospital.logic.model

data class Identifier(val id: Int, val username: String, val telephone: String, val id_card: String)