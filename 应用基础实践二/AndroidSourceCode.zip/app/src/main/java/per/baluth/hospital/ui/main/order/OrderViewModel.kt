package per.baluth.hospital.ui.main.order

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import per.baluth.hospital.logic.Repository
import per.baluth.hospital.logic.model.OrderInfoDetailed

class OrderViewModel : ViewModel() {
    internal  val orderList = ArrayList<OrderInfoDetailed>()
    internal val orderLiveData = MutableLiveData<List<OrderInfoDetailed>>()

    fun hasIdentifier() = Repository.hasIdentifier()

    fun getIdentifier() = Repository.getIdentifier()

    fun refresh(id: Int) {
        CoroutineScope(Job()).launch {
            orderLiveData.postValue(Repository.getFirstTenOrders(id))
        }
    }
}