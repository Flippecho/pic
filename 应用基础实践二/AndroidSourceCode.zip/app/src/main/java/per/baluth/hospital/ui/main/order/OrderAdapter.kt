package per.baluth.hospital.ui.main.order

import android.content.Intent
import android.net.Uri
import android.provider.CalendarContract
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import kotlinx.coroutines.*
import per.baluth.hospital.clickFeedback
import per.baluth.hospital.databinding.FragmentOrderItemBinding
import per.baluth.hospital.logic.Repository
import per.baluth.hospital.logic.model.OrderInfoDetailed
import per.baluth.hospital.toast
import per.baluth.hospital.widthTo
import java.text.SimpleDateFormat
import java.util.*

class OrderAdapter(
    private val fragment: OrderFragment,
    private val orderList: List<OrderInfoDetailed>
) : RecyclerView.Adapter<OrderAdapter.BindViewHolder>() {

    inner class BindViewHolder(private var itemBinding: FragmentOrderItemBinding) :
        RecyclerView.ViewHolder(itemBinding.root) {
        fun bind(order: OrderInfoDetailed) {
            val calendar = Calendar.getInstance()
            val date = order.date - 1
            calendar.add(Calendar.DAY_OF_WEEK, date)
            val week = when (date) {
                0 -> "今天"
                1 -> "明天"
                2 -> "后天"
                else -> SimpleDateFormat("EE", Locale.CHINA).format(calendar.time)
            }
            val year = calendar.get(Calendar.YEAR)
            val month = calendar.get(Calendar.MONTH) + 1
            val day = calendar.get(Calendar.DAY_OF_MONTH)
            val morNoon = if (order.is_morning == 1) "上午" else "下午"

            itemBinding.doctor.text = "医生：${order.doctor_name}"
            itemBinding.department.text = order.sub_department_name
            itemBinding.patient.text = "患者：${order.patient_name}"
            itemBinding.time.text = "$week  |  $month-$day  |  $morNoon"

            Log.d("Baluth", order.toString())
            when (order.order_status) {
                0 -> {
                    itemBinding.commentLayout.visibility = View.GONE
                    itemBinding.cancelLayout.visibility = View.GONE
                    itemBinding.pay.visibility = View.VISIBLE
                    itemBinding.cancel.visibility = View.GONE
                    itemBinding.defaultLayout.visibility = View.VISIBLE
                }
                1 -> {
                    itemBinding.cancelLayout.visibility = View.GONE
                    itemBinding.commentLayout.visibility = View.GONE
                    itemBinding.pay.visibility = View.GONE
                    itemBinding.cancel.visibility = View.VISIBLE
                    itemBinding.defaultLayout.visibility = View.VISIBLE
                }
                2 -> {
                    itemBinding.defaultLayout.visibility = View.GONE
                    itemBinding.cancelLayout.visibility = View.GONE
                    itemBinding.commentLayout.visibility = View.VISIBLE
                }
                4 -> {
                    itemBinding.defaultLayout.visibility = View.GONE
                    itemBinding.commentLayout.visibility = View.GONE
                    itemBinding.cancelLayout.visibility = View.VISIBLE
                }
            }

            if (order.date == 1) {
                itemBinding.cancel.visibility = View.GONE
            }

            itemBinding.calendar.setOnClickListener {
                clickFeedback(it)

                val startMillis: Long = Calendar.getInstance().run {
                    set(year, month, day, if (order.is_morning == 1) 8 else 14, 0)
                    timeInMillis
                }

                val endMillis: Long = Calendar.getInstance().run {
                    set(year, month, day, if (order.is_morning == 1) 12 else 18, 0)
                    timeInMillis
                }

                val intent = Intent(Intent.ACTION_INSERT)
                    .setData(CalendarContract.Events.CONTENT_URI)
                    .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, startMillis)
                    .putExtra(CalendarContract.EXTRA_EVENT_END_TIME, endMillis)
                    .putExtra(CalendarContract.Events.TITLE, order.sub_department_name)
                    .putExtra(
                        CalendarContract.Events.DESCRIPTION,
                        "医生：${order.doctor_name}    患者：${order.patient_name}"
                    )
                    .putExtra(CalendarContract.Events.EVENT_LOCATION, "中南大学湘雅医院")

                fragment.startActivity(intent)
            }

            itemBinding.navigation.setOnClickListener {
                clickFeedback(it)

                val intent = Intent(Intent.ACTION_VIEW)
                val chooser = Intent.createChooser(intent, "请选择地图")
                intent.data =
                    Uri.parse("geo:0,0?q=%E4%B8%AD%E5%8D%97%E5%A4%A7%E5%AD%A6%E6%B9%98%E9%9B%85%E5%8C%BB%E9%99%A2")     // 中南大学湘雅医院
                fragment.startActivity(chooser)
            }

            itemBinding.cancel.setOnClickListener {
                clickFeedback(it)

                val cancelCount = Repository.getCancelCount()
                MaterialAlertDialogBuilder(fragment.requireContext()).apply {
                    setMessage("预约信息如下:\n" +
                            "科室:  ${order.sub_department_name}\n" +
                            "医生:  ${order.doctor_name}\n" +
                            "患者:  ${order.patient_name}\n" +
                            "时间:  $week  |  $month 月 $day 日$morNoon\n" +
                            "\n7 天内取消 3 次订单后将暂停线上预约功能，您当前已取消 $cancelCount 次，是否要取消本次预约？\n")
                    setPositiveButton("取消预约") { _, _ ->
                        CoroutineScope(Job()).launch {
                            val result = Repository.cancelOrder(order.order_id.widthTo(11))
                            if (result) {
                                withContext(Dispatchers.Main) {
                                    itemBinding.defaultLayout.visibility = View.GONE
                                    itemBinding.commentLayout.visibility = View.GONE
                                    itemBinding.cancelLayout.visibility = View.VISIBLE
                                }
                            }
                        }
                    }
                    setNegativeButton("放弃取消") { _, _ -> }
                    show()
                }
            }

            itemBinding.pay.setOnClickListener {
                clickFeedback(it)

                CoroutineScope(Job()).launch {
                    val qrCode = Repository.getQrCode(order.order_id.widthTo(11))
                    if (qrCode.succeed) {
                        val payUrl =
                            "alipays://platformapi/startapp?saId=10000007&qrcode=${qrCode.qrCode}"
                        val intent = Intent.parseUri(payUrl, Intent.URI_INTENT_SCHEME)
                        intent.addCategory("android.intent.category.BROWSABLE")
                        intent.component = null
                        fragment.startActivity(intent)
                    } else {
                        "无法唤起支付 :（".toast()
                    }
                }
            }

            itemBinding.flow.setOnClickListener {
                clickFeedback(it)
                val intent = Intent(fragment.requireContext(), FlowImageDialog::class.java)
                fragment.startActivity(intent)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BindViewHolder {
        val itemBinding = FragmentOrderItemBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )

        return BindViewHolder(itemBinding)
    }

    override fun onBindViewHolder(holder: BindViewHolder, position: Int) {
        val order = orderList[position]
        holder.bind(order)
    }

    override fun getItemCount(): Int = orderList.size
}