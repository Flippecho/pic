package per.baluth.hospital.ui.main.personal

import android.app.Activity
import android.os.Bundle
import com.google.gson.Gson
import per.baluth.hospital.R
import per.baluth.hospital.databinding.CustomDialogQrCodeBinding
import per.baluth.hospital.logic.Repository
import per.baluth.hospital.logic.utils.QrCode

class QrCodeDialog: Activity() {
    private lateinit var binding: CustomDialogQrCodeBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = CustomDialogQrCodeBinding.inflate(layoutInflater)
        setContentView(binding.root)
        this.setFinishOnTouchOutside(false)
    }

    override fun onResume() {
        super.onResume()
        val json = Gson().toJson(Repository.getIdentifier())
        val displayMetrics = this.resources.displayMetrics
        val bitmap = QrCode.createQr(json, (displayMetrics.widthPixels * 0.7).toInt())
        if (bitmap != null) {
            binding.image.setImageBitmap(bitmap)
        } else {
            binding.image.setImageResource(R.drawable.ic_qr_code_load_failure)
        }
    }
}