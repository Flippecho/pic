package per.baluth.hospital.logic.model

data class OrderInfoDetailed(
    val order_id: Int,
    val sub_department_name: String,
    val doctor_id: Int,
    val doctor_name: String,
    val patient_name: String,
    val id_card: String,
    val telephone: String,
    val date: Int,
    val is_morning: Int,
    val cost: Int,
    val order_status: Int
)
