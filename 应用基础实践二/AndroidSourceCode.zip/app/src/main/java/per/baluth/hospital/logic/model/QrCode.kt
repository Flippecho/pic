package per.baluth.hospital.logic.model

data class QrCode(val succeed: Boolean, val qrCode: String)
