package per.baluth.hospital.ui.doctor_collection

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import per.baluth.hospital.databinding.FragmentDoctorCollectionBinding

class DoctorCollectionFragment : Fragment() {
    private var _binding: FragmentDoctorCollectionBinding? = null
    private val binding: FragmentDoctorCollectionBinding get() = _binding!!
    private val viewModel by lazy { ViewModelProvider(this)[DoctorCollectionViewModel::class.java] }
    private lateinit var adapter: DoctorAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentDoctorCollectionBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        adapter = DoctorAdapter(this, viewModel.doctorList)
        binding.doctorList.adapter = adapter

        viewModel.doctorLiveData.observe(viewLifecycleOwner) {
            if (it.isEmpty()) {
                showPlaceholder()
            } else {
                viewModel.doctorList.clear()
                viewModel.doctorList.addAll(it)
                adapter.notifyDataSetChanged()
                hidePlaceholder()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.getDoctorCollection()
    }

    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }

    private fun showPlaceholder() {
        binding.doctorList.visibility = View.GONE
        binding.placeholder.visibility = View.VISIBLE
    }

    private fun hidePlaceholder() {
        binding.doctorList.visibility = View.VISIBLE
        binding.placeholder.visibility = View.GONE
    }
}