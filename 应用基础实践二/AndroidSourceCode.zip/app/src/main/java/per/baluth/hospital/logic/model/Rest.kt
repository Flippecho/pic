package per.baluth.hospital.logic.model

data class Rest(val morning: Int, val afternoon: Int)
