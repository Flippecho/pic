package per.baluth.hospital.ui.order_preview

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.gson.Gson
import kotlinx.coroutines.*
import per.baluth.hospital.clickFeedback
import per.baluth.hospital.databinding.FragmentOrderPreviewBinding
import per.baluth.hospital.logic.model.OrderInfo
import per.baluth.hospital.toast
import per.baluth.hospital.ui.login.LoginActivity
import per.baluth.hospital.ui.main.MainActivity
import per.baluth.hospital.widthTo
import java.util.*

class OrderPreviewFragment : Fragment() {
    private var _binding: FragmentOrderPreviewBinding? = null
    private val binding: FragmentOrderPreviewBinding get() = _binding!!
    private val viewModel by lazy { ViewModelProvider(this)[OrderPreviewViewModel::class.java] }
    private var refreshJob: Job? = null

    private val paymentArray = arrayOf("支付宝", "微信", "银联", "诊疗卡")

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentOrderPreviewBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onResume() {
        super.onResume()
        val json = requireActivity().intent.getStringExtra("ORDER_INFO")
        val orderInfo = Gson().fromJson(json, OrderInfo::class.java)

        if (viewModel.orderId != 0) {
            CoroutineScope(Job()).launch {
                withContext(Dispatchers.Main) {
                    showProgress()
                    binding.topTitle.text = "正在查询支付状态"
                    delay(3 * 1000)
                    val orderStatus = viewModel.getOrderStatus(viewModel.orderId)
                    if (orderStatus == 1) {
                        "支付成功".toast()
                    } else {
                        "请在 15 分钟内完成支付".toast()
                    }
                    val intent = Intent(requireContext(), MainActivity::class.java)
                    startActivity(intent)
                }
            }
        } else if (viewModel.hasIdentifier()){
            viewModel.getOrderCountStatus(
                orderInfo.schedule_id,
                orderInfo.isMorning,
                orderInfo.sub_department_id
            )
        }

        viewModel.orderCountStatusLiveData.observe(viewLifecycleOwner) {
            Log.d("Baluth", orderInfo.toString())
            setSubmitButton(it == 0)
            when (it) {
                1 -> "不可重复预约".toast()
                2 -> "同一科室至多 3 个预约".toast()
                3 -> "同一账号至多 7 个预约".toast()
            }
        }

        if (viewModel.hasIdentifier()) {
            val identifier = viewModel.getIdentifier()
            orderInfo.patient_id = identifier.id
            binding.patientName.text = "就诊人：${identifier.username}"
            binding.patientCardId.text = "身份证号：${identifier.id_card}"
            binding.patientTelephone.text = "手机号码：${identifier.telephone}"
        } else if (viewModel.firstResume) {
            viewModel.firstResume = false
            val intent = Intent(requireContext(), LoginActivity::class.java)
            startActivity(intent)
        } else {
            requireActivity().finish()
        }

        val calendar = Calendar.getInstance()
        calendar.add(Calendar.DAY_OF_WEEK, orderInfo.date)
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH) + 1
        val day = calendar.get(Calendar.DAY_OF_MONTH)
        val dayPart = if (orderInfo.isMorning) "上午" else "下午"

        binding.subDepartment.text = "科室：${orderInfo.sub_department_name}"
        binding.doctor.text = "医生：${orderInfo.doctor_name}"
        binding.time.text = "时间：$year-${month.widthTo(2)}-${day.widthTo(2)}    $dayPart    "
        binding.cost.text = "${orderInfo.cost}￥"

        binding.paymentContainer.setOnClickListener {
            clickFeedback(it)
            MaterialAlertDialogBuilder(requireContext())
                .setTitle("请选择支付方式")
                .setSingleChoiceItems(paymentArray, viewModel.paymentId) { dialog, which ->
                    binding.payment.text = paymentArray[which]
                    viewModel.paymentId = which
                    orderInfo.payment_id = which
                    dialog.dismiss()
                }.show()
        }

        binding.submitButton.setOnClickListener {
            CoroutineScope(Job()).launch {
                val payResponse = viewModel.submitOrder(Gson().toJson(orderInfo))
                if (payResponse.code == 10000) {
                    viewModel.orderId = payResponse.out_trade_no.toInt()
                    val payUrl =
                        "alipays://platformapi/startapp?saId=10000007&qrcode=${payResponse.qr_code}"
                    val intent = Intent.parseUri(payUrl, Intent.URI_INTENT_SCHEME)
                    intent.addCategory("android.intent.category.BROWSABLE")
                    intent.component = null
                    startActivity(intent)
                } else {
                    "订单创建失败".toast()
                }
            }
        }

        if (viewModel.hasIdentifier() && refreshJob == null) {
            refreshJob = Job()
            CoroutineScope(refreshJob!!).launch {
                repeat(Int.MAX_VALUE) {
                    val rest = viewModel.getRest(orderInfo.schedule_id)
                    withContext(Dispatchers.Main) {
                        binding.rest.text =
                            "余 ${if (orderInfo.isMorning) rest.morning else rest.afternoon}"
                    }
                    delay(1000)
                }
            }
        }
    }

    override fun onPause() {
        super.onPause()
        if (refreshJob != null) {
            refreshJob!!.cancel()
            refreshJob = null
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }

    private fun showProgress() {
        CoroutineScope(Job()).launch {
            withContext(Dispatchers.Main) {
                binding.progress.visibility = View.VISIBLE
                binding.divider.visibility = View.GONE
            }
        }
    }

    private fun setSubmitButton(active: Boolean) {
        if (active) {
            binding.submitButton.visibility = View.VISIBLE
            binding.disabledButton.visibility = View.GONE
        } else {
            binding.submitButton.visibility = View.GONE
            binding.disabledButton.visibility = View.VISIBLE
        }
    }
}