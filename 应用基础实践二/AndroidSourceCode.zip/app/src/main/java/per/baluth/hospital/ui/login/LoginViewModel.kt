package per.baluth.hospital.ui.login

import androidx.lifecycle.ViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import per.baluth.hospital.logic.Repository
import per.baluth.hospital.logic.model.Identifier
import java.time.LocalTime

class LoginViewModel : ViewModel() {
    fun startWaiting(telephone: String): Int = Repository.startWaiting(telephone)

    fun isWaiting(): Boolean = Repository.isWaiting()

    fun getEndTime(): Long = Repository.getEndTime()

    fun getTelephone() = Repository.getTelephone()

    fun increaseRetry() = Repository.increaseRetry()

    fun resetRetry() = Repository.resetRetry()

    fun storeTimer() = Repository.storeTimer()

    fun restoreTimer() = Repository.restoreTimer()

    fun getVerificationCode(telephone: String) {
        CoroutineScope(Job()).launch {
            Repository.getVerificationCode(telephone)
        }
    }

    suspend fun checkVerificationCode(telephone: String, code: String) =
        Repository.checkVerificationCode(telephone, code)

    suspend fun getRegisterStatus(telephone: String) = Repository.getRegisterStatus(telephone)

    suspend fun updateInfo(telephone: String, id: String, name: String) =
        Repository.updateInfo(telephone, id, name)

    suspend fun checkIdentifier(id: String, name: String) = Repository.checkIdentifier(id, name)

    suspend fun getIdentifier(telephone: String) = Repository.getIdentifier(telephone)

    fun setIdentifier(identifier: Identifier) = Repository.setIdentifier(identifier)
}