package per.baluth.android.nasagalley.data

data class PhotoSize(val width: Int, val height: Int)
