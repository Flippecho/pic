package per.baluth.android.nasagalley.data

data class JSON(val photos: ArrayList<Photo>)
