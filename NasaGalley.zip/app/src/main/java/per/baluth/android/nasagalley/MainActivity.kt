package per.baluth.android.nasagalley

import android.app.ActivityManager
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.StaggeredGridLayoutManager
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import kotlinx.coroutines.*
import per.baluth.android.nasagalley.data.Photo
import per.baluth.android.nasagalley.data.PhotoSize
import per.baluth.android.nasagalley.databinding.ActivityMainBinding
import per.baluth.android.nasagalley.network.PhotoDownloader
import per.baluth.android.nasagalley.persistence.DatabaseHelper
import per.baluth.android.nasagalley.persistence.FileHelper

class MainActivity : AppCompatActivity(), SwipeRefreshLayout.OnRefreshListener {


    private lateinit var binding: ActivityMainBinding
    private lateinit var photoList: ArrayList<Photo>
    private lateinit var _context: Context
    private var networkErrorCaptured: Boolean = false
    private lateinit var db: SQLiteDatabase
    private lateinit var retryThumbnail: Bitmap
    private lateinit var placeholderThumbnail: Bitmap

    override fun onRefresh() {
        networkErrorCaptured = false
        start()
        binding.swipeRefreshLayout.isRefreshing = false
        binding.swipeRefreshLayout.isEnabled = false
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // hide Action Bar
        supportActionBar?.hide()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            setTaskDescription(
                ActivityManager.TaskDescription(
                    getString(R.string.app_name),
                    R.drawable.ic_launcher_foreground
                )
            )
        }
        // enable viewBinding
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        // save context to pass to PhotoAdapter
        _context = this
        // set style
        binding.recyclerView.itemAnimator = null
        binding.swipeRefreshLayout.setOnRefreshListener(this)
        binding.swipeRefreshLayout.isEnabled = false
        // open database
        db = DatabaseHelper(this, "photos.db", 1).writableDatabase
        // generate thumbnails
        generateThumbnails()
        // initialization done
        start()
    }

    private fun start() {
        CoroutineScope(Job()).launch {
            val json = PhotoDownloader.fetchJSON()

            if (json != null) {
                photoList = json.photos
                binding.textView.setText(R.string.app_name)

                val layoutManager =
                    StaggeredGridLayoutManager(3, StaggeredGridLayoutManager.VERTICAL)
                val adapter =
                    PhotoAdapter(photoList, _context, db, retryThumbnail, placeholderThumbnail)

                withContext(Dispatchers.Main) {
                    binding.recyclerView.layoutManager = layoutManager
                    binding.recyclerView.adapter = adapter
                }
            } else {
                withContext(Dispatchers.Main) {
                    toastException(getString(R.string.network_error))
                }
            }
        }
    }

    private suspend fun toastException(e: String) {
        withContext(Dispatchers.Main) {
            Toast.makeText(_context, e, Toast.LENGTH_SHORT).show()
            binding.textView.setText(R.string.try_again)
            binding.swipeRefreshLayout.isEnabled = true
        }
        networkErrorCaptured = true
    }

    private fun generateThumbnails() {
        CoroutineScope(Job()).launch {
            val retryOrigin = BitmapFactory.decodeResource(resources, R.drawable.placeholder_retry)
            val placeholderOrigin =
                BitmapFactory.decodeResource(resources, R.drawable.placeholder_default)
            retryThumbnail =
                FileHelper.generateThumbnail(_context, retryOrigin, PhotoSize(300, 300))
            placeholderThumbnail =
                FileHelper.generateThumbnail(_context, placeholderOrigin, PhotoSize(300, 300))
        }
    }
}