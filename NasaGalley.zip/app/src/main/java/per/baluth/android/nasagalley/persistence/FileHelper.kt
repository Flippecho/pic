package per.baluth.android.nasagalley.persistence

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import per.baluth.android.nasagalley.data.PhotoSize
import java.io.ByteArrayOutputStream
import kotlin.math.ceil
import kotlin.math.roundToInt

object FileHelper {

    suspend fun accessPhoto(id: Int, context: Context, isOrigin: Boolean): Bitmap? {
        return try {
            val blob: ByteArray
            val filename: String = when (isOrigin) {
                true -> "original_$id.png"
                false -> "thumbnail_$id.png"
            }

            withContext(Dispatchers.IO) {
                context.openFileInput(filename).use {
                    blob = it.readBytes()
                }
            }
            BitmapFactory.decodeByteArray(blob, 0, blob.size)
        } catch (e: Exception) {
            e.printStackTrace()
            Log.d("Baluth", "file read failure")
            null
        }
    }

    suspend fun storePhoto(id: Int, bitmap: Bitmap, context: Context, isOrigin: Boolean): Boolean {
        return try {
            val filename: String = when (isOrigin) {
                true -> "original_$id.png"
                false -> "thumbnail_$id.png"
            }

            withContext(Dispatchers.IO) {
                context.openFileOutput(filename, Context.MODE_PRIVATE).use {
                    val bos = ByteArrayOutputStream()
                    val blob: ByteArray
                    withContext(Dispatchers.Default) {
                        bitmap.compress(Bitmap.CompressFormat.PNG, 100, bos)
                        blob = bos.toByteArray()
                    }
                    it.write(blob)
                }
            }
            true
        } catch (e: Exception) {
            Log.d("Baluth", "file write failure")
            false
        }
    }

    private fun calcPhotoSize(context: Context, originalSize: PhotoSize): PhotoSize {
        val resource = context.resources
        val displayMetrics = resource.displayMetrics
        val width: Int = ((displayMetrics.widthPixels - 6 * 3) / 3.0).roundToInt()
        val height: Int = (1.0 * width * originalSize.height / originalSize.width).roundToInt()
        return PhotoSize(width, height)
    }

    fun generatePlaceholder(context: Context, originSize: PhotoSize, color: Int): Bitmap {
        val thumbnailSize = calcPhotoSize(context, originSize)
        val bitmap =
            Bitmap.createBitmap(thumbnailSize.width, thumbnailSize.height, Bitmap.Config.RGB_565)
        bitmap.eraseColor(color)
        return bitmap
    }

    fun generateThumbnail(
        context: Context,
        bitmap: Bitmap,
        originSize: PhotoSize
    ): Bitmap {
        val thumbnailSize = calcPhotoSize(context, originSize)
        val bos = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, bos)
        val blob: ByteArray = bos.toByteArray()
        val options = BitmapFactory.Options()
        options.inPreferredConfig = Bitmap.Config.RGB_565
        options.inSampleSize = ceil(1.0 * originSize.width / thumbnailSize.width).toInt()
        return BitmapFactory.decodeByteArray(blob, 0, blob.size, options)
    }
}