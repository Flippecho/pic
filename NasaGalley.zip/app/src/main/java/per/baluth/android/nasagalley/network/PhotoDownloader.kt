package per.baluth.android.nasagalley.network

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Log
import kotlinx.coroutines.*
import per.baluth.android.nasagalley.data.JSON
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.coroutines.suspendCoroutine

object PhotoDownloader {

    suspend fun fetchJSON(): JSON? {
        return try {
            withContext(Dispatchers.IO) {
                ServiceCreator.create<PhotoService>().getData().await()
            }
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    suspend fun downloadPhoto(url: String): Bitmap? {
        return try {
            withContext(Dispatchers.IO) {
                ServiceCreator.create<PhotoService>().downloadPhoto(url).await()
                    .byteStream().use(BitmapFactory::decodeStream)
            }
        } catch (e: Exception) {
            e.printStackTrace()
            Log.d("Baluth", "download failure")
            null
        }
    }

    private suspend fun <T> Call<T>.await(): T {
        return suspendCoroutine { continuation ->
            enqueue(object : Callback<T> {
                override fun onResponse(call: Call<T>, response: Response<T>) {
                    val body = response.body()
                    if (body != null) continuation.resume(body)
                    else Log.d("Baluth", "body empty")
                }

                override fun onFailure(call: Call<T>, t: Throwable) {
                    continuation.resumeWithException(t)
                }
            })
        }
    }
}