package per.baluth.android.nasagalley

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.graphics.Bitmap
import android.graphics.Color
import androidx.palette.graphics.Palette
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.*
import per.baluth.android.nasagalley.data.Photo
import per.baluth.android.nasagalley.data.PhotoSize
import per.baluth.android.nasagalley.network.PhotoDownloader
import per.baluth.android.nasagalley.persistence.DatabaseHelper
import per.baluth.android.nasagalley.persistence.FileHelper

class PhotoAdapter(
    private val photoList: List<Photo>,
    private val context: Context,
    private val db: SQLiteDatabase,
    private val retryThumbnail: Bitmap,
    private val placeholderThumbnail: Bitmap
) :
    RecyclerView.Adapter<PhotoAdapter.ViewHolder>() {

    inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val photo: ImageView = view.findViewById(R.id.photo)
        var isLoadFailed: Boolean = false
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.photo_item, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.setIsRecyclable(false)
        val photo = photoList[position]
        val photoSize: PhotoSize? = DatabaseHelper.queryPhotoSizeByID(photo.id, db)
        val photoColor: Int? = DatabaseHelper.queryPhotoColorByID(photo.id, db)

        holder.photo.setOnClickListener {
            if (holder.isLoadFailed) {
                // clickable if load failed
                holder.isLoadFailed = false
                // change placeholder
                if (photoSize == null) {
                    holder.photo.setImageBitmap(placeholderThumbnail)
                } else {
                    val temp: PhotoSize = photoSize
                    val placeholder = FileHelper.generatePlaceholder(context, temp, photoColor!!)
                    holder.photo.setImageBitmap(placeholder)
                }
                // try to download again
                downloadPhoto(photo, holder)
            }
        }

        if (holder.isLoadFailed) {
            holder.photo.setImageBitmap(retryThumbnail)
        } else {
            if (photoSize == null) {
                holder.photo.setImageBitmap(placeholderThumbnail)
            } else {
                val temp: PhotoSize = photoSize
                val placeholder = FileHelper.generatePlaceholder(context, temp, photoColor!!)
                holder.photo.setImageBitmap(placeholder)
            }
            updatePhoto(holder, position, photoSize)
        }
    }

    override fun getItemCount() = photoList.size

    private fun downloadPhoto(photo: Photo, holder: ViewHolder) {
        CoroutineScope(Job()).launch {
            val bitmap = PhotoDownloader.downloadPhoto(photo.img_src)
            if (bitmap != null) {
                // download succeed
                // generate thumbnail and display
                val photoSize = PhotoSize(bitmap.width, bitmap.height)
                val thumbnail = FileHelper.generateThumbnail(context, bitmap, photoSize)
                withContext(Dispatchers.Main) {
                    holder.photo.setImageBitmap(thumbnail)
                }
                // get primary color
                val palette = Palette.from(bitmap).generate()
                val primaryColor = palette.getDominantColor(Color.parseColor("#212121"))
                // store info to database
                DatabaseHelper.insertIntoPhotos(photo, photoSize, primaryColor, db)
                // store thumbnail and origin to local
                FileHelper.storePhoto(photo.id, thumbnail, context, false)
                FileHelper.storePhoto(photo.id, bitmap, context, true)
                // set flag
            } else {
                // download failed, change placeholder
                holder.isLoadFailed = true
                withContext(Dispatchers.Main) {
                    holder.photo.setImageBitmap(retryThumbnail)
                }
            }
        }
    }

    private fun updatePhoto(holder: ViewHolder, position: Int, photoSize: PhotoSize?) {
        CoroutineScope(Job()).launch {
            val photo = photoList[position]
            var bitmap: Bitmap? = null

            if (photoSize != null) {
                // try to access local photo
                bitmap = FileHelper.accessPhoto(photo.id, context, false)
            }

            if (bitmap != null) {
                // local photo access succeed, which is thumbnail already
                withContext(Dispatchers.Main) {
                    holder.photo.setImageBitmap(bitmap)
                }
            } else {
                // local photo access fail, try to download photo
                downloadPhoto(photo, holder)
            }
        }
    }
}