package per.baluth.android.nasagalley

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.graphics.Bitmap
import android.graphics.Color
import androidx.palette.graphics.Palette
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.*
import per.baluth.android.nasagalley.data.Photo
import per.baluth.android.nasagalley.data.PhotoSize
import per.baluth.android.nasagalley.network.PhotoDownloader
import per.baluth.android.nasagalley.persistence.DatabaseHelper
import per.baluth.android.nasagalley.persistence.FileHelper

class PhotoAdapter(
    private val photoList: ArrayList<Photo>,
    private val isLoadFailed: Array<Boolean>,
    private val context: Context,
    private val db: SQLiteDatabase,
    private val retryThumbnail: Bitmap,
    private val placeholderThumbnail: Bitmap
) :
    RecyclerView.Adapter<PhotoAdapter.ViewHolder>() {

    inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val photo: ImageView = view.findViewById(R.id.photo)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.photo_item, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.setIsRecyclable(false)
        val photo = photoList[position]
        val photoSize: PhotoSize? = DatabaseHelper.queryPhotoSizeByID(photo.id, db)
        val photoColor: Int? = DatabaseHelper.queryPhotoColorByID(photo.id, db)
        
        holder.photo.setOnClickListener {
            if (isLoadFailed[position]) {
                // clickable if load failed
                // change placeholder
                if (photoSize == null) {
                    holder.photo.setImageBitmap(placeholderThumbnail)
                } else {
                    val temp: PhotoSize = photoSize
                    val placeholder = FileHelper.generatePlaceholder(context, temp, photoColor!!)
                    holder.photo.setImageBitmap(placeholder)
                }
                // try again
                updatePhoto(holder, position, photoSize)
//                downloadPhoto(photo, holder, position)
            }
        }

        if (isLoadFailed[position]) {
            holder.photo.setImageBitmap(retryThumbnail)
        } else {
            if (photoSize == null) {
                holder.photo.setImageBitmap(placeholderThumbnail)
            } else {
                val temp: PhotoSize = photoSize
                val placeholder = FileHelper.generatePlaceholder(context, temp, photoColor!!)
                holder.photo.setImageBitmap(placeholder)
            }
            updatePhoto(holder, position, photoSize)
        }
    }

    override fun getItemCount() = photoList.size

    private fun downloadPhoto(photo: Photo, holder: ViewHolder, position: Int) {
        CoroutineScope(Job()).launch {
            val bitmap = PhotoDownloader.downloadPhoto(photo.img_src)
            if (bitmap != null) {
                // download succeed
                // generate thumbnail and display
                val photoSize = PhotoSize(bitmap.width, bitmap.height)
                val thumbnail = FileHelper.generateThumbnail(context, bitmap, photoSize)
                withContext(Dispatchers.Main) {
                    holder.photo.setImageBitmap(thumbnail)
                }
                // get primary color
                val palette = Palette.from(bitmap).generate()
                val primaryColor = palette.getDominantColor(Color.parseColor("#212121"))
                // store info to database
                DatabaseHelper.insertIntoPhotos(photo, photoSize, primaryColor, db)
                // store thumbnail and origin to local
                FileHelper.storePhoto(photo.id, thumbnail, context, false)
                FileHelper.storePhoto(photo.id, bitmap, context, true)
                // set flag
                isLoadFailed[position] = false
            } else {
                // download failed, change placeholder
                isLoadFailed[position] = true
                withContext(Dispatchers.Main) {
                    holder.photo.setImageBitmap(retryThumbnail)
                }
            }
        }
    }

    private fun updatePhoto(holder: ViewHolder, position: Int, photoSize: PhotoSize?) {
        CoroutineScope(Job()).launch {
            val photo = photoList[position]
            var bitmap: Bitmap? = null

            if (photoSize != null) {
                // try to access local photo
                bitmap = FileHelper.accessPhoto(photo.id, context, false)
            }

            if (bitmap != null) {
                // local photo access succeed, which is thumbnail already
                withContext(Dispatchers.Main) {
                    holder.photo.setImageBitmap(bitmap)
                }
                // set flag
                isLoadFailed[position] = false
            } else {
                // local photo access fail, try to download photo
                downloadPhoto(photo, holder, position)
            }
        }
    }
}