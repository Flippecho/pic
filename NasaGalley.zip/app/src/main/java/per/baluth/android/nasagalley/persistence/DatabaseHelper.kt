package per.baluth.android.nasagalley.persistence

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.util.Log
import per.baluth.android.nasagalley.data.Photo
import per.baluth.android.nasagalley.data.PhotoSize

class DatabaseHelper(context: Context, name: String, version: Int) :
    SQLiteOpenHelper(context, name, null, version) {

    private val createPhoto = "create table Photos(" +
            "id integer primary key," +
            "sol integer," +
            "url String," +
            "earth_date text," +
            "width integer," +
            "height integer," +
            "color integer)"

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(createPhoto)
        Log.d("Baluth", "database created")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
    }

    companion object {
        fun queryPhotoSizeByID(id: Int, db: SQLiteDatabase): PhotoSize? {
            val query = "select width,height from Photos where id = $id"

            return try {
                db.rawQuery(query, null).use {
                    when (it.moveToFirst()) {
                        true -> PhotoSize(it.getInt(0), it.getInt(1))
                        false -> null
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
                Log.d("Baluth", "SQLite: read failure")
                null
            }
        }

        fun queryPhotoColorByID(id: Int, db: SQLiteDatabase): Int? {
            val query = "select color from Photos where id = $id"

            return try {
                db.rawQuery(query, null).use {
                    when (it.moveToFirst()) {
                        true -> it.getInt(0)
                        false -> null
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
                Log.d("Baluth", "SQLite: read failure")
                null
            }
        }

        fun insertIntoPhotos(
            photo: Photo,
            photoSize: PhotoSize,
            photoColor: Int,
            db: SQLiteDatabase
        ): Boolean {
            val values = ContentValues().apply {
                put("id", photo.id)
                put("sol", photo.sol)
                put("url", photo.img_src)
                put("earth_date", photo.earth_date)
                put("width", photoSize.width)
                put("height", photoSize.height)
                put("color", photoColor)
            }

            return try {
                db.replace("Photos", null, values)
                true
            } catch (e: Exception) {
                e.printStackTrace()
                Log.d("Baluth", "SQLite: write failure")
                false
            }
        }
    }
}