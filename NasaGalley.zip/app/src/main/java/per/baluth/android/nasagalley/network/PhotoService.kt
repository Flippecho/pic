package per.baluth.android.nasagalley.network

import okhttp3.ResponseBody
import per.baluth.android.nasagalley.data.JSON
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Url

interface PhotoService {
    @GET("mars-photos/api/v1/rovers/curiosity/photos?sol=21&api_key=Jr28aq7Y4YoQXV1ibCUpkGtLT9goq36ngYHohdTs")
    fun getData(): Call<JSON>

    @GET
    fun downloadPhoto(@Url url: String): Call<ResponseBody>
}